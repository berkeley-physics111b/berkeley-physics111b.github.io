function [FinalD,Ds, weights] = ComputeTotalD(cellarray)
%usage function out = ComputeTotalD(cellarray)
%This function computes the diffusion coefficient using all data spit out
%by the BrownianMotionApplication's Save Particle Data feature and then
%parsed by the BrownianMotionParse matlab script
%It computes the diffusion coefficient seperately for each tracked
%particle and then does a weighted mean on all of these values using the
%particle's tracked duration for weights. 

length = size(cellarray,1);

weights = zeros(length,1); %initialize our arrays
Ds = zeros(length,1);

for i = 1:length
    A = cellarray{i}; %i'th particle
    Ds(i) = ComputeD(A(:,3), A(:,8)); %compute diffusion Coefficient using our own computeD function. Feel free to make your own!
    weights(i) = size(A,1); %weighting by the number of frames we tracked this particle
end
FinalD = WeightedMean(Ds,weights);

