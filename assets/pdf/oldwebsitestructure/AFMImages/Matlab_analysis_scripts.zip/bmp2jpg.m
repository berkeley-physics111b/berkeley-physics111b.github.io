function bmp2jpg()

a = dir('*.bmp');
c = {a.name};
for i = 1:length(c);
    im = imread(c{i});
    jpgname = [c{i}(1:end-3) 'jpg'];
    imwrite(im, jpgname, 'jpg');
end


