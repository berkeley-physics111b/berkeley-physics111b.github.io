function D = ComputeD(time, D2)
%usage D = ComputeD(time, DisplacementSquared)
%Computes the DiffusionCoefficient of a Brownian Particle
%Calculates the slope of Displacement squared as a function of Time graph
%Assuming that we're working in two dimensions the diffusion coefficient is
%just a quarter of that

D = sum(D2.*time) / sum(time.*time) / 4;