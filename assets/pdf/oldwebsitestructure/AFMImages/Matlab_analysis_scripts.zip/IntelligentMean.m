function m = IntelligentMean(data)
%performs a nice mean that throws out outliers

for i = 1:10
    zscores = (data-mean(data))./std(data); %get a zscore for each point of data
    nonoutliers = find(abs(zscores)<2); %find all points less than two standard deviations away
    data = data(nonoutliers); %only accept the nice points
end %repeat

m = mean(data);