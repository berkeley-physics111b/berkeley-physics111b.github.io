function [Vx, Vy] = VelocityCell(in)
%usage [Vx,Vy] = VelocityCell(in)
%takes in a particle array and spits out a total, long-range velocity
%velocity = final position - initial position / time
Vx = (in(end,1)-in(1,1)) / in(end,3);
Vy = (in(end,2)-in(1,2)) / in(end,3);