function PlotParticle(Array, varargin)
%plots a particle data chunk x vs y
%usage PlotParticle(ParticleDataArray)
plot(Array(:,1), Array(:,2), varargin{:});