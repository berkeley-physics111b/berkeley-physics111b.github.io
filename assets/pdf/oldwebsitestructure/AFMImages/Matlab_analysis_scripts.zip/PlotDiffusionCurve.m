function PlotDiffusionCurve(Array, varargin)
%plots a particle data chunk. time vs displacement squared
%usage  PlotDiffusionCurve(ParticleDataArray)
plot(Array(:,3), Array(:,8), varargin{:});