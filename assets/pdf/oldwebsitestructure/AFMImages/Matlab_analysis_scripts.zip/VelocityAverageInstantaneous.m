function vout = VelocityAverageInstantaneous(in)
%usage function vout = VelocityAverageInstantaneous(in)
%calculates mean of instantaneous velocity magnitudes

dx = in(2:end,4); 
dy = in(2:end,5);
dt = in(2:end,6);

vx = dx./dt; vy = dy./dt;

vout = mean(sqrt(vx.^2 + vy.^2));
