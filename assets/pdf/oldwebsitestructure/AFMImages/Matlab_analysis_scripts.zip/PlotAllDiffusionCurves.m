function PlotAllDiffusionCurves(CellArray, varargin)
%plots all particles' time vs displacement squared graph
%usage  PlotAllDiffusionCurves(CellArray)
colors = ['b', 'g' , 'r', 'c', 'm', 'y', 'k'];
clf;
hold on;

for i = 1:length(CellArray)
    A = CellArray{i};
    plot(A(:,3), A(:,8), colors(mod(i, length(colors))+1), varargin{:});
end

hold off;