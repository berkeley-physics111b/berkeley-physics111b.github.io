function D = ComputeD2(dt, dr2)
%This function is not operational yet, or at least does not jive with
%reality
%usage function D = ComputeD(dt, D2)
ind = find(dt>.03);
if(size(ind)>0)
    D = median(dr2(ind)./(4*dt(ind)));
else
    D = 0; 
end