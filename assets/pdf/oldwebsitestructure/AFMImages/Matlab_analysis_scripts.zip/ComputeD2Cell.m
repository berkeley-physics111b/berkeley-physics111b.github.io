function D = ComputeDCell(A)
%usage function D = ComputeD(particledataarray)
D = ComputeD(A(:,6), A(:,7));