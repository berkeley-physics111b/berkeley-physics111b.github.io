function out = WeightedMean(x, w)
%Performs a weighted mean with values x and weights w
%usage function out = WeightedMean(x, w)
out = sum(x.*w)/sum(w);
