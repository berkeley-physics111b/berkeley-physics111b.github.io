function D = ComputeDCell(A)
%Usage D = ComputeDCell(CellArray{63})
%to compute the 63rd particle's DiffusionCoefficient
%Computes the DiffusionCoefficient of a Brownian Particle
%Calculates the slope of Displacement squared as a function of Time graph
%Assuming that we're working in two dimensions the diffusion coefficient is
%just a quarter of that

D = ComputeD(A(:,3), A(:,8));