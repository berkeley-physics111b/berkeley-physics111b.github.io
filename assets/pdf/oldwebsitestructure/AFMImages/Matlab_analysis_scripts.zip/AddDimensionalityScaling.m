function in = AddDimensionalityScaling(in, factor)
%usage DataOut = AddDimensionalityScaling(DataIn, meters per pixel factor)
%Act this function on your whole cell array (from BrownianMotionParse) in 
%order to add in physical units. Converts from pixels to meters.
%perform only once

for i = 1:size(in) ;  %foreach cell (particle in our case) in our array
    B = in{i} ; 
    B(:,1) = B(:,1)*factor; %X
    B(:,2) =B(:,2)*factor ; %Y
    B(:,4) =B(:,4)*factor ; %dX
    B(:,5) =B(:,5)*factor ; %dY
    B(:,7) =B(:,7)*factor^2 ; %dr^2
    B(:,8) = B(:,8)*factor^2 ; %displacement squared has units distance^2, needs two factors
    in{i} = B;
end