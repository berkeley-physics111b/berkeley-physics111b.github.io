function [Vx, Vy] = VelocityAll(in)
%usage [Vx,Vy] = VelocityAll(in)
%takes in a particle Cell array and spits out total, long-range velocities
%for all particles contained within
%velocity = final position - initial position / time
Vx = zeros(length(in),1);
Vy = zeros(length(in),1);
for i = 1:length(in)
    Vx(i) = (in{i}(end,1)-in{i}(1,1)) / in{i}(end,3);
    Vy(i) = (in{i}(end,2)-in{i}(1,2)) / in{i}(end,3);
end
