function out = lowpass(in,gausswidth)
%lowpass function
%usage out = lowpass(in,gausswidth)
%gausswidth is the width of elements close to dc to allow. Higher
%gausswidth means more high frequency information allowed. NOT compatible
%with the notion of gaussian convolution
l = length(in);
fin = fftshift(fft(in));
fin = fin.*(exp(-(((1:l)-l/2)/gausswidth).^2));
out = real(ifft(fftshift(fin)));

