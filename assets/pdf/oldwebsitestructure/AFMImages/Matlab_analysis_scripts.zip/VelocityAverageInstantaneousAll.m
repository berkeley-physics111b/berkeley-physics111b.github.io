function vout = VelocityAverageInstantaneousAll(in)
%usage function vout = VelocityAverageInstantaneous(in)
%calculates mean of instantaneous velocity magnitudes
%works on a Cell Array and returns an array of velocities

vout = zeros(length(in),1);

for i = 1:length(in)
    vout(i) = VelocityAverageInstantaneous(in{i});
end
