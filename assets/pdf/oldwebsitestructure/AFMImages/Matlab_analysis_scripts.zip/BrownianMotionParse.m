function out = BrownianMotionParse(filename)
%This function reads the particle data textfile produced by the Brownian
%Motion Data collection application and produces a cell array of particle
%data
%each cell corresponds to one detected particle
%usage CellArrayOut = BrownianMotionParse(filename)

maxlength  = 10000;
A = dlmread(filename,' ', 1,0); %read the file. Space delimited. Skip the first line (title line)
linenumber = 1;
numlines = size(A) ; numlines = numlines(1);
out = cell(maxlength,1); %initialize cell array to huge size
i = 1;
while(linenumber<numlines) %while there is still some file left
    length = A(linenumber, 1); %how large is this particular particle
    B = A(linenumber+1:linenumber+length, :); %grab everything that belongs to it
    linenumber = linenumber + length +1;
    out{i} = B; %put data into outgoing cell array
    i = i+1;
end

    
out = out(1:i-1);