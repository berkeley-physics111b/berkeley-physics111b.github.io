function Out = AccumulateData(Data)
%takes in a cell array of arrays and spits out a giant normal array
%removes first line of every entry. This is because we often use this function when dealing with the dx's and dy's in bulk. The first entry is always 0 for them. 
%usage outarray = AccumulateData(Cellarray)

Out = Data{1};
for i = 2:length(Data)
    Out = [Out;Data{i}];
end
