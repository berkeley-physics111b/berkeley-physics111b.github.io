function PlotAllTrajectories(data)
%usage PlotAllTrajectories(data) data is the cell array of all particle
%info
clf;
hold on;
c = ['b' 'g' 'r' 'c' 'm' 'y' 'k'];
for i=1:size(data)
    PlotParticleTrajectory(data{i}, c(mod(i,length(c))+1));
end
hold off;