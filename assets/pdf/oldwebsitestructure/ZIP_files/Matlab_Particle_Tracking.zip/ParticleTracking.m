function varargout = ParticleTracking(varargin)
% ParticleTracking Application M-file for ParticleTracking.fig
%   ParticleTracking, by itself, creates a new ParticleTracking or raises the existing
%   singleton*.
%
%   H = ParticleTracking returns the handle to a new ParticleTracking or
%   the handle to
%   the existing singleton*.
%
%   ParticleTracking('CALLBACK',hObject,eventData,handles,...) calls the local
%   function named CALLBACK in ParticleTracking.M with the given input arguments.
%
%   ParticleTracking('Property','Value',...) creates a new ParticleTracking or raises the
%   existing singleton*.  Starting from the left, property value pairs are
%   applied to the GUI before ParticleTracking_OpeningFunction gets called.  An
%   unrecognized property name or invalid value makes property application
%   stop.  All inputs are passed to ParticleTracking_OpeningFcn via varargin.
%
%   *See GUI Options - GUI allows only one instance to run (singleton).
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2001-2002 The MathWorks, Inc.

% Edit the above text to modify the response to help ParticleTracking

% Last Modified by GUIDE v2.5 23-Nov-2006 14:04:10

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',          mfilename, ...
                   'gui_Singleton',     gui_Singleton, ...
                   'gui_OpeningFcn',    @ParticleTracking_OpeningFcn, ...
                   'gui_OutputFcn',     @ParticleTracking_OutputFcn, ...
                   'gui_LayoutFcn',     [], ...
                   'gui_Callback',      []);
if nargin && isstr(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    varargout{1:nargout} = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT

% --- Executes just before ParticleTracking is made visible.
function ParticleTracking_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ParticleTracking (see VARARGIN)

% Choose default command line output for ParticleTracking
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = ParticleTracking_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

% --------------------------------------------------------------------
function varargout = loadMovie_pushbutton_Callback(hObject, eventdata, handles, varargin)
% hObject    handle to surf_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % compute filename of "frames.txt" file
    moviePath=uigetdir;                                                 % prompt user for movie directory
    slashes = findstr('\', moviePath)
    lastSlash=max(slashes)                                              % index of the last '\'
    movieName=moviePath(lastSlash+1:length(moviePath))                  % text after last '\' is the movie name
    set(handles.currentMovieLabel, 'String', strcat('Movie: ', movieName));
    ClearFrames(handles);
    guidata(hObject, handles);

    movie.movieName = movieName;
    movie.fileNames = importdata(strcat(moviePath, '\', movieName, ' frames.txt')); % retrieve list of all movie frames

    movieLength = length(movie.fileNames);
    colormap('gray');                                                   % set up for grayscale movie

    % get all of the parameters
    parameters.distanceScaleFactor = str2double(get(handles.scaleTextBox,'string'));
    parameters.lobject=str2double(get(handles.objectDiameter,'string'));
    parameters.lnoise=str2double(get(handles.noiseDiameter,'string'));
    parameters.standardDeviations=str2double(get(handles.standardDeviation,'string'));
    parameters.minimumDeviation=str2double(get(handles.minimumDeviation,'string'));
    parameters.minimumSize=str2double(get(handles.minimumSize,'string'));
    parameters.maximumDisplacement=str2double(get(handles.maximumDisplacement,'string'));
    parameters.subtractAverage = get(handles.subtractAverage_enable,'Value') == get(handles.subtractAverage_enable,'Max');
    parameters.eta = str2double(get(handles.etaTextBox,'string'));
    
    if(size(get(handles.startFrameTextBox,'string'),2) > 0)
        startFrame = str2double(get(handles.startFrameTextBox,'string'));
        endFrame = str2double(get(handles.endFrameTextBox,'string'));
        movieLength = endFrame - startFrame + 1;
    else
        startFrame = 1;
        endFrame = movieLength;
    end

    for i = 1: movieLength                                              
        set(handles.processingFrameNumberLabel, 'string', strcat('Loading Frame: ', num2str(i + startFrame - 1)));
        frame = imread(strcat(moviePath, '\', char(movie.fileNames(i + startFrame - 1)))); % read in the image
        movie.inputMovie(:,:,i) = frame;                            % add frame to movie
        displayFrame(handles, i, movie);
    end


    % scale the movie
    minValue = min(min(min(movie.inputMovie)));
    maxValue = max(max(max(movie.inputMovie)));
    range = maxValue - minValue;
    movie.inputMovie = uint8(((movie.inputMovie - minValue).*(234/range)) + 16);

    set(handles.processingFrameNumberLabel, 'string', 'Finished loading movie');

    % compute the average of the movie over all frames
    movie.averageFrame=uint8(sum(movie.inputMovie,3)/movieLength);  % compute the average

    % Update handles structure
    handles.currentMovie=movie;
    handles.currentFrame = movieLength;
    guidata(hObject, handles);


% --------------------------------------------------------------------
function varargout = NextFrame_pushbutton_Callback(hObject, eventdata, handles, varargin)
% hObject    handle to NextFrame_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    if(isfield(handles, 'currentMovie') & isfield(handles, 'currentFrame'))
        if(isfield(handles.currentMovie, 'inputMovie'))
            movieLength = size(handles.currentMovie.inputMovie,3);
            handles.currentFrame = min(movieLength, handles.currentFrame + 1);
            displayFrame(handles, handles.currentFrame, handles.currentMovie);
        end
    end

    guidata(hObject, handles);
    
% --------------------------------------------------------------------
function varargout = previousFrame_pushbutton_Callback(hObject, eventdata, handles, varargin)
% hObject    handle to NextFrame_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
    if(isfield(handles, 'currentMovie') & isfield(handles, 'currentFrame'))
        if(isfield(handles.currentMovie, 'inputMovie'))
            movieLength = size(handles.currentMovie.inputMovie,3);
            handles.currentFrame = max(1, handles.currentFrame - 1);
            displayFrame(handles, handles.currentFrame, handles.currentMovie);
        end
    end

    guidata(hObject, handles);

% --- Executes on button press in processMovieButton.
function processMovieButton_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to processMovieButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in processMovieButton.
function processMovieButton_Callback(hObject, eventdata, handles)
% hObject    handle to processMovieButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

    % clear out the movie data structure
    movie.inputMovie = handles.currentMovie.inputMovie;
    movie.fileNames = handles.currentMovie.fileNames;
    movie.averageFrame = handles.currentMovie.averageFrame;
    movieLength = size(movie.inputMovie,3) ;                                             
    ClearPlots(handles);
    clear handles.currentMovie;

    % Update handles structure
    guidata(hObject, handles);

    % get all of the parameters
    parameters.distanceScaleFactor = str2double(get(handles.scaleTextBox,'string'));
    parameters.lobject=str2double(get(handles.objectDiameter,'string'));
    parameters.lnoise=str2double(get(handles.noiseDiameter,'string'));
    parameters.standardDeviations=str2double(get(handles.standardDeviation,'string'));
    parameters.minimumDeviation=str2double(get(handles.minimumDeviation,'string'));
    parameters.minimumSize=str2double(get(handles.minimumSize,'string'));
    parameters.maximumDisplacement=str2double(get(handles.maximumDisplacement,'string'));
    parameters.subtractAverage = get(handles.subtractAverage_enable,'Value') == get(handles.subtractAverage_enable,'Max');
    parameters.eta = str2double(get(handles.etaTextBox,'string'));
    parameters.timestep = str2double(get(handles.timestepTextBox,'string'));

    showProgress = get(handles.showProgressCheckbox,'Value') == get(handles.showProgressCheckbox,'Max');
    for i = 1:movieLength                           
        set(handles.processingFrameNumberLabel, 'string', strcat('Processing Frame: ', num2str(i)));
        drawnow;
        computeTrajectoriesAndShow = showProgress | (i == movieLength);
        movie = ProcessFrame(movie, i, parameters, computeTrajectoriesAndShow);
        if(computeTrajectoriesAndShow)
            displayFrame(handles, i, movie);
            PlotData(handles, i, movie);
        end
    end
    set(handles.processingFrameNumberLabel, 'string', 'Finished processing');

    if(isfield(movie, 'particle'))
        assignin('base', 'particle', movie.particle);
    else
        assignin('base', 'particle', NaN);
    end
    
    handles.currentMovie = movie;
    set(handles.processingFrameNumberLabel, 'string', strcat('Done processing'));
    guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function TextBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to startFrameTextBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function TextBox_Callback(hObject, eventdata, handles)
% hObject    handle to endFrameTextBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of endFrameTextBox as text
%        str2double(get(hObject,'String')) returns contents of endFrameTextBox as a double




% --- Executes on button press in showProgressCheckbox.
function showProgressCheckbox_Callback(hObject, eventdata, handles)
% hObject    handle to showProgressCheckbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of showProgressCheckbox




% --- Executes on selection change in computedDiffusionCoefficientsListBox.
function computedDiffusionCoefficientsListBox_Callback(hObject, eventdata, handles)
% hObject    handle to computedDiffusionCoefficientsListBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns computedDiffusionCoefficientsListBox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from computedDiffusionCoefficientsListBox


% --- Executes during object creation, after setting all properties.
function computedDiffusionCoefficientsListBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to computedDiffusionCoefficientsListBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


