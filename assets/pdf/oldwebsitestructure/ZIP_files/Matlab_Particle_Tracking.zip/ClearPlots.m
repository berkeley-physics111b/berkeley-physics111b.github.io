   

% -------------------------------------------------------------------------------------
function ClearPlots(handles)
    axes(handles.trajectoryPlot);                                           % make the trajectory plot active
    cla;                                                                    % clear plot area
    axes(handles.histogramPlot);
    cla;       
    set(handles.computedDiffusionCoefficientsListBox, 'String', {});
    axes(handles.histogramPlot);
    cla;
