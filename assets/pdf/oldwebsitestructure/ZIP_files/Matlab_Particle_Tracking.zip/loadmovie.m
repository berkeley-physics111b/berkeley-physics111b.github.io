function out = loadmovie( moviePath )
% Reads a sequence of frames captured by Octopus111
% Argument is the root name of the movie
% Expects the movie to be in the folder: ~\Movies\<MovieName>
% Results returned in array "movie"

slashes = findstr('\', moviePath)
lastSlash=max(slashes)
movieName=moviePath(lastSlash+1:length(moviePath))

fileNames = importdata(strcat(moviePath, '\', movieName, ' frames.txt'));

movieLength = length(fileNames);
colormap('gray');

for i = 1: movieLength
    movie(:,:,i) = imread(strcat(moviePath, '\', char(fileNames(i))));
    imagesc(movie(:,:,i));
    title(char(fileNames(i)));
    drawnow;
end

out = movie;