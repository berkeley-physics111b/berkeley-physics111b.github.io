function Movie = ProcessFrame(Movie, FrameNumber, Parameters, ComputeTrajectories)
% Movie input movie structure
% FrameNumber index of frame to process
% Parameters processing parameters structure
% Set to true in order to enable computing trajectories; otherwise, only
% filtering is executed

    % compute the particle radius in microns
    r = Parameters.lobject * 1E-9 / 2;
    
    % compute the particle diameter in pixels
    particleDiameterPixels = round(Parameters.lobject / Parameters.distanceScaleFactor);
    if particleDiameterPixels < 1
        particleDiameterPixels = 1;
    end

    % Compute theoretical value of D from particle diameter, viscoisty
    % (eta), and kBT
    Movie.objectDiameter = Parameters.lobject;
    kBT  = 1.38e-23 * 300;
    Movie.dTheoretical = kBT / (6 * pi * Parameters.eta / 1E6 * r);
    
    % extract frame from input movie (must be uint8 intensity)
    frame = Movie.inputMovie(:,:,FrameNumber);                            
    
    % subtract average value from frame if option selected
    if(Parameters.subtractAverage)
        subtractedFrame = frame - Movie.averageFrame;
        minValue = min(min(subtractedFrame));
        subtractedFrame = subtractedFrame - (minValue - 16);
    % otherwise do not modify frame
    else
        subtractedFrame = frame;
    end
    
    % determine if frame needs to be inverted (motion tracker wants to see
    % light particles on a dark background). note that frame has already
    % been scaled to full range (16-235) when the movie was read in
    if(mean(mean(frame)) >= 128)
        subtractedFrame = 255 - subtractedFrame;
    end
    
    % add the processed frame to the movie
    Movie.subtractedMovie(:,:,FrameNumber) = subtractedFrame;
    
    % bandpass filter the frame  
    % see the documentation for bpass for details
    if(particleDiameterPixels > 1)
        filteredFrame = bpass(subtractedFrame, Parameters.lnoise, particleDiameterPixels);
    else
        filteredFrame = subtractedFrame;
    end
    
    % rescale the output range from the filter and add the resulting frame
    %  to the filtered movie
    minValue = min(min(min(filteredFrame)));
    maxValue = max(max(max(filteredFrame)));
    range = maxValue - minValue;
    filteredFrame = uint8(((filteredFrame).*(234/range)) + 16);
    Movie.filteredMovie(:,:,FrameNumber) = filteredFrame;
    
    % compute the threshold for converting the frame to bilevel
    average = mean(mean(filteredFrame));
    stdev = std(reshape(filteredFrame, 1, numel(filteredFrame))); % convert to a 1 dimensionsl array to compute stdev
    stdev = max(Parameters.minimumDeviation,stdev);                            % this prevents the gain from getting turned up too high on blank frames
    threshold = double(average + Parameters.standardDeviations * stdev)/(256);
    
    % convert the frame to bilevel and add the processed frame to the
    % bilevel movie
    bilevelFrame = im2bw(filteredFrame, threshold);
    Movie.bilevelMovie(:,:,FrameNumber)=bilevelFrame;
    
    % ---- clean up the movie ----
    % compute the minimum area in pixels
    minimumArea = round(pi * (Parameters.minimumSize / Parameters.distanceScaleFactor / 2)^2);
    cleanFrame = bwareaopen(bilevelFrame, minimumArea);  % remove objects below minimum size
    cleanFrame = imfill(cleanFrame, 'holes');                            % fill holes in objects
    cleanFrame = imclearborder(cleanFrame, 4);                           % remove objects touching borders
    Movie.cleanMovie(:,:,FrameNumber) = cleanFrame;
    
    % locate centers of objects in frame
    [boundaries, labelarray] = bwboundaries(cleanFrame, 'noholes');
    stats = regionprops(labelarray, 'Area', 'Centroid');

    if(~isfield(Movie, 'centers'))
        Movie.centers = [];
    end

    for k=1:length(boundaries)
        xycentroid = [ stats(k).Centroid FrameNumber ];
        Movie.centers = cat(1, Movie.centers, xycentroid);
    end
    
    % compute trajectories and diffusion coefficients
    % place the results in a cellular array of particles
    Movie.particle = {};                                                    % initialize particle info cell array
    
    % the following parameters control the operation of the
    % assemble_trajectories routine
    % there is currently no way to set them in the UI -- mostly because
    % they are hard to explain and there is enough going on already
    trajectoryParameters.mem = 4;
    trajectoryParameters.good = 8;
    trajectoryParameters.dim = 2; 
    trajectoryParameters.quiet = 0;

    if(ComputeTrajectories)                                                 % only compute if option selected
        if(length(Movie.centers > 0))                                       % if there are no centers, nothing to compute
            % ensure that there are enough frames (at least
            % trajectoryParameters.good) to bother doing the computation
            if(min(Movie.centers(:,3)) < max(Movie.centers(:,3))) 
                % see assemble_trajectories documentation details
                trajectories = assemble_trajectories( ...
                    Movie.centers, ...
                    Parameters.maximumDisplacement / Parameters.distanceScaleFactor , ...
                    trajectoryParameters);

                if(length(trajectories) > 0)                                % test to see if there are any valid trajectories
                    % determine the size of the array needed to hold the particle tracks
                    maxparticles = max(trajectories(:,4));                  % fourth column contains the particle index
                    nframes = size(Movie.inputMovie,3);

                    sortedTrajectories = cell(nframes, maxparticles);       % create a cell array to hold the particle positions

                    % fill in the cell array by stepping through each element in trajectories
                    dataPointCount = size(trajectories, 1);                 % total number of data points
                    
                    for i=1:dataPointCount
                       framenum = trajectories(i,3);
                       particleIndex = trajectories(i,4);
                       position = trajectories(i,1:3);
                       sortedTrajectories{framenum, particleIndex} = [position];
                    end
                    
                    for i=1:maxparticles
                        particle = struct();
                        temp = cell2mat(sortedTrajectories(:,i));           % extract ith position vector (x,y,frame)
                        n = size(temp, 1);
                        
                        if(n > 2)

                            particle.centers = struct(                  ...
                                'x', temp(:,1),                         ...
                                'y', temp(:,2),                         ...
                                'frame', temp(:,3));

                            % subtract off initial positions for displacement
                            % squared computation
                            temp(:,1) = temp(:,1) - temp(1,1);                  % subtract the initial X position
                            temp(:,2) = temp(:,2) - temp(1,2);                  % subtract the initial Y position

                            % compute histograms of displacements
                            deltaX = (temp(2:n,1) - temp(1:n-1,1)) * Parameters.distanceScaleFactor * 1E-9;
                            deltaY = (temp(2:n,2) - temp(1:n-1,2)) * Parameters.distanceScaleFactor * 1E-9;
                            smallestDelta = min([deltaX; deltaY]);
                            biggestDelta = max([deltaX; deltaY]);
                            binSpacing = (biggestDelta - smallestDelta) / round(n / 3);
                            bins = smallestDelta:binSpacing:biggestDelta;
                            particle.displacementHistogram.x = histc(deltaX, bins);
                            particle.displacementHistogram.y = histc(deltaY, bins);
                            particle.displacementHistogram.bins = bins;

                            % compute displacement^2 vector
                            dSquared = (Parameters.distanceScaleFactor * 1E-9) ^ 2 *       ...
                                       (temp(:,1).^2 + temp(:,2).^2);

                            % create the time axis for  displacement squared
                            % vector
                            time = transpose(0:(Parameters.timestep*1E-3):(n-1)*(Parameters.timestep*1e-3));

                            % copy the displacment vector to the particle structure
                            particle.displacementSquared =              ...
                                struct( 'time', time,                   ...
                                        'frame', temp(:,3),             ...
                                        'displacementSquared', dSquared);

                            % ---------- linear regression method
                            % compute statistics
                            % variance and standard deviation of displacement
                            % squared
                            particle.varianceDisplacementSquared = var(dSquared); % sigma^2 of displacement^2 vector
                            particle.deviationDisplacementSquared =     ...
                                sqrt(particle.varianceDisplacementSquared);

                            % variance and standard deviation of time axis
                            particle.varianceTime = var(time);                  % sigma^2 of time vector
                            particle.deviationTime = sqrt(particle.varianceTime);

                            % correlation coefficient of displacement squared
                            % vs time and r squared 
                            r = corrcoef(dSquared, time);
                            r = r(1,2);
                            particle.correlationCoefficient = r;
                            particle.rSquared = particle.correlationCoefficient^2;

                            % compute the slope of a least squares best fit
                            % line -- slope of the line is mean squared displacement 
                            % slope = r * Sy / Sx for linear regression
                            slope = particle.correlationCoefficient * ...
                                    particle.deviationDisplacementSquared / ...
                                    particle.deviationTime;
                            particle.diffusionCoefficientLeastSquaresMethod = slope / 4;

                            % compute standard error = 
                            % Sy * sqrt((1-r^2)(n-1)/(n-2))
                            standardLinearRegressionError =                 ...
                                    particle.deviationDisplacementSquared * ...
                                    sqrt((1 - r^2) * (n - 1) / (n - 2));

                            % compute the uncertainty in the slope
                            slopeError = standardLinearRegressionError /    ...
                                ((particle.deviationTime * sqrt(n - 1)));
                            particle.uncertaintyLeastSquaresMethod = slopeError/4;

                            % ----------- direct evaluation (average d^2) method
                            % compute delta displacement squared
                            particle.deltaDisplacementSquared = deltaX.^2 + deltaY.^2;
                            particle.averageDisplacementSquared = ...
                                sum(particle.deltaDisplacementSquared) / ...
                                    (n * Parameters.timestep * 1E-3);
                            slope = particle.averageDisplacementSquared;
                            particle.diffusionCoefficientAverageMethod = particle.averageDisplacementSquared / 4;

                            % compute standard error
                            particle.uncertaintyAverageMethod = sqrt( ...
                                var(particle.deltaDisplacementSquared)/ ...
                                (n-1))                                      % n-1 because number of frames is reduced by one

                            % line for graph
                            % This is CONFUSING -- need to rename -- this
                            % is the line based on the average d^2 method
                            % of evaluation
                            y = slope * time;
                            particle.bestFitLine =                          ...
                                struct('time', time,                        ...
                                        'displacementSquared', y);

                            Movie.particle{i} = particle;
                        end
                    end
                end
            end
       end
    end

