function out = trackparticles(movie, centers, maximumDisplacement)
% Usage: trackparticles(movie, centers, maximumDisplacement)
% Returns an array of particle tracks: traj(frameNumber, particleIndex) =
% movie (used for display only) is the original movie array
% centers is the array of centers returned from findobjects
% maximumDisplacement is the largest allowed frame-to-frame change in
% position
% position

% see assemble_trajectories documentation for parameter definitions and
% function usage
param.mem = 4;
param.good = 8;
param.dim = 2; 
param.quiet = 0;

trajectories = assemble_trajectories(centers, maximumDisplacement, param);

% determine the size of the array to hold the particle tracks
maxparticles = max(trajectories(:,4));
nparticles = size(trajectories, 1);
nframes = size(movie,3);

% create a cell array to hold the particle positions
traj = cell(nframes, maxparticles);

% fill in the cell array by stepping through each element in trajectories
for k=1:nparticles
   framenum = trajectories(k,3);
   particleIndex = trajectories(k,4);
   position = trajectories(k,1:2);
   traj{framenum, particleIndex} = [position];
end

clear trajectories;

nparticles = size(traj, 2);


out = traj                                      % return the cell array of particle positions
