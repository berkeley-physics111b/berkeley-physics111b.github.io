function out = findobjects(movie)
% usage: out = findobjects(movie)
%
% returns an array of object centers indexed by frame
%
% movie is the input movie

width = size(movie,1);
height = size(movie,2);
frameCount = size(movie,3);

centers = [];

for i=1:frameCount
    % get frame i
    frame = movie(:,:,i);

    [boundaries, labelarray] = bwboundaries(frame, 'noholes');

    stats = regionprops(labelarray, 'Area', 'Centroid');

    for k=1:length(boundaries)

        % obtain (x,y) boundary coordinates corresponding to the kth object
        boundary = boundaries{k};

        xycentroid = stats(k).Centroid;
        centers = cat(1, centers, [xycentroid i]);
    end


    
end
out = centers;

