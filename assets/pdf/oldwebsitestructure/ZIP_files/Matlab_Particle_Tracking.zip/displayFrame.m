
% --------------------------------------------------------------------
function displayFrame(handles, frameNumber, m)
% handles       handles of display window
% frameNumber   index of frame to display
% m             movie data structure

    % create array of colors for identifying particles
    colors = ['y' 'c' 'g' 'r' 'm' 'b'];
    
    % create colormap -- movies shoudl be 8-bit grayscale, normalized to
    % 16-235
    gray256 = [ transpose(0:255) transpose(0:255) transpose(0:255) ] / 255;
    colormap(gray256);                                                  % make colormap active

    % display raw frame
    if(FrameExists(m, 'inputMovie', frameNumber))
        axes(handles.rawAxes);                                          % make raw movie axes active
        image(m.inputMovie(:,:,frameNumber));                           % display the frame
        title(char(m.fileNames(frameNumber)));                          % set title to name of file displayed

        % plot center markers for current frame prefer data from
        % trajectories (in order to match marker colors and only include
        % data from tracked particles-- otherwise, use centers and mark
        % them all in red
        if(isfield(m, 'particle'))                                      % check if trajectrories computed
            hold on;
            for i=1:length(m.particle)                              % iterate through each particle's data
                particle = m.particle{i};
                lineSpec = strcat(colors(mod(i-1,length(colors))+1), 'x');  % format marker color/style
                plot(   particle.centers.x, ...
                        particle.centers.y, ...
                        lineSpec);                 % plot the marker
            end                                                         % if(isfield(m, 'trajectories'))
            hold off;
        else                                                            % no trajectories computed -- plot centers
            if(isfield(m, 'centers'))                                   % check to see if any centers founr
                if(size(m.centers,1) > 0)
                    hold on;
                        plot(m.centers(:,1), m.centers(:,2), 'xr');     % plot red crosses at each center point
                    hold off;
                end                                                     % if(size(m.centers,1) > 0)
            end                                                         % if(isfield(m, 'centers'))
        end                                                             % else
    end                                                                 % if(FrameExists(m, 'inputMovie', frameNumber))
    
    % plot the filtered version of the movie
    if(FrameExists(m, 'filteredMovie', frameNumber))
        axes(handles.filteredAxes);                                     % make filtered movie axes active
        colormap(gray256);
        image(m.filteredMovie(:,:,frameNumber));                        % display the selected frame
        title(strcat('Filtered Frame ', num2str(frameNumber)));
    end
    
    if(FrameExists(m, 'subtractedMovie', frameNumber))
        axes(handles.subtractedAxes);                                   % make filtered movie axes active
        colormap(gray256);
        image(m.subtractedMovie(:,:,frameNumber));                                         % display the frame
        title(strcat('Subtracted Frame ', num2str(frameNumber)));
    end
    
     if(isfield(m, 'averageFrame'))
        axes(handles.averageAxes);                                 % make filtered movie axes active
        colormap(gray256);
        image(m.averageFrame);                                         % display the frame
        title(strcat('Average'));
     end

    if(FrameExists(m, 'bilevelMovie', frameNumber))
        axes(handles.bilevelAxes);                                 % make filtered movie axes active
        colormap(gray256);
        imagesc(m.bilevelMovie(:,:,frameNumber));                                         % display the frame
        title(strcat('Bilevel Frame', num2str(frameNumber)));
    end

    if(FrameExists(m, 'cleanMovie', frameNumber))
        axes(handles.cleanAxes);                                            % make filtered movie axes active
        colormap(gray256);
        imagesc(m.cleanMovie(:,:,frameNumber));                             % display the frame
        title(strcat('Clean Frame', num2str(frameNumber)));
    
        if(isfield(m, 'particle'))                                      % check if trajectrories computed
            hold on;
            for i=1:length(m.particle)                              % iterate through each particle's data
                particle = m.particle{i};
                lineSpec = strcat(colors(mod(i-1,length(colors))+1), 'x-');  % format marker color/style
                plot(   particle.centers.x, ...
                        particle.centers.y, ...
                        lineSpec);                                          % plot the marker
            end                                                         % if(isfield(m, 'trajectories'))
            hold off;
        else                                                            % no trajectories computed -- plot centers
            if(isfield(m, 'centers'))                                   % check to see if any centers founr
                if(size(m.centers,1) > 0)
                    hold on;
                        plot(m.centers(:,1), m.centers(:,2), 'xr');     % plot red crosses at each center point
                    hold off;
                end                                                     % if(size(m.centers,1) > 0)
            end                                                         % if(isfield(m, 'centers'))
        end                                                             % else
    end
    


% -------------------------------------------------------------------------------------
% Test for existance of a particular movie frame
function out = FrameExists( Movie, FieldName, FrameNumber )
% Movie -- input movie structire
% FieldName -- name of the datafield containing the movie
% FrameNumber -- number of desired frame

    if( isfield(Movie, FieldName) )
        out = size(getfield(Movie, FieldName), 3) >= FrameNumber;
    else
        out = false;
    end
    

