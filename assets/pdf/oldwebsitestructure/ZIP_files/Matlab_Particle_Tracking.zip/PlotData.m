function PlotData(handles, FrameNumber, m)
    % create array of colors for identifying particles
    colors = ['y' 'c' 'g' 'r' 'm' 'b'];

    % plot the displacement squared versus time
    axes(handles.trajectoryPlot);                                           % make the trajectory plot active
    cla;                                                                    % clear plot area
    title('Displacement Squared');
    axes(handles.histogramPlot);
    cla;       
    title('Histogram');
    set(handles.computedDiffusionCoefficientsListBox, 'String', {});
    dcstring = {};

    if(isfield(m, 'particle'))                                                  % test to see particle data computed
        for i=1:length(m.particle)                                              % iterate through all particles
            axes(handles.trajectoryPlot);                                           % make the trajectory plot active
            hold on;
            particle = m.particle{i};
            plot(   particle.displacementSquared.time,         ...
                    particle.displacementSquared.displacementSquared, ...                               ...
                    colors(mod(i-1,length(colors))+1));
            for j=1:length(particle.displacementSquared.time)
              if(particle.displacementSquared.frame(j)==i)
                  plot( particle.displacementSquared.time(j), ... 
                        particle.displacementSquared.displacementSquared(j), ...          % hilight the data for the current frame
                        'xk', 'LineWidth', 2); 
              end
            end
            
            % plot the best fit line
            plot(   particle.bestFitLine.time, ...
                    particle.bestFitLine.displacementSquared, ...                         % plot the best fir line
                    strcat(colors(mod(i-1,length(colors))+1), ':')); 
            % TODO this is a BUG -- similar to one above
            % indexed, but rather top shifted if statement is a temporary
            % HACK to prevent crashing
%             if(size(BestFitLine,1) >= frameNumber)
%                 plot(BestFitLine(frameNumber,1), BestFitLine(frameNumber,2), ...    % mark data for the current frame
%                         'xk', 'LineWidth', 2);     
%             end
            hold off;
            axis auto;
            
            % plot displacement histogram
            axes(handles.histogramPlot);
            hold on;
                plot(particle.displacementHistogram.bins, particle.displacementHistogram.x, strcat(colors(mod(i-1,length(colors))+1), ':')');
                plot(particle.displacementHistogram.bins, particle.displacementHistogram.y, strcat(colors(mod(i-1,length(colors))+1), '--'));
            hold off;
            drawnow;
           
            % display the theoretical value of D
            if(isfield(m, 'dTheoretical'))
                dcstring{length(dcstring) + 1} = strcat( ...
                    'Theoretical D ', num2str(m.dTheoretical));
            end
    
             % display the computed diffussion coefficient for the particle
            if(isfield(particle, 'diffusionCoefficientAverageMethod'))
                dcstring{length(dcstring) + 1} = strcat( ...
                    'Particle ', num2str(i));
                dcstring{length(dcstring) + 1} = strcat( ...
                    'D (avg method): ', num2str(particle.diffusionCoefficientAverageMethod, 3));
                dcstring{length(dcstring) + 1} = strcat( ...
                    'Std. Error: ', num2str(particle.uncertaintyAverageMethod, 3));
                dcstring{length(dcstring) + 1} = strcat( ...
                    'D (lr method): ', num2str(particle.diffusionCoefficientLeastSquaresMethod, 3));
                dcstring{length(dcstring) + 1} = strcat( ...
                    'Std. Error: ', num2str(particle.uncertaintyLeastSquaresMethod, 3));
                set(handles.computedDiffusionCoefficientsListBox, 'String', dcstring);
            end
       end
        
        
        
    end
    
    
