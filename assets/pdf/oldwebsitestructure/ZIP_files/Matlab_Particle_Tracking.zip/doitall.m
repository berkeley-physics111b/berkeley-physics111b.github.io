function out = doitall( movieName, invert, noiseDiameter, objectDiameter, standardDeviations, minimumDeviation, minimumSize, maximumDisplacement )
% Usage: doitall( movieName, invert, noiseDiameter, objectLength, standardDeviations, 
%                   minimumDeviation, minimumSize, maximumDisplacement )
% returns an array of particle trajectories
%
% movieName is a string with the name of the movie to analyze
%
% invert = 0 for bright particles on a dark background; invert = 1 for
% dark particles on a bright background
%
% noiseDiameter is the characteristic size of the noise used in the
% bandpass filter
%
% objectDiameter is the characteristic size of the objects used in the
% bandbass filter
%
% standardDeviations is the number of standard deviations above the average
% value to set the threshold for converting to bilevel image
%
% minimumDeviation is the minimum value of standard deviation to use in
% odger to prevent finding false objects on blank frames
%
% minimumSize is the smallest object that will be recognized
%
% maximumDisplacement is the largest frame-to-frame change in position that
% will be tracked

movie = readmovie(movieName);

if( invert == 1)
    movie = 256 - movie;
end

pmovie = filtermovie(movie, noiseDiameter, objectDiameter);
pmovie = bilevelmovie(pmovie, standardDeviations, minimumDeviation);
pmovie = cleanupedges(pmovie, minimumSize);
centers = findobjects(pmovie);
trajectories = trackparticles(movie, centers, maximumDisplacement);
out = trajectories;