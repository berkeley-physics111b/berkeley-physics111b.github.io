function out = bilevelmovie(movie, standardDeviations, minimumDeviation)
% usage: out = bilevelmovie(movie, standardDeviations, minimumDeviation)
%
% returns a bilevel movie
%
% movie is the input movie
% standartDeviations is the number of standard deviations abouv the average
%   value to set the threshold
% minimumDeviation is a minimum value for the standart deviation that helps
%   prevent detecting objects in blank frames

width = size(movie,1);
height = size(movie,2);
frameCount = size(movie,3);

colormap gray;

for i=1:frameCount
    % get frame i
    frame = movie(:,:,i);

    average = mean(mean(frame));
    stdev = std(reshape(frame, 1, width*height));
    
    % this prevents the gain from getting turned up too high on blank
    % frames
    stdev = max(minimumDeviation,stdev);

    % cutoff in range 0-1?
    cutoff = double(average + standardDeviations * stdev)/(2^16-1);
    frame = im2bw(uint16(frame), cutoff);
    image(frame * 255);
    title(strcat('bilevel frame ', num2str(i)));
    drawnow;
    movie(:,:,i) = frame;
    
end
out = movie;
