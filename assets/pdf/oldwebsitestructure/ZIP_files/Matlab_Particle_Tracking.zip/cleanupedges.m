function out = cleanupedges(movie, minimumSize)

width = size(movie,1);
height = size(movie,2);
frameCount = size(movie,3);

colormap gray;

for i=1:frameCount
    % get frame i
    frame = movie(:,:,i);

    % remove objects (interconnected pixels) below a certain size
    frame = bwareaopen(frame, minimumSize);

    % fill holes in objects
    frame = imfill(frame, 'holes');

    % remove objects on borders
    frame = imclearborder(frame, 4);

    image(255*frame);
    title(strcat('Cleanup Frame ', num2str(i)));
    drawnow;
    movie(:,:,i) = frame;
    
end
out = movie;

