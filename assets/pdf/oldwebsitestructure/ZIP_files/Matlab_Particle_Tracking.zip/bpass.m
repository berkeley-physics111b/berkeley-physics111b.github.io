%; ********** start of bpass.pro
%;
%; see http://www.physics.emory.edu/~weeks/idl
%;  for further documentation
%;
%;+
%; NAME:
%;		bpass
%; PURPOSE:
%;		Implements a real-space bandpass filter which suppress 
%;		pixel noise and slow-scale image variations while 
%;		retaining information of a characteristic size.
%;
%; CATEGORY:
%;		Image Processing
%; CALLING SEQUENCE:
%;		res = dgfilter( image, lnoise, lobject )
%; INPUTS:
%;		image:	The two-dimensional array to be filtered.
%;		lnoise: Characteristic lengthscale of noise in pixels.
%;			Additive noise averaged over this length should
%;			vanish. May assume any positive floating value.
%;		lobject: A length in pixels somewhat larger than a typical
%;			object. Must be an odd valued integer at least twice lnoise
%; OUTPUTS:
%;		res:	filtered image.
%; PROCEDURE:
%;		simple 'wavelet' convolution yields spatial bandpass filtering.

% assumes image is uint16

function res = bpass(image, lnoise, lobject, field)

width = size(image, 1);
height = size(image ,2);
nf = size(image, 3);
 
b = double(lnoise);
w = round(lobject);
N = 2*w + 1;

for i=1:N
    r(i) = (i-1 - w)/(2 * b);
end

xpt = exp(-1 * (r.^2));
xpt = xpt / sum(xpt);
factor = sum(xpt.^2) - (1/N);

gx = xpt;
gy = transpose(gx);

for i=1:N
    bx(i) = -1/N;
end
by = transpose(bx);

%if (field) then begin
%	if N mod 4 eq 1 then indx = 2*indgen(w+1)$
%			else indx = 1+ (2*indgen(w))
%	gy = gy(indx)
%	gy = gy/total(gy)
%
%	nn = n_elements(indx)
%	by = fltarr(nn) - 1./nn
%endif

% do x and y convolutions
for i=1:nf
    g = imfilter(single(image(:,:,i)), gx, 'same', 'replicate', 'conv');
	g = imfilter(g, gy, 'same', 'replicate', 'conv');
    
	b = imfilter(single(image(:,:,i)), bx, 'same', 'replicate', 'conv');
	b = imfilter(b, by, 'same', 'replicate', 'conv');
    
	res = g-b;
end






