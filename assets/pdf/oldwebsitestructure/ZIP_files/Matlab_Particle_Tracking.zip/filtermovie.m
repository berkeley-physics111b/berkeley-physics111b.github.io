function out = filtermovie( movie, lnoise, lobject )
% usage: out = filtermovie( movie, lnoise, lobject )
%
% returns the filtered movie
%
% movie is the input movie
% lnoise is the characteristic length of noise
% lobject is the characteristic length of particles to be tracked

% get the parameters of the movie
width = size(movie,1);
height = size(movie,2);
frameCount = size(movie,3);

% set up the display window for grayscale
colormap gray;

for i=1:frameCount                                      % iterate through each frame of the movie
    frame = movie(:,:,i);                               % get the indexed frame
    frame = bpass(frame, lnoise, lobject);              % apply the bandpass filter
    
    % display the frame
    title(strcat('Filtering Frame ', num2str(i)));
    imagesc(frame);
    drawnow;

    movie(:,:,i) = frame;                               % update the movie with the filtered frame
end

out = movie;                                            % return the filtered movie