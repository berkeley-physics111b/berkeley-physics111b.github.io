% --------------------------------------------------------------------
function ClearFrames(handles)
    axes(handles.rawAxes);
    cla;       
    axes(handles.averageAxes);
    cla;       
    axes(handles.subtractedAxes);
    cla;       
    axes(handles.filteredAxes);
    cla;       
    axes(handles.bilevelAxes);
    cla;       
    axes(handles.cleanAxes);
    cla;    