using System;
using System.Collections.Generic;
using System.Text;

namespace StageControl1Demo {
    public static class MusicNotes {

        private static string[] noteLetters = { "A", "Bf", "B", "C", "Df", "D", "Ef", "E", "F", "Fs", "G", "Ab" };

        public static int MakeNote(string noteString, int octave) {
            int indexOf = Array.IndexOf(noteLetters, noteString);
            return (int)Math.Round(Math.Pow(2.0, indexOf / 12.0 + octave) * 440.0);
        }
    }
}
