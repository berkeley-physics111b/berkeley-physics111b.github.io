using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Ports;
using System.Text;
using System.Windows.Forms;

namespace StageControl1Demo {
    public partial class Form1 : Form {

        SerialPort serial1 = new SerialPort("COM1", 19200, Parity.None, 8, StopBits.One);
        char[] buffer1 = new char[128];

        private void Form1_Load(object sender, EventArgs e) {
            serial1.ReadBufferSize = 128;
            serial1.DtrEnable = true;
            serial1.RtsEnable = true;
            serial1.ErrorReceived += new SerialErrorReceivedEventHandler(serial1_ErrorReceived);
            serial1.Encoding = ASCIIEncoding.ASCII;
            serial1.NewLine = Environment.NewLine;
            //serial1.Handshake = Handshake.RequestToSend;

            serial1.Open();

        }

        void serial1_ErrorReceived(object sender, SerialErrorReceivedEventArgs e) {
            Trace.WriteLine("Serial Communication Error");
        }

        public Form1() {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e) {
            if (serial1.IsOpen) {
                serialWrite(serial1, "DEF");
                serialWrite(serial1, "JOF");
                serialWrite(serial1, "CHL a1=0");
                serialWrite(serial1, "MPV a1 1=0");
                serialWrite(serial1, "VEL a1 1=30");
                serialWrite(serial1, "ACC a1 1=5000");
                serialWrite(serial1, "MON");
                serialWrite(serial1, "REV a1");
                serialWrite(serial1, "GO");
            } else {
                Trace.WriteLine("Error");
            }
        }

        private void serialWrite(SerialPort serialP, string command) {
            serialP.WriteLine(command);
            serialP.Read(buffer1, 0, 128);
            string outStr = new string(buffer1, 0, 128);
            Trace.WriteLine("");
            Trace.WriteLine("#" + command);
            Trace.WriteLine(outStr);
            buffer1 = new char[128];
            serialP.DiscardInBuffer();
            System.Threading.Thread.Sleep(35);
        }

        private void serialWriteCheck(SerialPort serialP, string command)
        {
            bool doAgain = false;
            serialP.WriteLine(command);
            serialP.Read(buffer1, 0, 128);
            string outStr = new string(buffer1, 0, 128);
            Trace.WriteLine("");
            Trace.WriteLine("#" + command);
            Trace.WriteLine(outStr);
            buffer1 = new char[128];
            while (outStr.LastIndexOf("?") != -1 || outStr.LastIndexOf("UN") != -1 || outStr.LastIndexOf("MMA") != -1 || doAgain)
            {
                Trace.WriteLine("Error. Trying Again " + command);
                System.Threading.Thread.Sleep(250);
                serialP.WriteLine(command);
                serialP.Read(buffer1, 0, 128);
                outStr = new string(buffer1, 0, 128);
                Trace.WriteLine("");
                Trace.WriteLine(outStr);
                buffer1 = new char[128];
                doAgain = false;
                if (!doAgain && (outStr.LastIndexOf("?") != -1 || outStr.LastIndexOf("UN") != -1 || outStr.LastIndexOf("MMA") != -1))
                {
                    doAgain = true;
                }
            }
            buffer1 = new char[128];
            serialP.DiscardInBuffer();
            System.Threading.Thread.Sleep(35);
        }

        private void buttonUP_Click(object sender, EventArgs e) {
            if (serial1.IsOpen) {
                serialWrite(serial1, "rel a1 10 g");
            } else {
                Trace.WriteLine("Error");
            }
        }

        private void buttonDOWN_Click(object sender, EventArgs e) {
            if (serial1.IsOpen) {
                serialWrite(serial1, "STO");
            } else {
                Trace.WriteLine("Error");
            }
        }

        private void button2_Click(object sender, EventArgs e) {
            serialWrite(serial1, "JOF");
            serialWrite(serial1, "JON");
        }

        private void button3_Click(object sender, EventArgs e) {
            serialWrite(serial1, textBox1.Text);
        }

        private void button4_Click(object sender, EventArgs e) {
            serialWrite(serial1, "DEF");
            //serialWrite(serial1, "JOF");
            serialWrite(serial1, "CHL a1=0");
            serialWrite(serial1, "CHL a1=0");
            serialWrite(serial1, "CHL a1=0");
            serialWrite(serial1, "MPV a1 1=0");
            //serialWrite(serial1, "VEL a1 1=440");
            serialWrite(serial1, "ACC a1 1=5000");
            //serialWrite(serial1, "REV a1");
            //serialWrite(seriald1, "REV a1");
            //serialWrite(serial1, "GO");
            serialWrite(serial1, "REL a1 1 g");
        }

        bool playing = false;

        private void listen_KeyDown(object sender, KeyEventArgs e) {

            if (!playing) {
                playing = true;
                Trace.WriteLine("Pressed " + e.KeyData.ToString());

                serialWriteCheck(serial1, "REV a1");
                serialWriteCheck(serial1, "REV a1");

                Keys currentLetter = e.KeyData;
                switch (currentLetter) {
                    case Keys.A:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("C", -1).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("C", -1).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.S:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("D", -1).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("D", -1).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.D:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("E", -1).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("E", -1).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.F:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("F", -1).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("F", -1).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.G:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("G", -1).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("G", -1).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.H:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("A", 0).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("A", 0).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.J:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("B", 0).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("B", 0).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.K:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("C", 0).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("C", 0).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    case Keys.L:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("D", 0).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("D", 0).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                    default:
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("C", -2).ToString());
                        serialWriteCheck(serial1, "VEL a1 1=" + MusicNotes.MakeNote("C", -2).ToString());
                        serialWriteCheck(serial1, "GO");
                        break;
                }
            }
        }

        private void listen_KeyUp(object sender, KeyEventArgs e) {
            playing = false;
            serialWriteCheck(serial1, "STO");
        }
    }
}