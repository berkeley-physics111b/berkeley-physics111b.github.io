using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;
using GoodStuff;

namespace HelloWorld
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Dictionary<string, object> o = new Dictionary<string, object>();
            GoodObjectBuilder.ReadFile("hello.xml");
            GoodWindow gw2 = ObjectManager.Get("First Window") as GoodWindow;
            //GoodWindow gw3 = ObjectManager.Get("Second Window") as GoodWindow;
            Thread t2 = new Thread(new ThreadStart(gw2.Run));
            //Thread t3 = new Thread(new ThreadStart(gw3.Run));
            t2.Start();
            //t3.Start();

            //GoodWindow GW = ObjectManager.Get("Main Window2") as GoodWindow;
            //GW.Run();
        }
    }
}