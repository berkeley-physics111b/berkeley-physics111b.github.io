using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    public class GoodControlContainerBase : ContainerControl, IGoodControl {
        protected Control _control;
        protected Label _label;
        public string LabelText { get { return _label.Text; } set { _label.Text = value; } }
        protected int _charactersWide;
        public int CharactersWide {
            get { return _charactersWide; }
            set { _charactersWide = value; }
        }
        protected bool _updating;


        protected GoodVariable _variable;
        public GoodVariable GoodVariableBinding {
            get { return _variable; }
            set {
                Trace.WriteLine("GoodControl set to point to variable " + value.Name);
                _variable = value;
            }
        }

        public GoodControlContainerBase() {
            _label = new Label();
        }

        virtual public void Initialize() {
            _variable.ValueChanged += OnVariableChanged;

            LabelText = _variable.DisplayName + ":";
            _label.TextAlign = ContentAlignment.MiddleRight;
            _label.MaximumSize = _label.PreferredSize;

            _label.Location = new Point(
                Margin.Left,
                Margin.Top + Math.Max(0, (_control.Height - _label.Height) / 2));
            _control.Location = new Point(
                _label.Right + Padding.Horizontal,
                Margin.Top + Math.Max(0, (_label.Height - _control.Height) / 2));
            _control.Update();
            Size = new Size(
                _control.Right + Margin.Right,
                Math.Max(_label.Height, _control.Height) + Margin.Vertical);
            Controls.Add(_label);
            Controls.Add(_control);
        }

        virtual protected void OnVariableChanged(object sender, EventArgs args) {
        }


        #region IGoodControl Members

        Control IGoodControl.Control {
            get {
                return _control;
            }
/*            set {
                _control = value;
            }*/
        }


        IGoodVariable IGoodControl.GoodVariableBinding {
            get {
                return _control as IGoodVariable;
            }
            set {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        #endregion
    }

    public class GoodControlGroupBox : GroupBox, IGoodControl {
        protected GoodVariable _variable;
        public IGoodVariable GoodVariableBinding {
            get { return (IGoodVariable) _variable; }
            set {
                Trace.WriteLine("GoodControl set to point to variable " + value.Name);
                _variable = (GoodVariable) value;
            }
        }

        virtual public void Initialize() {
            _variable = new GoodVariable();
            _variable.ValueChanged += OnVariableChanged;
        }

        virtual protected void OnVariableChanged(object sender, EventArgs args) {
        }


        #region IGoodControl Members

        Control IGoodControl.Control {
            get { throw new Exception("The method or operation is not implemented."); }
//          set { throw new Exception("The method or operation is not implemented."); }
        }

        #endregion
    }
    public class GoodControl
    {
        protected Control _control;
        public Control Control
        {
            get { return _control; }
            set { _control = value; }
        }

        protected string _text;
        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }

        protected GoodVariable[] _gv;

        public void BindTo( string variableName )
        {
            BindTo( new string[1]{variableName} );
        }

        public void BindTo( params string[] variableNames)
        {
            _gv = new GoodVariable[variableNames.Length];
            for (int i = 0; i < variableNames.Length; ++i)
            {
                if(variableNames[i] != null)
                    _gv[i] = (GoodVariable)StateStore.Store[variableNames[i]];
                if(_gv[i] != null)
                    _gv[i].ValueChanged += OnVariableChanged;
            }
        }

        public virtual void Initialize()
        {
            OnVariableChanged(this, new EventArgs());
        }

        protected virtual void OnVariableChanged(object sender, EventArgs args)
        {
        }
    }



  /*  public interface IGoodControl
    {
        void Initialize();
        GoodVariable GoodVariableBinding { get; set; }
    }
*/
    

}
