﻿using System;
using System.Collections.Generic;

namespace GoodStuff
{
    public interface IGoodControl
    {
        void Initialize();
        IGoodVariable GoodVariableBinding { get; set;}
        System.Windows.Forms.Control Control { get; }
    }
}
