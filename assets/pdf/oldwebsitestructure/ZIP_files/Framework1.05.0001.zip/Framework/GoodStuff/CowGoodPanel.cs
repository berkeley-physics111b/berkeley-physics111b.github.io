using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace GoodStuff
{
    public class GoodPanel : Panel
    {
        GoodLayout _layout;

        public GoodPanel()
        {
            _layout = new GoodLayout(this);
            Size = new Size(10, 10);
            Margin = new Padding(7);
            Padding = new Padding(7);
        }

        public void Add(Control c)
        {
            Add(c, false);
        }

        public void Add(Control c, bool isHorizontal)
        {
            if (c != null)
            {
                Controls.Add(c);
                _layout.Add(c, isHorizontal);
            }
        }

        public new void PerformLayout()
        {
            _layout.PerformLayout();
            //base.PerformLayout();
        }
    }
}
