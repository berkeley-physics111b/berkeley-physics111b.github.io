using System;
using System.Collections.Specialized;
using System.Drawing;
using System.Threading;
using System.Text;


namespace GoodStuff
{
    public class StateStore
    {
        static ListDictionary      _store;

        static StateStore	_globalStateStore;
        public static StateStore Store
        {
            get { return _globalStateStore; }
        }

        static StateStore()
        {
	        _store = new ListDictionary();
        }
        public static StateStore GetStore()
        {
	        if(_globalStateStore == null)
		        _globalStateStore = new StateStore();
	        return _globalStateStore;
        }
        public object this[string i]
        {
            get
            {
                return GetVariable(i);
            }
            set
            {
                SetVariable(i, value);
            }
        }
        public void AddVariable(String key, Object initialValue)
        {
	        lock(_store.SyncRoot)
            {
    	        _store.Add(key, initialValue);
	        }
        }
        public void AddVariable(GoodVariable gv)
        {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodVariable<Size> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodVariable<Byte> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodNumericVariable<Byte> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodNumericVariable<Decimal> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodVariable<Rectangle> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodVariable<Bitmap> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodNumericVariable<UInt32> gv) {
            _store.Add(gv.Name, gv);
        }

        public void AddVariable(GoodVariable<EventHandler> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodVariable<string> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodVariable<uint> gv) {
            _store.Add(gv.Name, gv);
        }
        public void AddVariable(GoodVariable<bool> gv) {
            _store.Add(gv.Name, gv);
        } 
        public void SetVariable(String key, Object value)
        {
	        lock(_store.SyncRoot)
            {
	            _store[key] = value;
	        }
        }
        public Object GetVariable(String key)
        {
            Object o;
	        lock(_store.SyncRoot)
            {
	            o = _store[key];
	        }
	        return o;
        }

         public void Lock()
        {
	        Monitor.Enter(_store.SyncRoot);
        }
         public void Unlock()
        {
            Monitor.Enter(_store.SyncRoot);
        }

    }
}
