using System;
using System.Collections.Generic;
using System.Text;

namespace GoodStuff
{
    public class GoodSelection : GoodVariable<object>
    {
        object[] _choices;
        public object[] Choices
        {
            get { return _choices; }
            set { _choices = value; }
        }
    }
}
