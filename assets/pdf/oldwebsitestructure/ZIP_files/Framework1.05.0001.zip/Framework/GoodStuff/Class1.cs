using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public class bioLabinator
{
    FormCaptureControl fCControl;
    FormPassthru fPT;
    Camera chimaera;
    public FormCaptureControl FCaptureControl {
        get {
            return fCControl;
        }
        set {
            fCControl = value;
        }
    }
    public FormPassthru FPassThru {
        get {
            return fPT;
        }
        set {
            fPT = value;
        }
    }

    public Camera chimaera {
        get {
            return chimaera;
        }
        set {
            chimaera = value;
        }
    }
	public bioLabinator()
	{
    }
    public void Initialize() {
    }
}
