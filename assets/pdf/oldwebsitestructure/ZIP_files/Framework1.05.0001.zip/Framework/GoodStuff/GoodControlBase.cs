using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    public abstract class GoodControlBase : IGoodControl, IInitializable
    {
        //CURSOR3

        protected int _charactersWide;
        protected int pushIndex;
        public int CharactersWide {
            get { return _charactersWide; }
            set { _charactersWide = value; }
        }
        protected bool _updating;
        protected Control _control;
        public Control Control
        {
            get { return _control; }
            set { _control = value; }
        }

        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
/*        public void pBind(IGoodControl gCon) {
            if(_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase) gCon;
            pushPopIndex++;
        }*/

        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }
           


        protected string _text;
        public string Text {
            get { return _text; }
            set { _text = value; }
        }
        protected Dictionary<string, object> _parameterList;
        public Dictionary<string, object> ParameterList
        {
            get { return _parameterList; }
            set { _parameterList = value; }
        }

        public virtual void Initialize()
        {
            pushIndex = 0;
            _control = new Control();
            _parameterList = new Dictionary<string, object>();
//            OnVariableChanged(this, new EventArgs());
        }

        protected IGoodVariable _gv0;

        public void BindTo(string variableName) {
            BindTo(new string[1] { variableName });
        }

        public void BindTo(params string[] variableNames) {
            _gv = new GoodVariableBase[variableNames.Length];
            for (int i = 0; i < variableNames.Length; ++i) {
                if (variableNames[i] != null)
                    _gv[i] = (GoodVariableBase)StateStore.Store[variableNames[i]];
                if (_gv[i] != null)
                    _gv[i].ValueChanged += OnVariableChanged;
            }
        }

/*        public void pushBindTo(string variableName) {
            Array.Resize(ref _gv, _gv.Length + 1);
            if (variableName != null) {
                _gv[pushIndex] = (GoodVariable)StateStore.Store[variableName];
                pushIndex++;
            }
            if (_gv[pushIndex] != null)
                _gv[pushIndex].ValueChanged += OnVariableChanged;           
        }*/

        public GoodVariableBase popBindTo {
            get {
                if (_gv[pushIndex] != null) {
                    pushPopIndex--;
                }
                return _gv[pushPopIndex];
            }
        }

        public void IntInit(int junk) {
            Initialize();
        }
        abstract protected void OnVariableChanged(object sender, EventArgs args);

        public void Add(IGoodControl somethingToAdd) {
            if (!(somethingToAdd is Control)) {
                _control.Controls.Add(somethingToAdd.Control);
            } else {
                _control.Controls.Add((Control)somethingToAdd);
            }
        }
        protected string ParameterText(string key)
        {
            if(_parameterList.ContainsKey(key))
                return (string)_parameterList[key];
            else
                return null;
        }

        protected IGoodVariable ParameterVariable(string key)
        {
            if (_parameterList.ContainsKey(key))
            {
                IGoodVariable gv = _parameterList[key] as IGoodVariable;
                string s = _parameterList[key] as string;
                if (s != null)
                    return (IGoodVariable) StateStore.Store[s];
                else
                    return gv;
            }
            else
                return null;
       }

       protected IConvertible ParameterNumericVariable(string key)
       {
           if (_parameterList.ContainsKey(key))
               return (IConvertible)_parameterList[key];
           else
               return null;
       }


       #region IGoodControl Members

       public IGoodVariable GoodVariableBinding {
            get {
               return _gv0 as IGoodVariable;
            }
            set {
                _gv0 = (IGoodVariable) value;
            }
        }
        

       #endregion
   }


}
