using System;
using System.Collections.Generic;
using System.Text;

namespace GoodStuff
{
    class GoodForm
    {
    }
}
