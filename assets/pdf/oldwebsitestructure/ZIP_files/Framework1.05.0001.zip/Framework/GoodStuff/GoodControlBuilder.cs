using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml.Serialization;
using System.Reflection;
using System.Diagnostics;

namespace GoodStuff
{
    [XmlRoot("GoodPanel")]
    public class GoodPanelBuilder
    {
        [XmlElement("GoodControlBuilder")]
        public GoodControlBuilder[] ControlList;

        [XmlElement("SubPanel")]
        public GoodPanelBuilder[] SubPanel;

        static public GoodPanelBuilder GetControlListFromFile(string filename)
        {
            XmlSerializer s = new XmlSerializer(typeof(GoodPanelBuilder));
            FileStream fs = new FileStream(filename, FileMode.Open);
            GoodPanelBuilder gcl = (GoodPanelBuilder)s.Deserialize(fs);
            fs.Close();
            return gcl;
        }
        static public GoodPanelBuilder ReadParamatersFromEmbeddedResource(string filename)
        {
            Assembly a = Assembly.GetExecutingAssembly();
            Stream fs = a.GetManifestResourceStream(filename);
            XmlSerializer s = new XmlSerializer(typeof(GoodPanelBuilder));
            GoodPanelBuilder gcl = (GoodPanelBuilder)s.Deserialize(fs);

            return gcl;
        }
        static public GoodPanel MakePanel(GoodPanelBuilder b)
        {
            GoodPanel panel = new GoodPanel();
            foreach (GoodControlBuilder gcb in b.ControlList)
            {
                IGoodControl c = gcb.MakeControl();
                bool horizontal = false;
                if (gcb.Layout != null)
                    foreach (GoodDictionaryEntry gde in gcb.Layout)
                        if (gde.Key == "Horizontal")
                            horizontal = true;

                panel.Add(gcb.MakeControl().Control, horizontal);
            }
            panel.PerformLayout();
            return panel;
        }
    }

    public class GoodControlBuilder
    {
        [XmlElement("Type")]
        public string ControlType;

        [XmlElement("Parameter")]
        public GoodDictionaryEntry[] _parameters;
        public GoodDictionaryEntry[] ParameterDictionary
        {
            get { return _parameters; }
            set { _parameters = value; }
        }

        [XmlElement("LayoutParameter")]
        public GoodDictionaryEntry[] _layout;
        public GoodDictionaryEntry[] Layout
        {
            get { return _layout; }
            set { _layout = value; }
        }

        public IGoodControl MakeControl()
        {
            Trace.Write("MakeControl: creating " + ControlType + " with parameters: ");
            IGoodControl c = null;

            Assembly a = Assembly.GetExecutingAssembly();
            string typeName = a.GetName().Name + "." + ControlType;
            Type t = System.Type.GetType(typeName);
            ConstructorInfo ci = t.GetConstructor(System.Type.EmptyTypes);
            c = (IGoodControl)ci.Invoke(null);

            Dictionary<string, object> processedParameters = new Dictionary<string,object>();

            foreach (GoodDictionaryEntry gde in _parameters)
            {
                Trace.Write(gde.Key + "," + gde.Value + ";");
                switch (gde.Type)
                {
                    case "Text": processedParameters.Add(gde.Key, gde.Value);
                        break;

                    case "VariableName": processedParameters.Add(gde.Key, StateStore.Store[gde.Value]);
                        break;
                }
            }
            Trace.WriteLine("");

            c.ParameterList = processedParameters;
            c.Initialize();
            return c;
        }
    }
}
