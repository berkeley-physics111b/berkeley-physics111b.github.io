using System;
using System.Collections.Generic;
using System.Text;
using  System.Drawing;

namespace GoodStuff
{
    public class FrameCompleteEventArgs : EventArgs
    {
        public Frame Frame;

        public FrameCompleteEventArgs(Frame f)
        {
            Frame = f;
        }
    }

    public delegate void FrameCompleteEventHandler( object sender, FrameCompleteEventArgs args );

    public interface IFrameProcessor
    {
        void ProcessFrame(object sender, FrameCompleteEventArgs args);
        event FrameCompleteEventHandler FrameComplete;
    }

    public class Frame
    {
        public Dictionary<string, object> _objects;

        public Frame()
        {
            _objects = new Dictionary<string,object>();
        }
   }
}
