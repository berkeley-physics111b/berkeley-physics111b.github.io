﻿using System;
using System.Collections.Generic;

namespace GoodStuff
{
    public interface IGoodVariable
    {
        event EventHandler ValueChanged;
        string Name { get; set;}
    }
}
