using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

namespace GoodStuff
{
    public class GoodProgressBar : IGoodControl
    {
        IGoodVariable _minimum;
        IGoodVariable _maximum;
        IGoodVariable _value;

        ProgressBar _bar;

        public void Initialize() {
            _bar = new ProgressBar();
            if (_text != null) {
                GroupBox ggb = new GroupBox();
                ggb.Margin = new Padding(5, 15, 5, 5);
                ggb.Text = Text;
                ggb.SizeChanged += new EventHandler(HandleSizeChanged);
                _control = ggb;
                ggb.Controls.Add(_bar);
                HandleSizeChanged(this, new EventArgs());
            } else {
                _control = _bar;
            }
            _value = _gv[0] as IGoodVariable;
            _minimum = _gv[1] as IGoodVariable;
            _maximum = _gv[2] as IGoodVariable;
            UpdateValues();
            base.Initialize();
        }

        

        protected void HandleSizeChanged(object sender, EventArgs args)
        {
            _bar.Size = new Size(
                _control.Size.Width - _control.Margin.Horizontal,
                _control.Size.Height - _control.Margin.Vertical);
            _bar.Location = new Point(
                _control.Margin.Left,
                _control.Margin.Top);
        }

        protected void OnVariableChanged(object sender, EventArgs args)
        {
            if (_control.InvokeRequired)
                _control.Invoke(new UpdateDelegate(UpdateValues));
            else
                UpdateValues();
        }

        private delegate void UpdateDelegate();

        private void UpdateValues()
        {
             if (_minimum != null)
                _bar.Minimum = _minimum.ToInt32(null);
            else
                _bar.Minimum = 0;

            if (_maximum != null)
                _bar.Maximum = _maximum.ToInt32(null);
            else
                _bar.Maximum = Int32.MaxValue;

            _bar.Value = Math.Min(_bar.Maximum, Math.Max(_bar.Minimum,_value.ToInt32(null)));
       }

       #region IGoodControl Members

       IGoodVariable IGoodControl.GoodVariableBinding {
           get {
               return _variable as IGoodVariable;
           }
           set {
               throw new Exception("The method or operation is not implemented.");
           }
       }

       Control IGoodControl.Control {
           get { throw new Exception("The method or operation is not implemented."); }
       }

       #endregion
   }
}
