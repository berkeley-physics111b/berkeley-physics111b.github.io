using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace GoodStuff
{
    public class GoodVariableBase : IGoodVariable
    {
        protected string _instanceName;
        #region IGoodVariable Members
        public event EventHandler ValueChanged;
        string IGoodVariable.Name {
            get {
                return _instanceName;
            }
            set {
                _instanceName = value;
            }

        }

        #endregion

        public string InstanceName
        {
            get { return _instanceName; }
            set { _instanceName = value; }
        }

        public GoodVariableBase()
        {
            _syncRoot = new object();
        }

        public void Initialize()
        {
        }

        protected void RaiseValueChanged()
        {
            if (ValueChanged != null)
                ValueChanged(this, new EventArgs());
        }

        protected object _syncRoot;
        public object SyncRoot
        {
            get { return _syncRoot; }
        }

    }

    // 8 & 9. provides type specific get and set operators

    public class GoodProperty<T> : GoodVariable<T>, IGoodProperty where T : IConvertible {
        #region IConvertible Members
        public IConvertible propertyValue() {
            return Value;
        }
        public TypeCode GetTypeCode() { return _value.GetTypeCode(); }
        public bool ToBoolean(IFormatProvider provider) { return _value.ToBoolean(provider); }
        public byte ToByte(IFormatProvider provider) { return _value.ToByte(provider); }
        public char ToChar(IFormatProvider provider) { return _value.ToChar(provider); }
        public DateTime ToDateTime(IFormatProvider provider) { return _value.ToDateTime(provider); }
        public decimal ToDecimal(IFormatProvider provider) { return _value.ToDecimal(provider); }
        public double ToDouble(IFormatProvider provider) { return _value.ToDouble(provider); }
        public short ToInt16(IFormatProvider provider) { return _value.ToInt16(provider); }
        public int ToInt32(IFormatProvider provider) { return _value.ToInt32(provider); }
        public long ToInt64(IFormatProvider provider) { return _value.ToInt64(provider); }
        public sbyte ToSByte(IFormatProvider provider) { return _value.ToSByte(provider); }
        public float ToSingle(IFormatProvider provider) { return _value.ToSingle(provider); }
        public string ToString(IFormatProvider provider) { return _value.ToString(provider); }
        public override string ToString() { return _value.ToString(null); }
        public object ToType(Type conversionType, IFormatProvider provider) { return _value.ToType(conversionType, provider); }
        public ushort ToUInt16(IFormatProvider provider) { return _value.ToUInt16(provider); }
        public uint ToUInt32(IFormatProvider provider) { return _value.ToUInt32(provider); }
        public ulong ToUInt64(IFormatProvider provider) { return _value.ToUInt64(provider); }

        #endregion

        // type cast operators

        public static explicit operator bool(GoodProperty<T> v) { return v.Value.ToBoolean(null); }
        public static explicit operator byte(GoodProperty<T> v) { return v.Value.ToByte(null); }
        public static explicit operator char(GoodProperty<T> v) { return v.Value.ToChar(null); }
        public static explicit operator DateTime(GoodProperty<T> v) { return v.Value.ToDateTime(null); }
        public static explicit operator decimal(GoodProperty<T> v) { return v.Value.ToDecimal(null); }
        public static explicit operator double(GoodProperty<T> v) { return v.Value.ToDouble(null); }
        public static explicit operator short(GoodProperty<T> v) { return v.Value.ToInt16(null); }
        public static explicit operator int(GoodProperty<T> v) { return v.Value.ToInt32(null); }
        public static explicit operator long(GoodProperty<T> v) { return v.Value.ToInt64(null); }
        public static explicit operator sbyte(GoodProperty<T> v) { return v.Value.ToSByte(null); }
        public static explicit operator float(GoodProperty<T> v) { return v.Value.ToSingle(null); }
        public static explicit operator string(GoodProperty<T> v) { return v.Value.ToString(null); }
        public static explicit operator ushort(GoodProperty<T> v) { return v.Value.ToUInt16(null); }
        public static explicit operator uint(GoodProperty<T> v) { return v.Value.ToUInt32(null); }
        public static explicit operator ulong(GoodProperty<T> v) { return v.Value.ToUInt64(null); }

        // TODO: handle exceptions in all of these

        public void Set(IConvertible v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }
    }

    public class GoodVariable {
        protected string _name;
        public string Name {
            get { return _name; }
            set { _name = value; }
        }

        protected string _displayName;
        public string DisplayName {
            get { return _displayName; }
            set { _displayName = value; }
        }

        public GoodVariable() {
            _syncRoot = new object();
        }

        public event EventHandler ValueChanged;
        protected void RaiseValueChanged() {
            if (ValueChanged != null)
                ValueChanged(this, new EventArgs());
        }

        protected object _syncRoot;
        public object SyncRoot {
            get { return _syncRoot; }
        }
    }


    public class GoodVariable<T> : GoodVariableBase
    {
        protected T _value;
        virtual public T Value
        {
            get
            {
                return _value;
            }
            set
            {
                lock (_syncRoot)
                {
                    _value = value;
                }
                RaiseValueChanged();
            }
        }

        protected string _name;
        public string Name {
            get { return _name; }
            set { _name = value; }
        }

        protected string _displayName;
        public string DisplayName {
            get { return _displayName; }
            set { _displayName = value; }
        }
         

    }

    public interface IGoodProperty : IGoodVariable, IConvertible
    {
        void Set(IConvertible v);
        IConvertible propertyValue();
    }

    //public class GoodProperty<T> : GoodVariable<T>, IGoodProperty where T : IConvertible
    //{
    //    #region IConvertible Members

    //    public TypeCode GetTypeCode() { return _value.GetTypeCode(); }
    //    public bool ToBoolean(IFormatProvider provider) { return _value.ToBoolean(provider); }
    //    public byte ToByte(IFormatProvider provider) { return _value.ToByte(provider); }
    //    public char ToChar(IFormatProvider provider) { return _value.ToChar(provider); }
    //    public DateTime ToDateTime(IFormatProvider provider) { return _value.ToDateTime(provider); }
    //    public decimal ToDecimal(IFormatProvider provider) { return _value.ToDecimal(provider); }
    //    public double ToDouble(IFormatProvider provider) { return _value.ToDouble(provider); }
    //    public short ToInt16(IFormatProvider provider) { return _value.ToInt16(provider); }
    //    public int ToInt32(IFormatProvider provider) { return _value.ToInt32(provider); }
    //    public long ToInt64(IFormatProvider provider) { return _value.ToInt64(provider); }
    //    public sbyte ToSByte(IFormatProvider provider) { return _value.ToSByte(provider); }
    //    public float ToSingle(IFormatProvider provider) { return _value.ToSingle(provider); }
    //    public string ToString(IFormatProvider provider) { return _value.ToString(provider); }
    //    public override string ToString() { return _value.ToString(null); }
    //    public object ToType(Type conversionType, IFormatProvider provider) { return _value.ToType(conversionType, provider); }
    //    public ushort ToUInt16(IFormatProvider provider) { return _value.ToUInt16(provider); }
    //    public uint ToUInt32(IFormatProvider provider) { return _value.ToUInt32(provider); }
    //    public ulong ToUInt64(IFormatProvider provider) { return _value.ToUInt64(provider); }

    //    #endregion

    //    // type cast operators

    //    public static explicit operator bool(GoodProperty<T> v) { return v.Value.ToBoolean(null); }
    //    public static explicit operator byte(GoodProperty<T> v) { return v.Value.ToByte(null); }
    //    public static explicit operator char(GoodProperty<T> v) { return v.Value.ToChar(null); }
    //    public static explicit operator DateTime(GoodProperty<T> v) { return v.Value.ToDateTime(null); }
    //    public static explicit operator decimal(GoodProperty<T> v) { return v.Value.ToDecimal(null); }
    //    public static explicit operator double(GoodProperty<T> v) { return v.Value.ToDouble(null); }
    //    public static explicit operator short(GoodProperty<T> v) { return v.Value.ToInt16(null); }
    //    public static explicit operator int(GoodProperty<T> v) { return v.Value.ToInt32(null); }
    //    public static explicit operator long(GoodProperty<T> v) { return v.Value.ToInt64(null); }
    //    public static explicit operator sbyte(GoodProperty<T> v) { return v.Value.ToSByte(null); }
    //    public static explicit operator float(GoodProperty<T> v) { return v.Value.ToSingle(null); }
    //    public static explicit operator string(GoodProperty<T> v) { return v.Value.ToString(null); }
    //    public static explicit operator ushort(GoodProperty<T> v) { return v.Value.ToUInt16(null); }
    //    public static explicit operator uint(GoodProperty<T> v) { return v.Value.ToUInt32(null); }
    //    public static explicit operator ulong(GoodProperty<T> v) { return v.Value.ToUInt64(null); }

    //    // TODO: handle exceptions in all of these

    //    public void Set(IConvertible v)
    //    {
    //        Value = (T)(v as IConvertible).ToType(typeof(T), null);
    //    }
    //}

    public delegate T GoodValidator<T>(GoodVariable<T> v, T newValue);

    public interface IGoodNumericVariable : IConvertible {
        void Set(bool v);
        void Set(byte v);
        void Set(char v);
        void Set(DateTime v);
        void Set(decimal v);
        void Set(double v);
        void Set(short v);
        void Set(int v);
        void Set(long v);
        void Set(sbyte v);
        void Set(float v);
        void Set(string v);
        void Set(object v);
        void Set(ushort v);
        void Set(uint v);
        void Set(ulong v);
    }

    public class GoodNumericVariable<T> : GoodVariable<T>, IGoodNumericVariable where T : IConvertible {
        #region IConvertible Members

        public TypeCode GetTypeCode() { return _value.GetTypeCode(); }
        public bool ToBoolean(IFormatProvider provider) { return _value.ToBoolean(provider); }
        public byte ToByte(IFormatProvider provider) { return _value.ToByte(provider); }
        public char ToChar(IFormatProvider provider) { return _value.ToChar(provider); }
        public DateTime ToDateTime(IFormatProvider provider) { return _value.ToDateTime(provider); }
        public decimal ToDecimal(IFormatProvider provider) { return _value.ToDecimal(provider); }
        public double ToDouble(IFormatProvider provider) { return _value.ToDouble(provider); }
        public short ToInt16(IFormatProvider provider) { return _value.ToInt16(provider); }
        public int ToInt32(IFormatProvider provider) { return _value.ToInt32(provider); }
        public long ToInt64(IFormatProvider provider) { return _value.ToInt64(provider); }
        public sbyte ToSByte(IFormatProvider provider) { return _value.ToSByte(provider); }
        public float ToSingle(IFormatProvider provider) { return _value.ToSingle(provider); }
        public string ToString(IFormatProvider provider) { return _value.ToString(provider); }
        public object ToType(Type conversionType, IFormatProvider provider) { return _value.ToType(conversionType, provider); }
        public ushort ToUInt16(IFormatProvider provider) { return _value.ToUInt16(provider); }
        public uint ToUInt32(IFormatProvider provider) { return _value.ToUInt32(provider); }
        public ulong ToUInt64(IFormatProvider provider) { return _value.ToUInt64(provider); }

        #endregion

        // type cast operators

        public static explicit operator bool(GoodNumericVariable<T> v) { return v.Value.ToBoolean(null); }
        public static explicit operator byte(GoodNumericVariable<T> v) { return v.Value.ToByte(null); }
        public static explicit operator char(GoodNumericVariable<T> v) { return v.Value.ToChar(null); }
        public static explicit operator DateTime(GoodNumericVariable<T> v) { return v.Value.ToDateTime(null); }
        public static explicit operator decimal(GoodNumericVariable<T> v) { return v.Value.ToDecimal(null); }
        public static explicit operator double(GoodNumericVariable<T> v) { return v.Value.ToDouble(null); }
        public static explicit operator short(GoodNumericVariable<T> v) { return v.Value.ToInt16(null); }
        public static explicit operator int(GoodNumericVariable<T> v) { return v.Value.ToInt32(null); }
        public static explicit operator long(GoodNumericVariable<T> v) { return v.Value.ToInt64(null); }
        public static explicit operator sbyte(GoodNumericVariable<T> v) { return v.Value.ToSByte(null); }
        public static explicit operator float(GoodNumericVariable<T> v) { return v.Value.ToSingle(null); }
        public static explicit operator string(GoodNumericVariable<T> v) { return v.Value.ToString(null); }
        public static explicit operator ushort(GoodNumericVariable<T> v) { return v.Value.ToUInt16(null); }
        public static explicit operator uint(GoodNumericVariable<T> v) { return v.Value.ToUInt32(null); }
        public static explicit operator ulong(GoodNumericVariable<T> v) { return v.Value.ToUInt64(null); }

        #region IGoodNumericVariable Members

        // TODO: handle exceptions in all of these

        public void Set(bool v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(byte v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(char v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(DateTime v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(decimal v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(double v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(short v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(int v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(long v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(sbyte v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(float v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(string v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(object v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(ushort v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(uint v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        public void Set(ulong v) {
            Value = (T)(v as IConvertible).ToType(typeof(T), null);
        }

        #endregion
    }


}