using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace GoodStuff
{
    public class GoodPanel : Panel
    {
        GoodLayout _layout;

        public GoodPanel()
        {
            _layout = new GoodLayout(this);
        }

        public void Add(Control c)
        {
            Add(c, false);
        }

        public void Add(Control c, bool isHorizontal)
        {
            Controls.Add(c);
            _layout.Add(c, isHorizontal);
            PerformLayout();
        }

        public new void PerformLayout()
        {
            _layout.PerformLayout();
            base.PerformLayout();
        }
    }
}
