using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    public class GoodControl: IInitializable
    {
        protected Control _control;
        public Control Control
        {
            get { return _control; }
        }

        protected string _text;
        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }

        protected GoodVariableBase[] _gv;

        public void BindTo( string variableName )
        {
            BindTo( new string[1]{variableName} );
        }

        public void BindTo( params string[] variableNames)
        {
            _gv = new GoodVariableBase[variableNames.Length];
            for (int i = 0; i < variableNames.Length; ++i)
            {
                if(variableNames[i] != null)
                    _gv[i] = (GoodVariableBase)StateStore.Store[variableNames[i]];
                if(_gv[i] != null)
                    _gv[i].ValueChanged += OnVariableChanged;
            }
        }

        public virtual void Initialize()
        {
            OnVariableChanged(this, new EventArgs());
        }

        protected virtual void OnVariableChanged(object sender, EventArgs args)
        {
        }
    }



    public interface IGoodControl
    {
        void Initialize();
        IGoodVariable GoodVariableBinding { get; set; }
        System.Windows.Forms.Control Control { get; }
        void Add(IGoodControl somethingToAdd);
        void pBind(IGoodProperty newGoodVar);
//        void pBind(IGoodControl newControl);
    }
    
    public class GoodControlContainerBase : ContainerControl, IGoodControl
    {
        protected Control _control;
        protected Label _label;
        public string LabelText { get { return _label.Text; } set { _label.Text = value; } }
        protected int _charactersWide;
        public int CharactersWide
        {
            get { return _charactersWide; }
            set { _charactersWide = value; }
        }
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        /*public void pBind(IGoodControl gCon) {
            if (_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase) gCon;
            pushPopIndex++;
        }*/
        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }

        protected bool _updating;
        public Control Control {
            get { return _control; }
        }
        public void Add(IGoodControl somethingToAdd) {
            if (!(somethingToAdd is Control)) {
                Controls.Add(somethingToAdd.Control);
            } else {
                Controls.Add((Control)somethingToAdd);
            }
        }
        protected GoodVariable _variable;
        public IGoodVariable GoodVariableBinding
        {
            get { return (IGoodVariable) _control; }
            set
            {
                Trace.WriteLine("GoodControl set to point to variable " + value.Name);
                _control = (Control) value;
            }
        }

        public GoodControlContainerBase()
        {
            _label = new Label();
        }

        virtual public void Initialize()
        {
                _variable.ValueChanged += OnVariableChanged;

                LabelText = _variable.DisplayName + ":";
                _label.TextAlign = ContentAlignment.MiddleRight;
                _label.MaximumSize = _label.PreferredSize;

                _label.Location = new Point(
                    Margin.Left,
                    Margin.Top + Math.Max(0, (_control.Height - _label.Height) / 2));
                _control.Location = new Point(
                    _label.Right + Padding.Horizontal,
                    Margin.Top + Math.Max(0, (_label.Height - _control.Height) / 2));
                _control.Update();
                Size = new Size(
                    _control.Right + Margin.Right,
                    Math.Max(_label.Height, _control.Height) + Margin.Vertical);
                Controls.Add((Control)_label);
                Controls.Add((Control)_control);
         }

        virtual protected void OnVariableChanged(object sender, EventArgs args)
        {
        }

    }

    public class GoodControlGroupBox : GroupBox, IGoodControl
    {
        protected GoodVariable<Rectangle> _variable;
        protected GoodVariable<Rectangle> _goodRControl;
        public IGoodVariable GoodVariableBinding
        {
            get { return (IGoodVariable) _variable; }
            set
            {
                Trace.WriteLine("GoodControl set to point to variable " + value.Name);
                _variable = (GoodVariable<Rectangle>) value;
            }
        }
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        /*public void pBind(IGoodControl gCon) {
            if (_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase) gCon;
            pushPopIndex++;
        }*/

        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }

        public Control Control {
            get { return this; }
        }

        public void Add(IGoodControl somethingToAdd) {
            if (!(somethingToAdd is Control)) {
                Controls.Add(somethingToAdd.Control);
            } else {
                Controls.Add((Control)somethingToAdd);
            }
            }

        virtual public void Initialize()
        {
                _variable.ValueChanged += OnVariableChanged;
        }

        virtual protected void OnVariableChanged(object sender, EventArgs args)
        {
        }

    }

}
