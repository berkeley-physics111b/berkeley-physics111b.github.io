using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    public class GoodButton : Button, IGoodControl
    {
//        public event EventHandler Click;
        public GoodVariable<EventHandler> _variable;

        IGoodProperty _text;
        #region IGoodControl Members

        public void Initialize() {
            AutoSize = true;
            Text = (IGoodProperty)_variable.DisplayName;
            Click += _variable.Value;
        }

        public GoodVariable GoodVariableBinding {
            get {
                return _variable as GoodVariable;
            }
            set {
                _variable = value as GoodVariable<EventHandler>;
            }
        }

        #endregion
        public IGoodProperty Text
        {
            get { return _text; }
            set { _text = value; _control.Text = _text.ToString(); }
        }

        Button _control;

        public Control Control
        {
            get { return _control; }
//            set { _control = (Button)value; }
        }

        public GoodButton()
        {
            Trace.WriteLine("GoodButton Constructor Called");
            _control = new Button();
            _control.AutoSize = true;
            _control.Text = "Text";
            _control.Click += ClickHandler;
        }

        protected void ClickHandler(object sender, EventArgs args)
        {
            SampleEventArgs clickArgs = new SampleEventArgs();
            clickArgs.Sample.Add("Time", Environment.TickCount);
            Click(this, clickArgs);
        }


     /* public void Initialize()
        {
            throw new Exception("The method or operation is not implemented.");
        }*/

    }
}
