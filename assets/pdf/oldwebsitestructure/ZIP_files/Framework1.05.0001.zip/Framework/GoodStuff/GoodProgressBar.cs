using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    /// <summary>
    /// implements a UI progress bar control
    /// bindings: { value, minimum, maximum, text }
    /// </summary>
    public class GoodProgressBar : GoodControlBase, IInitializable
    {
        GoodNumericVariable<int> _minimum;
        GoodNumericVariable<int> _maximum;
        GoodNumericVariable<int> _value;

        ProgressBar _bar;



        public override void Initialize()
        {
            base.Initialize();

            _value = (GoodNumericVariable<int>) ParameterNumericVariable("Variable");
            if (_value != null) {
                _value.ValueChanged += OnVariableChanged;
                Trace.WriteLine("Initializing GoodProgressBar " + _value.InstanceName);
            }
            _minimum = (GoodNumericVariable<int>) ParameterNumericVariable("Minimum");
            if (_minimum != null)
                _minimum.ValueChanged += OnVariableChanged;
            _maximum = (GoodNumericVariable<int>) ParameterNumericVariable("Maximum");
            if (_maximum != null)
                _maximum.ValueChanged += OnVariableChanged;

            _bar = new ProgressBar();
            GroupBox ggb = new GroupBox();
            if (ParameterText("Width") != null)
                ggb.Width = Int32.Parse(ParameterText("Width"));
            if (ParameterText("Height") != null)
                ggb.Height = Int32.Parse(ParameterText("Height"));

            ggb.Margin = new Padding(5,15, 5, 5);
            ggb.Text = ParameterText("Text");
            ggb.SizeChanged += new EventHandler(HandleSizeChanged);
            _control = ggb;
            ggb.Controls.Add(_bar);
            HandleSizeChanged(this, new EventArgs());

            UpdateValues();
        }
        public void BindTo(GoodVariableBase[] variables)
        {
            _gv = new GoodVariableBase[variables.Length];
            for (int i = 0; i < variables.Length; ++i)
            {
                if (variables[i] != null)
                    _gv[i] = variables[i];
                if (_gv[i] != null)
                    _gv[i].ValueChanged += OnVariableChanged;
            }
        }

        public void BindTo(params string[] variableNames) {
            _gv = new GoodVariableBase[variableNames.Length];
            for (int i = 0; i < variableNames.Length; ++i) {
                if (variableNames[i] != null)
                    _gv[i] = (GoodVariableBase)StateStore.Store[variableNames[i]];
                if (_gv[i] != null)
                    _gv[i].ValueChanged += OnVariableChanged;
            }
        }


        public int Height {
            get { return _control.Size.Height; }
            set {
                Size controlSize;
                controlSize = _control.Size;
                controlSize.Height = value;
                HandleSizeChanged(this, new EventArgs());

                UpdateValues();
            }
        }

        public int Width {
            get { return _control.Size.Width; }
            set {
                Size controlSize;
                controlSize = _control.Size;
                controlSize.Width = value;
                HandleSizeChanged(this, new EventArgs());

                UpdateValues();
            }
        }


        protected void HandleSizeChanged(object sender, EventArgs args)
        {
            _bar.Size = new Size(
                _control.Size.Width - _control.Margin.Horizontal,
                _control.Size.Height - _control.Margin.Vertical);
            _bar.Location = new Point(
                _control.Margin.Left,
                _control.Margin.Top);
        }

        protected override void OnVariableChanged(object sender, EventArgs args)
        {
            if (_control.InvokeRequired)
                _control.Invoke(new UpdateDelegate(UpdateValues));
            else
                UpdateValues();
        }

        private delegate void UpdateDelegate();

        private void UpdateValues()
        {
             if (_minimum != null)
                _bar.Minimum = _minimum.ToInt32(null);
            else
                _bar.Minimum = 0;

            if (_maximum != null)
                _bar.Maximum = _maximum.ToInt32(null);
            else
                _bar.Maximum = Int32.MaxValue;
            if (_value != null) {
                _bar.Value = Math.Min(_bar.Maximum, Math.Max(_bar.Minimum, _value.ToInt32(null)));
            }
            else {
                _bar.Value = Math.Min(_bar.Maximum, _bar.Minimum);
            }
        }
    }
}
