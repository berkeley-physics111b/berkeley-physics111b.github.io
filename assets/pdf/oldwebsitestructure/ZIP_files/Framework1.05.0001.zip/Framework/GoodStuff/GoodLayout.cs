using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.Diagnostics;

namespace GoodStuff
{
    public class GoodLayout
    {
        Point _insertionPoint;
        int _horizontalInsertionHeight;
        Control _owner;
        List<Control> _thisRow;

        Dictionary<Control, bool> _isHorizontal;

        public GoodLayout(Control owner)
        {
            _isHorizontal = new Dictionary<Control, bool>();
            _owner = owner;
        }

        protected void SetLocation(Control c, bool isHorizontal)
        {
            //Trace.WriteLine("Insertion Point " + _insertionPoint.ToString());

            if (!isHorizontal)
            {
                _thisRow = null;
                if(_horizontalInsertionHeight != 0)
                _insertionPoint = new Point(_insertionPoint.X, 
                    _insertionPoint.Y + _horizontalInsertionHeight + _owner.Padding.Vertical);
                _horizontalInsertionHeight = 0;
                c.Location = _insertionPoint;
                int w = Math.Max(_owner.Size.Width, _insertionPoint.X + c.Width + _owner.Margin.Right);
                int h = _insertionPoint.Y + c.Size.Height + _owner.Margin.Bottom;
                _owner.Size = new Size(w, h);
                _insertionPoint = new Point(_insertionPoint.X, _insertionPoint.Y + c.Size.Height + _owner.Padding.Vertical);
            }
            else
            {
                if (_thisRow == null)
                    _thisRow = new List<Control>();
                _thisRow.Add(c);
                _horizontalInsertionHeight = Math.Max(_horizontalInsertionHeight, c.Size.Height);
                int horizontalOffset = 0;
                foreach (Control cc in _thisRow)
                {
                    cc.Location = new Point(_insertionPoint.X + horizontalOffset, 
                        _insertionPoint.Y + (_horizontalInsertionHeight - cc.Height) / 2);
                    horizontalOffset += cc.Width + _owner.Padding.Horizontal;
                }
                int w = Math.Max(_owner.Size.Width, 
                    _insertionPoint.X + horizontalOffset + _owner.Margin.Right - _owner.Padding.Right);
                int h = _insertionPoint.Y + _horizontalInsertionHeight + _owner.Margin.Bottom;
                _owner.Size = new Size(w, h);
                //_horizontalInsertionColumn += c.Width + _owner.Padding.Horizontal;
            }
        }

        public void PerformLayout()
        {
            _insertionPoint = new Point(_owner.Margin.Left, _owner.Margin.Top);
            _horizontalInsertionHeight = 0;

            _thisRow = null;
            foreach (Control c in _owner.Controls)
            {
                SetLocation(c, _isHorizontal[c]);
            }
        }

        public void Add(IGoodControl c, bool IsHorizontal) {
            if (!(c is Control)) {
                _isHorizontal.Add(c.Control, IsHorizontal);
            } else {
                _isHorizontal.Add((Control)c, IsHorizontal);
            }
        }
    }
}
