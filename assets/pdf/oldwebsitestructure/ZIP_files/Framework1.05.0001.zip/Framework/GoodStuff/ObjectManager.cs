using System;
using System.Collections.Generic;
using System.Text;

namespace GoodStuff
{

    //CURSOR2
    public class ObjectManager
    {
        static Dictionary<string, object> _objects;

        public static object Get(string ObjectName)
        {
            return _objects[ObjectName];
        }

        public static void Add(string ObjectName, object ObjectToAdd)
        {
            if( _objects == null)
                _objects = new Dictionary<string, object>();

            _objects.Add(ObjectName, ObjectToAdd);
        }
    }
}
