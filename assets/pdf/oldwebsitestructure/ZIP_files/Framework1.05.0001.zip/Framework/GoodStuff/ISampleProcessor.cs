using System;
using System.Collections.Generic;
using System.Text;

namespace GoodStuff
{
    public class SampleEventArgs : EventArgs
    {
        Dictionary<string, object> _Sample;

        public Dictionary<string, object> Sample
        {
            get { return _Sample; }
            set { _Sample = value; }
        }

        public SampleEventArgs()
        {
            _Sample = new Dictionary<string, object>();
        }
    }

    public delegate void SampleEventHandler(object sender, SampleEventArgs args);

}
