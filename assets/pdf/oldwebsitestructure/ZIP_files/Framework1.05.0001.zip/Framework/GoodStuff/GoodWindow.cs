using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace GoodStuff
{
    public class GoodWindow
    {
        Form _form;
        FlowLayoutPanel _flp;

        public GoodWindow()
        {
            _form = new Form();
            _flp = new FlowLayoutPanel();
            _form.Controls.Add(_flp);
            _flp.FlowDirection = FlowDirection.TopDown;
            _flp.Margin = new Padding(10);
            _flp.Padding = new Padding(10);
        }

        public void Add(IGoodControl c) {
            if (!(c is Control)) {
                _flp.Controls.Add(c.Control);
            } else {
                _flp.Controls.Add((Control)c);
            }
        }
        public void Run()
        {
            Application.Run(_form);
        }
    }
}
