using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace GoodStuff
{
    public class GoodGroupBox : GroupBox, IGoodControl
    {
        GoodLayout _layout;

        public GoodGroupBox()
        {
            Margin = new Padding(5, 15, 5, 5);
            _layout = new GoodLayout(this);
            Size = new Size(10, 10);
        }

        public void Add(IGoodControl c)
        {
            Add(c, false);
        }

        public void Add(IGoodControl c, bool isHorizontal)
        {
            _layout.Add(c, isHorizontal);
            if (!(c is Control)) {
                Controls.Add(c.Control);
            } else {
                Controls.Add((Control)c);
            }
            PerformLayout();
        }

        public new void PerformLayout()
        {
            _layout.PerformLayout();
            base.PerformLayout();
        }


        #region IGoodControl Members

        public void Initialize() {
            PerformLayout();
        }

        public IGoodVariable GoodVariableBinding {
            get {
                throw new Exception("The method or operation is not implemented.");
            }
            set {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        public new Control Control {
          get {
                return this as Control;
            }
        }

        public void pBind(IGoodProperty newControl) {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
}
