using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace GoodStuff
{
    public class GoodPictureBox : GroupBox, IGoodControl, IInitializable
    {
        GoodVariable<Bitmap> _variable;
        Graphics _controlGraphics;
        #region IGoodControl Members
        protected Control _control;
        public Control Control{
            get { return this as Control; }
//            set { _control = value; }
        }
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        /*public void pBind(IGoodControl gCon) {
            if (_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase) gCon;
            pushPopIndex++;
        }*/

        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }

        public void Initialize() {
            Text = _variable.DisplayName;
            _variable.ValueChanged += OnBitmapChanged;
            _control = new Control();
        }
#endregion
        #region xmliorate
        public int Height {
            get {
                return Size.Height;
            }
            set {
                Size = new Size(Size.Width, value);
            }
        }
        public int Width {
            get {
                return Size.Width;
            }
            set {
                Size = new Size(value, Size.Height);
            }
        }
#endregion
        public GoodPictureBox()
        {
            Margin = new Padding(3, 15, 3, 3);
        }

        #region IGoodControl Members

        public void Add(IGoodControl somethingToAdd) {
            if (!(somethingToAdd is Control)) {
                Controls.Add(somethingToAdd.Control);
            } else {
                Controls.Add((Control)somethingToAdd);
            }
        }
        GoodProperty<Int32> sizefication;
        public GoodProperty<Int32> Sizefier {
            get {
                return sizefication;
            }
            set {
                sizefication = value;
                Size = new Size(sizefication.Value + Margin.Horizontal, sizefication.Value + Margin.Vertical);
            }
        }

        public void OnBitmapChanged(object sender, EventArgs args)
        {
            if(_controlGraphics == null)
                _controlGraphics = this.CreateGraphics();

            _controlGraphics.SetClip(new Rectangle(
                Margin.Left,
                Margin.Top,
                Size.Width - Margin.Horizontal,
                Size.Height - Margin.Vertical));

            Bitmap b = _variable.Value;
            _controlGraphics.DrawImage(
                b,
                _controlGraphics.VisibleClipBounds,
                new Rectangle(0, 0, b.Size.Width, b.Size.Height),
                GraphicsUnit.Pixel);
        }
        
        #endregion

        #region IGoodControl Members
     

        public IGoodVariable GoodVariableBinding {
            get {
                return _variable as IGoodVariable;
            }
            set {
                _variable = (GoodVariable<Bitmap>)value;
            }
        }

        #endregion
    }
}
