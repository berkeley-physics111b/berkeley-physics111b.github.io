using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    //public class GoodComboBox : NewGoodControl, IGoodControl
    //{

    //    public GoodComboBox()
    //    {
    //        Trace.WriteLine("GoodComboBox constructor called");
    //        _control = new ComboBox();
    //    }

    //    override protected void OnVariableChanged(object sender, EventArgs args)
    //    {
    //        if (!_updating)
    //        {
    //            _updating = true;
    //            object o = (_variable as GoodSelection).Value;
    //            (_control as ComboBox).SelectedItem = o;
    //            _updating = false;
    //        }
    //    }

    //    public override void Initialize()
    //    {
    //        Trace.WriteLine("Initializing GoodComboBox " + _variable.Name);
    //        if (!(_variable is GoodSelection))
    //            throw (new Exception("GoodComboBox must refer to a variable that is a GoodSelection"));

    //        ComboBox control = (_control as ComboBox);

    //        control.DropDownStyle = ComboBoxStyle.DropDownList;
    //        control.Items.AddRange((_variable as GoodSelection).Choices);
    //        control.SelectedItem = (_variable as GoodSelection).Value;
    //        control.SelectedValueChanged += OnValueChanged;

    //        base.Initialize();
    //    }

    //    public void OnValueChanged(object sender, EventArgs e)
    //    {
    //        if (!_updating)
    //        {
    //            _updating = true;
    //            Trace.WriteLine("GoodComboBox " + _variable.Name + " changed in UI");
    //            if (_variable != null)
    //            {
    //                (_variable as GoodSelection).Value = ((_control as ComboBox).SelectedItem);
    //            }
    //            _updating = false;
    //        }
    //    }
    //}

}
