using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace GoodStuff
{
    public class GoodDictionaryEntry
    {
        [XmlElement("Key")]
        public string Key;
        [XmlElement("Type")]
        public string Type;
        [XmlElement("Value")]
        public string Value;
    }
}
