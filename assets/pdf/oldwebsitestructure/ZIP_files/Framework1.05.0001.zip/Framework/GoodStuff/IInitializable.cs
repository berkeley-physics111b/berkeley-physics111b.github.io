using System;
using System.Collections.Generic;

namespace GoodStuff {
    public interface IInitializable {
        void Initialize();
    }
}
