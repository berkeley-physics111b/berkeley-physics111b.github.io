using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;

namespace GoodStuff {
    public class GoodPanel : Panel, IGoodControl {
        GoodLayout _layout;
        GoodProperty<Int32> marginIndex;
        GoodProperty<Int32> paddingIndex;
        GoodVariable _variable;
        Control control;

        public GoodProperty<Int32> MarginIndex {
            get {
                return marginIndex;
            }
            set {
                marginIndex = value;
                Margin = new Padding(marginIndex.Value);
            }
        }
        public GoodProperty<Int32> PaddingIndex {
            get {
                return paddingIndex;
            }
            set {
                paddingIndex = value;
                Padding = new Padding(paddingIndex.Value);
            }
        }
        public GoodPanel() {
            _layout = new GoodLayout(this);
            control = (Control)this;
        }

        public void Add(IGoodControl c) {
            Add(c, false);
        }

        public void Add(IGoodControl c, bool isHorizontal) {
            if (!(c is Control)) {
                Controls.Add(c.Control);
            } else {
                Controls.Add((Control)c);
            }
            _layout.Add( c, isHorizontal);
            PerformLayout();
        }

 
        public new void PerformLayout() {
            _layout.PerformLayout();
            base.PerformLayout();
        }
        #region IGoodControl Members
        public IGoodVariable GoodVariableBinding {
            get {
                return _variable as IGoodVariable;
            }
            set {
                _variable = (GoodVariable)value;
            }
        }
        public void Initialize() {
            PerformLayout();
        }
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        /*public void pBind(IGoodControl gCon) {
            if (_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase)gCon;
            pushPopIndex++;
        }*/

        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }

        public Control Control {
            get {
                return control;
            }
        }
        #endregion
    }
}
