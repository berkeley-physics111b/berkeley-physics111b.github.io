using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    public class GoodButton : IGoodControl, IInitializable
    {
        public event EventHandler Click;
        protected GoodVariable<EventHandler> _click;
        IGoodProperty _text;

        public IGoodProperty Text
        {
            get { return _text; }
            set { _text = value; _control.Text = _text.ToString(); }
        }

        public Button _control;
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        /*public void pBind(IGoodControl gCon) {
            if (_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase)gCon;
            pushPopIndex++;
        }*/

        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }

        public Control Control
        {
            get { return (Control) _control; }
            set { _control = (Button) value; }
        }

        public void Add(IGoodControl somethingToAdd) {
            if (!(somethingToAdd is Control)) {
                _control.Controls.Add(somethingToAdd.Control);
            } else {
                _control.Controls.Add((Control)somethingToAdd);
            }
        }
        public GoodButton()
        {
            Trace.WriteLine("GoodButton Constructor Called");
            _control = new Button();
            _control.AutoSize = true;
            _control.Text = "Text";
            _control.Click += ClickHandler;
        }

        protected void ClickHandler(object sender, EventArgs args)
        {
            SampleEventArgs clickArgs = new SampleEventArgs();
            clickArgs.Sample.Add("Time", Environment.TickCount);
            Click(this, clickArgs);
        }


        public void Initialize()
        {
         
        }


        #region IGoodControl Members

        void IGoodControl.Initialize() {
         
        }

        public IGoodVariable GoodVariableBinding {
            get {
                return _click as IGoodVariable;
            }
            set {
                _click = (GoodVariable<EventHandler>) value;
                Click = _click.Value;
                
            }
        }

        #endregion
    }
}
