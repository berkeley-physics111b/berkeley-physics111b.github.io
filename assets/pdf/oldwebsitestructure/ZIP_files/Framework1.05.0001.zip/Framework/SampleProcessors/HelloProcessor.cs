using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Forms;
using GoodStuff;

namespace SampleProcessors {
    class HelloProcessor : WorkerThread {

        public event SampleEventHandler Hello;
        internal SampleEventArgs cache;


        // NOTE THAT THE MULTI_THREADING IS DIsABLED DUE TO CROSS-THREAD INVOKE ISSUES
        //WORKING ON THIS!
        static BackgroundWorker bw = new BackgroundWorker();
        internal Queue<string> greetings = new Queue<string>();

        public void sayHello(object sender, SampleEventArgs args) {
            string message = "Hello World #" + args.Sample["Time"];

            cache = args;
            greetings.Enqueue(message);

            // NOTE THAT THE MULTI_THREADING IS DIsABLED DUE TO CROSS-THREAD INVOKE ISSUES
            //WORKING ON THIS!
            bw_DoWork();
        }

        public HelloProcessor() {
            //bw.DoWork += new DoWorkEventHandler(bw_DoWork);
            //bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bw_RunWorkerCompleted);
        }

        void bw_DoWork() {
            cache.Sample.Add("Message", greetings.Dequeue());
            if (Hello != null) Hello(this, cache);
            System.Threading.Thread.Sleep(25);
        }

        void bw_RunWorkerCompleted() {
            if (greetings.Count > 0) {
                bw_DoWork();
            }
        }
    }
}
