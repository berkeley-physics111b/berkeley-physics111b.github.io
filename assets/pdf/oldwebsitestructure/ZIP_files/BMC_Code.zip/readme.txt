To run executable navigate to 
BrownianApplication\bin\Debug\Brownian Application.exe

TO change code navigate to
Brownian Motion in Cells\FrameGrabber.sln