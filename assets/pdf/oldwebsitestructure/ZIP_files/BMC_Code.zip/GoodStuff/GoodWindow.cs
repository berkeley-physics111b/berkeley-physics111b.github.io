using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace GoodStuff
{
    public class GoodWindow
    {
        protected Form _form;
        FlowLayoutPanel _flp;
                
        public event SampleEventHandler MouseAction;
        public event SampleEventHandler KeyAction;
        public event SampleEventHandler StateChanged;
        public event SampleEventHandler WindowClosed;

        IGoodProperty _title;

        public IGoodProperty Title
        {
            get { return _title; }
            set { _title = value; _form.Text = _title.ToString(); }
        }
        protected GoodProperty<int> _height;
        protected GoodProperty<int> _width;
        public GoodProperty<int> Height
        {
            get { return _height; }
            set{_height = value; _form.Height=value.Value;}
        }
        public GoodProperty<int> Width
        {
            get { return _width; }
            set{_width = value; _form.Width=value.Value;}
        }

        public GoodWindow()
        {
            _width = new GoodProperty<int>();
            _height = new GoodProperty<int>();


            InitializeForm();
        }
        protected void InitializeForm()
        {
            _flp = new FlowLayoutPanel();
            _flp.FlowDirection = FlowDirection.TopDown;
            _flp.Margin = new Padding(10);
            _flp.Padding = new Padding(10);
            _flp.AutoSize = true;
            _flp.AutoSizeMode = AutoSizeMode.GrowAndShrink;

            _form = new Form();
            _form.Controls.Add(_flp);
            _form.MouseClick += _mouseEventHandler;
            _form.ResizeEnd += new EventHandler(_form_ResizeEnd);
         
            //_form.ClientSizeChanged += _form_ResizeEnd;
            _form.KeyUp += new KeyEventHandler(_form_KeyUpDown);
            _form.KeyDown += _form_KeyUpDown;
            _form.FormClosed += new FormClosedEventHandler(_form_FormClosed);
            _form.AutoSize = true;
            _form.Activated += _form_ResizeEnd;
        }


        delegate void CallBack(object sender, SampleEventArgs sArgs);
        public void Close(object sender, SampleEventArgs sArgs)
        {
            if (_form.InvokeRequired)
            {
                CallBack d = new CallBack(Close);
                _form.Invoke(d, new object[] { sender, sArgs });
            }
            else
            {
                _form.Close();
            }
        }


        void _form_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (WindowClosed != null)
                WindowClosed(this, new SampleEventArgs());
        }

        void _form_KeyUpDown(object sender, KeyEventArgs kArgs)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("KeyArgs", kArgs);
            if (KeyAction != null)
                KeyAction(this, s);
        }

        void _form_ResizeEnd(object sender, EventArgs e)
        {
            SampleEventArgs s = new SampleEventArgs();
            _width.Value = _form.Width;
            _height.Value = _form.Height;
            s.Sample.Add("Graphics", _form.CreateGraphics());
            s.Sample.Add("ClientSize", _form.ClientSize);
            s.Sample.Add("ClientRectangle", _form.ClientRectangle);
            if(StateChanged!=null)
                StateChanged(this, s);
            
        }
        public void WriteGraphics(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("BufferedGraphics"))
            {
                //_controlGraphics = (Graphics)sArgs.Sample["Graphics"];
                BufferedGraphics bg = (BufferedGraphics)sArgs.Sample["BufferedGraphics"];
                bg.Render(_form.CreateGraphics());
            }
        }
        public void Add(IGoodControl c) {
            if (!(c is Control)) {
                _flp.Controls.Add(c.Control);
            } else {
                _flp.Controls.Add((Control)c);
            }
            
        }
        public void _mouseEventHandler(object sender, MouseEventArgs mArgs)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("MouseArgs", mArgs);
            if (MouseAction != null)
                MouseAction(this, s);
        }

        public void Run()
        {
            Application.Run(_form);
        }
    }
}
