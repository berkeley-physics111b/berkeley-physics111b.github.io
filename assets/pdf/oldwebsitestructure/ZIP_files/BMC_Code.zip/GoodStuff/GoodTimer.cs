using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using GoodStuff;

namespace GoodStuff {
    public class GoodTimer {
        Timer _timer;

        IGoodProperty _period;

        public IGoodProperty Period {
            get { return _period; }
            set {
                _period = value;
                _timer.Interval = _period.ToInt32(null);
            }
        }



        void PeriodChanged(object sender, SampleEventArgs args)
        {
            _timer.Interval = _period.ToInt32(null);
        }


        public event SampleEventHandler Tick;

        public GoodTimer() {
            _timer = new Timer();
            _timer.Interval = 500;
            _timer.Tick += TickHandler;
        }

        public void Start(object sender, SampleEventArgs args) {
            _timer.Start();
        }

        public void Stop(object sender, SampleEventArgs args)
        {
            _timer.Stop();
        }

        public void StartStop(object sender, SampleEventArgs args)
        {
            if (_timer.Enabled)
                _timer.Stop();
            else
                _timer.Start();
        }



        //public void OnIntervalChanged(object sender, EventArgs args)
        //{
        //    _timer.Stop();
        //    _timer.Interval = (int)Value;
        //    _timer.Start();
        //}

        int n = 0;

        void TickHandler(object sender, EventArgs args)
        {
            if (Tick != null) {
                SampleEventArgs ea = new SampleEventArgs();
                ea.Sample.Add("Time", n);
                n++;
                Tick(this, ea);
            }
        }
    }
}
