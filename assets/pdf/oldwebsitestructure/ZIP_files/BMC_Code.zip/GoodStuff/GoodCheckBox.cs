using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.Drawing;
namespace GoodStuff
{
    class GoodCheckBox : IGoodControl
    {

        GoodProperty<bool> _value;

        CheckBox _CB;
        Panel _panel;
        Label _label;
        public event SampleEventHandler BoolValueChanged;
        GoodProperty<string> _text;
        public GoodProperty<string> Text
        {
            get { return _text; }
            set { _text = value; _label.Text = value.Value; }
        }
        public GoodProperty<bool> Value
        {
            get
            {
                return _value;
            }
            set
            {
                _CB.Checked = value.Value;
                _value = value;
            }
        }
        public GoodCheckBox()
        {
            Trace.WriteLine("GoodCheckBox constructor called");
            _value = new GoodProperty<bool>();
            _CB = new CheckBox();
            _CB.CheckStateChanged += new EventHandler(_CB_CheckStateChanged);
            
            _label = new Label();
            _panel = new Panel();
            
            _label.Text = "Default";

            _label.Location = new Point(
                _panel.Margin.Left,
                _panel.Margin.Top + Math.Max(0, (_CB.Height - _label.Height) / 2));
            _CB.Location = new Point(
                _label.Right + _panel.Padding.Horizontal,
                _panel.Margin.Top + Math.Max(0, (_label.Height - _CB.Height) / 2));

            _panel.AutoSize = true;
            _panel.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            _panel.Controls.Add(_label);
            _panel.Controls.Add(_CB);
                        
        }

        void _CB_CheckStateChanged(object sender, EventArgs e)
        {
            _value.Value = _CB.Checked;

            if (BoolValueChanged != null)
            {
                SampleEventArgs s = new SampleEventArgs();
                s.Sample.Add("Value", _CB.Checked);
                BoolValueChanged(this, s);
            }
        }
        #region IGoodControl Members

        public Control Control
        {
            get { return _panel; }
            //          set { _textBox = (TextBox) value; }
        }
        public void Add(IGoodControl somethingToAdd)
        {
            if (!(somethingToAdd is Control))
            {
                _panel.Controls.Add(somethingToAdd.Control);
            }
            else
            {
                _panel.Controls.Add((Control)somethingToAdd);
            }
        }
        protected GoodVariableBase[] _gv;
        protected int pushPopIndex;
        public void pBind(IGoodProperty gProp)
        {
            if (_gv == null)
            {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }
        public void Initialize()
        {
            
        }


        public IGoodVariable GoodVariableBinding
        {
            get
            {
                return Value as IGoodVariable;
            }
            set
            {
                Value = (GoodProperty<bool>)value;
            }
        }
        #endregion
    }
}
