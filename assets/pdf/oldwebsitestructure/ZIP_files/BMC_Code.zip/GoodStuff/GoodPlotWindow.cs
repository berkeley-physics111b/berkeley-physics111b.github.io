using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using ZedGraph;
using System.Drawing;

namespace GoodStuff
{
    class GoodPlotWindow 
    {
        private ZedGraph.ZedGraphControl zgc;
        IGoodProperty _title;

        Form _form;

        public IGoodProperty Title
        {
            get { return _title; }
            set { _title = value; _form.Text = _title.ToString(); }
        }
        GoodProperty<int> _height;
        GoodProperty<int> _width;
        public GoodProperty<int> Height
        {
            get { return _height; }
            set { _height = value; _form.Height = value.Value; }
        }
        public GoodProperty<int> Width
        {
            get { return _width; }
            set { _width = value; _form.Width = value.Value; }
        }
        public GoodPlotWindow()
        {
            _height = new GoodProperty<int>();
            _width = new GoodProperty<int>();
            _height.Value = 250;
            _width.Value = 250;
            _form = new Form();
            _form.Size = new Size(250, 250);
            
            //_form.Controls.Add(_flp);
            //_form.MouseClick += _mouseEventHandler;
            //_form.ResizeEnd += new EventHandler(_form_ResizeEnd);
            //_form.KeyUp += new KeyEventHandler(_form_KeyUpDown);
            //_form.KeyDown += _form_KeyUpDown;
            //_form.FormClosed += new FormClosedEventHandler(_form_FormClosed);
            _form.AutoSize = true;

            //InitializeZedGraphControl();
            _form.Controls.Add(zgc);
            _form.Resize += new EventHandler(_form_Resize);
            _form.Load += new EventHandler(_form_Load);
            //_form.Activated += _form_ResizeEnd;
        }

        void _form_Load(object sender, EventArgs e)
        {
            SetSize();
        }

        void _form_Resize(object sender, EventArgs e)
        {
            SetSize();
        }
        public void InitializeZedGraphControl()
        {
            //if (zgc.InvokeRequired)
            //{
            //    CallBack d = new CallBack(InitializeZedGraphControl);
            //    zgc.Invoke(d, new object[] { });
            //}
            //else
            //{

            zgc = new ZedGraph.ZedGraphControl();
            zgc.EditButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.EditModifierKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.None)));
            zgc.IsAutoScrollRange = false;
            zgc.IsEnableHEdit = false;
            zgc.IsEnableHPan = true;
            zgc.IsEnableHZoom = true;
            zgc.IsEnableVEdit = false;
            zgc.IsEnableVPan = true;
            zgc.IsEnableVZoom = true;
            zgc.IsPrintFillPage = true;
            zgc.IsPrintKeepAspectRatio = true;
            zgc.IsScrollY2 = false;
            zgc.IsShowContextMenu = true;
            zgc.IsShowCopyMessage = true;
            zgc.IsShowCursorValues = false;
            zgc.IsShowHScrollBar = false;
            zgc.IsShowPointValues = false;
            zgc.IsShowVScrollBar = false;
            zgc.IsSynchronizeXAxes = false;
            zgc.IsSynchronizeYAxes = false;
            zgc.IsZoomOnMouseCenter = false;
            zgc.LinkButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.LinkModifierKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.None)));
            zgc.Location = new System.Drawing.Point(12, 12);
            zgc.Name = "zgc";
            zgc.PanButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.PanButtons2 = System.Windows.Forms.MouseButtons.Middle;
            zgc.PanModifierKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.None)));
            zgc.PanModifierKeys2 = System.Windows.Forms.Keys.None;
            zgc.PointDateFormat = "g";
            zgc.PointValueFormat = "G";
            zgc.ScrollMaxX = 0;
            zgc.ScrollMaxY = 0;
            zgc.ScrollMaxY2 = 0;
            zgc.ScrollMinX = 0;
            zgc.ScrollMinY = 0;
            zgc.ScrollMinY2 = 0;
            zgc.Size = new System.Drawing.Size(439, 297);
            zgc.TabIndex = 0;
            zgc.ZoomButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.ZoomButtons2 = System.Windows.Forms.MouseButtons.None;
            zgc.ZoomModifierKeys = System.Windows.Forms.Keys.None;
            zgc.ZoomModifierKeys2 = System.Windows.Forms.Keys.None;
            zgc.ZoomStepFraction = 0.1;
            SetSize();
            //}
        }
        delegate void CallBack(object sender, SampleEventArgs sArgs);
        public void Plot(object sender, SampleEventArgs sArgs)
        {
            InitializeZedGraphControl();
            if (zgc.InvokeRequired)
            {
                CallBack d = new CallBack(Plot);
                zgc.Invoke(d, new object[] { sender, sArgs });
            }
            else
            {
                Color C = Color.Black;
                SymbolType ST = SymbolType.Default;
                GraphPane myPane = zgc.GraphPane;
                LineItem curve;
                string DataTitle = "";
                if (sArgs.Sample.ContainsKey("Title"))
                    myPane.Title.Text = (string)sArgs.Sample["Title"];
                if (sArgs.Sample.ContainsKey("X Label"))
                    myPane.XAxis.Title.Text = (string)sArgs.Sample["XLabel"];
                if (sArgs.Sample.ContainsKey("Y Label"))
                    myPane.YAxis.Title.Text = (string)sArgs.Sample["YLabel"];
                if (sArgs.Sample.ContainsKey("Color"))
                    C = (Color)sArgs.Sample["Color"];
                if (sArgs.Sample.ContainsKey("SymbolType"))
                    ST = (SymbolType)sArgs.Sample["SymbolType"];
                if (sArgs.Sample.ContainsKey("DataTitle"))
                    DataTitle = (string)sArgs.Sample["DataTitle"];

                if (sArgs.Sample.ContainsKey("X") && sArgs.Sample.ContainsKey("Y"))
                {
                    double[] x = (double[])sArgs.Sample["X"];
                    double[] y = (double[])sArgs.Sample["Y"];
                    curve = myPane.AddCurve(DataTitle, x, y, C, ST);
                }
                if (sArgs.Sample.ContainsKey("PointList"))
                {
                    PointPairList P = (PointPairList)sArgs.Sample["PointList"];
                    curve = myPane.AddCurve(DataTitle, P, C, ST);
                }
                //Graphics _controlGraphics = this.CreateGraphics();

                //zgc.AxisChange();
                _form.Show();
            }
            //_controlGraphics.DrawImage(zgc.GetImage(), 1, 1);
        }
        private void SetSize()
        {
            zgc.Location = new Point(10, 10);
            // Leave a small margin around the outside of the control
            zgc.Size = new Size(_width.Value - 10, _height.Value - 10);
        }
    }
}
