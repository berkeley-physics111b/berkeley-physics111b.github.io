using System;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using ZedGraph;

namespace GoodStuff
{
    public class GoodPlotWindow2 : GoodWindow
    {
        private ZedGraph.ZedGraphControl zgc;

        bool DefaultHold;
        Color[] DefaultColors;
        public GoodPlotWindow2()
        {
            _width = new GoodProperty<int>();
            _width.Value = 400;
            _height = new GoodProperty<int>();
            _height.Value = 250;
            DefaultHold = false;
            //InitializeZedGraphControl();
            _form.Closing += new System.ComponentModel.CancelEventHandler(_form_Closing);
            DefaultColors = new Color[] {Color.Black, Color.Violet, Color.Blue, Color.Green, Color.Yellow, Color.Orange, Color.Red};
            
        }

        void _form_Closing(object sender, System.ComponentModel.CancelEventArgs e) //hijack the closing event. dont close the form!!!
        {
            e.Cancel = true ;
            _form.Hide(); //just hide it
            zgc.GraphPane.CurveList.Clear(); 
        }
        delegate void CloseCallBack(object sender, SampleEventArgs sArgs);
        public void Close(object sender, SampleEventArgs sArgs)
        {
            if (_form.InvokeRequired)
            {
                CloseCallBack d = new CloseCallBack(Close);
                _form.Invoke(d, new object[] { sender, sArgs });
            }
            else
            {
                _form.Dispose();
            }
        }
        public void InitializeZedGraphControl()
        {
            //if (zgc.InvokeRequired)
            //{
            //    CallBack d = new CallBack(InitializeZedGraphControl);
            //    zgc.Invoke(d, new object[] { });
            //}
            //else
            //{

            zgc = new ZedGraph.ZedGraphControl();
            zgc.EditButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.EditModifierKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.None)));
            zgc.IsAutoScrollRange = false;
            zgc.IsEnableHEdit = false;
            zgc.IsEnableHPan = true;
            zgc.IsEnableHZoom = true;
            zgc.IsEnableVEdit = false;
            zgc.IsEnableVPan = true;
            zgc.IsEnableVZoom = true;
            zgc.IsPrintFillPage = true;
            zgc.IsPrintKeepAspectRatio = true;
            zgc.IsScrollY2 = false;
            zgc.IsShowContextMenu = true;
            zgc.IsShowCopyMessage = true;
            zgc.IsShowCursorValues = false;
            zgc.IsShowHScrollBar = false;
            zgc.IsShowPointValues = false;
            zgc.IsShowVScrollBar = false;
            zgc.IsSynchronizeXAxes = false;
            zgc.IsSynchronizeYAxes = false;
            zgc.IsZoomOnMouseCenter = false;
            zgc.LinkButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.LinkModifierKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.None)));
            zgc.Location = new System.Drawing.Point(12, 12);
            zgc.Name = "zgc";
            zgc.PanButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.PanButtons2 = System.Windows.Forms.MouseButtons.Middle;
            zgc.PanModifierKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Shift | System.Windows.Forms.Keys.None)));
            zgc.PanModifierKeys2 = System.Windows.Forms.Keys.None;
            zgc.PointDateFormat = "g";
            zgc.PointValueFormat = "G";
            zgc.ScrollMaxX = 0;
            zgc.ScrollMaxY = 0;
            zgc.ScrollMaxY2 = 0;
            zgc.ScrollMinX = 0;
            zgc.ScrollMinY = 0;
            zgc.ScrollMinY2 = 0;
            zgc.Size = new System.Drawing.Size(439, 297);
            zgc.TabIndex = 0;
            zgc.ZoomButtons = System.Windows.Forms.MouseButtons.Left;
            zgc.ZoomButtons2 = System.Windows.Forms.MouseButtons.None;
            zgc.ZoomModifierKeys = System.Windows.Forms.Keys.None;
            zgc.ZoomModifierKeys2 = System.Windows.Forms.Keys.None;
            zgc.ZoomStepFraction = 0.1;

            _form.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            _form.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            _form.ClientSize = new System.Drawing.Size(463, 321);
            
            _form.Controls.Add(zgc);

            _form.ResizeEnd += new EventHandler(_form_ResizeEnd2);
            _form.AutoSize = false;

            
            //}
        }

        void _form_ResizeEnd2(object sender, EventArgs e)
        {
            SetSize();
            
        }
        void RecreateForm()
        {
            InitializeForm();

            _form.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            _form.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            _form.ClientSize = new System.Drawing.Size(463, 321);
            _form.Controls.Add(zgc);

            _form.ResizeEnd += new EventHandler(_form_ResizeEnd2);
            InitializeZedGraphControl();

            //Application.Run(_form);
            _form.Controls.Add(zgc); 
            _form.ShowDialog();
        }

        delegate void CallBack();
        private void SetSize()
        {
            if (zgc.InvokeRequired)
            {
                CallBack d = new CallBack(SetSize);
                zgc.Invoke(d, new object[] { });
            }
            else
            {
                zgc.Location = new Point(10, 10);
                // Leave a small margin around the outside of the control
                zgc.Size = new Size(_width.Value - 20, _height.Value - 50);
            }
        }
        delegate void FormShowCallback();
        public void Plot(object sender, SampleEventArgs sArgs)
        {
//            InitializeZedGraphControl();
            //if (zgc.InvokeRequired)
           // {
               // CallBack d = new CallBack(Plot);
                //object[] a = new object[2];
                //a[0] = sender;
                //a[1] = sArgs;

                //zgc.Invoke(d, a);
           // }
           // else
            //{
            if (_form.IsDisposed) //has the form been destroyed recently?
            {
                RecreateForm();
            }
            bool Hold;
                Color C = Color.Black;
                SymbolType ST = SymbolType.Default;
                GraphPane myPane = zgc.GraphPane;
                LineItem curve;
                string DataTitle = "";
                if (sArgs.Sample.ContainsKey("Title"))
                    myPane.Title.Text = (string)sArgs.Sample["Title"];
                if (sArgs.Sample.ContainsKey("X Label"))
                    myPane.XAxis.Title.Text = (string)sArgs.Sample["X Label"];
                if (sArgs.Sample.ContainsKey("Y Label"))
                    myPane.YAxis.Title.Text = (string)sArgs.Sample["Y Label"];
                if (sArgs.Sample.ContainsKey("Color"))
                {
                    if (sArgs.Sample["Color"].GetType().Name.Contains("Int") || sArgs.Sample["Color"].GetType().Name.Contains("int"))
                        C = DefaultColors[(int)sArgs.Sample["Color"]%DefaultColors.Length];
                    else
                        C = (Color)sArgs.Sample["Color"];
                }
                if (sArgs.Sample.ContainsKey("SymbolType"))
                    ST = (SymbolType)sArgs.Sample["SymbolType"];
                if (sArgs.Sample.ContainsKey("DataTitle"))
                    DataTitle = (string)sArgs.Sample["DataTitle"];
                if (sArgs.Sample.ContainsKey("Hold"))
                    Hold = (bool)sArgs.Sample["Hold"];
                else
                    Hold = DefaultHold;
                if (!Hold)
                    myPane.CurveList.Clear();
                if (sArgs.Sample.ContainsKey("X") && sArgs.Sample.ContainsKey("Y"))
                {
                    double[] x = (double[])sArgs.Sample["X"];
                    double[] y = (double[])sArgs.Sample["Y"];
                    curve = myPane.AddCurve(DataTitle, x, y, C, ST);
                }
                if (sArgs.Sample.ContainsKey("PointList"))
                {
                    PointPairList P = (PointPairList)sArgs.Sample["PointList"];
                    curve = myPane.AddCurve(DataTitle, P, C, ST);
                }
                //Graphics _controlGraphics = this.CreateGraphics();
                

                zgc.AxisChange();
                

                FormShowCallback d = new FormShowCallback (_form.Show);    
                _form.Invoke(d);
                d = new FormShowCallback(_form.Refresh);   
                _form.Invoke(d);
                SetSize();
               
            //}
            //_controlGraphics.DrawImage(zgc.GetImage(), 1, 1);
        }
        public void Run()
        {
            InitializeZedGraphControl();
            Application.Run(_form);
            _form.Hide();
        }
    }
}
