using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    public class GoodButton : Button, IGoodControl
    {
        GoodVariable<EventHandler> _variable;
        #region IGoodControl Members

        public void Initialize()
        {
            Text = _variable.DisplayName;
            Click += _variable.Value;
        }

        public GoodVariable GoodVariableBinding
        {
            get
            {
                return _variable as GoodVariable;
            }
            set
            {
                _variable = value as GoodVariable<EventHandler>;
            }
        }

        #endregion
    }
}
