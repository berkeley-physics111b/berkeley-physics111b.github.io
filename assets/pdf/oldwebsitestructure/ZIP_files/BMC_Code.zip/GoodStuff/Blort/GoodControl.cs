using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    public interface IGoodControl
    {
        void Initialize();
        GoodVariable GoodVariableBinding { get; set; }
    }

    public class GoodControlContainerBase : ContainerControl, IGoodControl
    {
        protected Control _control;
        protected Label _label;
        public string LabelText { get { return _label.Text; } set { _label.Text = value; } }
        protected int _charactersWide;
        public int CharactersWide
        {
            get { return _charactersWide; }
            set { _charactersWide = value; }
        }
        protected bool _updating;


        protected GoodVariable _variable;
        public GoodVariable GoodVariableBinding
        {
            get { return _variable; }
            set
            {
                Trace.WriteLine("GoodControl set to point to variable " + value.Name);
                _variable = value;
            }
        }

        public GoodControlContainerBase()
        {
            _label = new Label();
        }

        virtual public void Initialize()
        {
                _variable.ValueChanged += OnVariableChanged;

                LabelText = _variable.DisplayName + ":";
                _label.TextAlign = ContentAlignment.MiddleRight;
                _label.MaximumSize = _label.PreferredSize;

                _label.Location = new Point(
                    Margin.Left,
                    Margin.Top + Math.Max(0, (_control.Height - _label.Height) / 2));
                _control.Location = new Point(
                    _label.Right + Padding.Horizontal,
                    Margin.Top + Math.Max(0, (_label.Height - _control.Height) / 2));
                _control.Update();
                Size = new Size(
                    _control.Right + Margin.Right,
                    Math.Max(_label.Height, _control.Height) + Margin.Vertical);
                Controls.Add(_label);
                Controls.Add(_control);
         }

        virtual protected void OnVariableChanged(object sender, EventArgs args)
        {
        }

    }

    public class GoodControlGroupBox : GroupBox, IGoodControl
    {
        protected GoodVariable _variable;
        public GoodVariable GoodVariableBinding
        {
            get { return _variable; }
            set
            {
                Trace.WriteLine("GoodControl set to point to variable " + value.Name);
                _variable = value;
            }
        }

        virtual public void Initialize()
        {
                _variable.ValueChanged += OnVariableChanged;
        }

        virtual protected void OnVariableChanged(object sender, EventArgs args)
        {
        }

    }

}
