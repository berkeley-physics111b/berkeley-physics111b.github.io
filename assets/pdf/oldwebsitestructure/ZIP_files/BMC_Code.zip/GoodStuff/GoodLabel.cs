using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;


namespace GoodStuff
{
    class GoodLabel : IGoodControl
    {
        IGoodProperty _text;
        public IGoodProperty Text
        {
            get { return _text; }
            set { _text = value; _label.Text = _text.ToString(); }
        }
        Label _label;

        GoodProperty<string> _updateTextKey;
        public GoodProperty<string> UpdateTextKey
        {
            get { return _updateTextKey; }
            set { _updateTextKey = value; }
        }
        delegate void CallBack(object sender, SampleEventArgs sArgs);
        public void UpdateText(object sender, SampleEventArgs args)
        {
            if (_label.InvokeRequired)
            {
                CallBack d = new CallBack(UpdateText);
                _label.Invoke(d, new object[] { sender, args });
            }
            else
            {
                _text.Set(args.Sample[_updateTextKey.ToString()].ToString());
                _label.Text = args.Sample[_updateTextKey.ToString()].ToString();
                _label.Update();
            }
        }
        public GoodLabel()
        {
            Trace.WriteLine("Initializing GoodTextBox");
            _text = (IGoodProperty)new GoodProperty<string>();
            _text.Set("Default");

            _label = new Label();
            //_label.TextAlign = HorizontalAlignment.Left;
            _label.Text = _text.ToString();
            _label.AutoSize = true;
            
            _updateTextKey = new GoodProperty<string>();
            _updateTextKey.Value = "Message";
        }
        #region IGoodControl Members
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        public void pBind(IGoodProperty gProp)
        {
            if (_gv == null)
            {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }
        public void Add(IGoodControl somethingToAdd)
        {
            if (!(somethingToAdd is Control))
            {
                _label.Controls.Add(somethingToAdd.Control);
            }
            else
            {
                _label.Controls.Add((Control)somethingToAdd);
            }
        }
        public Control Control
        {
            get { return _label; }
            //          set { _textBox = (TextBox) value; }
        }

        public void Initialize()
        {
            //Label_textBox = new TextBox();
        }


        public IGoodVariable GoodVariableBinding
        {
            get
            {
                return _text as IGoodVariable;
            }
            set
            {
                _text = (IGoodProperty)value;
            }
        }
        #endregion
    }
}
