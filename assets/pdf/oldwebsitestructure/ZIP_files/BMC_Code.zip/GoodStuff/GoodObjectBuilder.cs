using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Reflection;
using System.Diagnostics;
using System.Windows.Forms;
using GoodStuff;

namespace GoodStuff {
    public class GoodObjectBuilder {
        XmlTextReader _reader = null;

        protected void ParseElement() {
            XmlNodeType currentNodeType = _reader.NodeType;
            string currentNodeName = _reader.Name;
        }

        public static object Instantiate(string AssemblyName, string TypeName) {
            return Instantiate(AssemblyName, AssemblyName, TypeName);
        }

        public static object Instantiate(string AssemblyName, string Namespace, string TypeName) {
            Type pType;
            Type nType;
            Type pbType;
            Type nbType;
            object objection = new object();
            Assembly b = Assembly.LoadFrom("System.Drawing.dll");
            if (TypeName == "Point") {
                Trace.WriteLine("Point!");
                pbType = b.GetType("System.Drawing.Point");
                Trace.WriteLine("pbType {0}", pbType.ToString());
            }            
            Assembly a = Assembly.LoadFrom(AssemblyName + ".dll");
            Type t = a.GetType(Namespace + "." + TypeName);
            if ((TypeName != "Point") && (TypeName != "Rectangle") && (TypeName != "Size")) {
                ConstructorInfo ci = t.GetConstructor(System.Type.EmptyTypes);
                objection = ci.Invoke(null);
            } else {
                if (TypeName == "Point") {
                    Type[] typeArg= new Type[1] { typeof(int)};
                    object[] param = new object[1];
                    param[0] =  0;
                    ConstructorInfo ci = t.GetConstructor(typeArg);
                    objection = ci.Invoke(param);
                }
                if (TypeName == "Rectangle") {
                    Type[] typeArg = new Type[4];
                    object[] param = new object[4];
                    param[0] = 0;
                    param[1] = 0;
                    param[2] = 0;
                    param[3] = 0;
                    typeArg[0] =typeof(int);
                    typeArg[1] = typeof(int);
                    typeArg[2] = typeof(int);
                    typeArg[3] = typeof(int);
                    ConstructorInfo ci = t.GetConstructor(typeArg);
                    objection = ci.Invoke(param);
                }
                if(TypeName == "Size") {
                    Type[] typeArg= new Type[2];
                    typeArg[0] =  typeof(int);
                    typeArg[1] =  typeof(int);
                    object[] param = new object[2];
                    param[0] =  0;
                    param[1] =  0;
                    ConstructorInfo ci = t.GetConstructor(typeArg);
                    objection = ci.Invoke(param);
                }
            }
                return objection;
        }

        public static object GenericInstantiate(string templateTypeName, string templateAssemblyName, string genericTypeName, string genericAssemblyName) {
            Type templateType;
            Assembly templateAssembly;        
            string subTemplateAssemblyName = templateAssemblyName.Substring(0, 6);
            if (subTemplateAssemblyName != "System") {
                templateAssembly = Assembly.LoadFrom(templateAssemblyName + ".dll");
                templateType = templateAssembly.GetType(templateAssemblyName+"."+templateTypeName);
            } else {
                if ((subTemplateAssemblyName == "System") && (templateAssemblyName != "System")) {
                    templateAssembly = Assembly.LoadFrom(templateAssemblyName + ".dll");
                    templateType = templateAssembly.GetType(templateAssemblyName + "." + templateTypeName);
                } else {
                    templateType = Type.GetType(templateAssemblyName + "." + templateTypeName);
                }
            }
            Assembly genericAssembly = Assembly.LoadFrom(genericAssemblyName + ".dll");
            Type genericType = genericAssembly.GetType(genericAssemblyName+"."+genericTypeName);
            Type rType = genericType.MakeGenericType(templateType);
            ConstructorInfo ci = rType.GetConstructor(System.Type.EmptyTypes);
            object o = ci.Invoke(null);
            return o;
        }

        public static void ConnectEvent(object EventSource, string EventName, object EventListner, string HandlerName) {
            Type tSource = EventSource.GetType();
            EventInfo ei = tSource.GetEvent(EventName);
            Type evDelegate = ei.EventHandlerType;

            Type tHandler = EventListner.GetType();
            MethodInfo mi = tHandler.GetMethod(HandlerName);

            Delegate d = Delegate.CreateDelegate(evDelegate, EventListner, HandlerName);
            
            ei.AddEventHandler(EventSource, d);
        }
    
        public static bool ImplementsIFace(Type interfaceType, Type implementingType)
        {
        Type[] interfaces = implementingType.GetInterfaces();
        foreach(Type t in interfaces)
        {
           if(t == interfaceType) return true;
            }
            return false;
        }

        public static void ConnectProperty(object Target, string PropertyName, object Value) {
            Type t = Target.GetType();
            PropertyInfo pi = t.GetProperty(PropertyName);
            IGoodProperty iGood = new GoodProperty<int>() as IGoodProperty;
            Type gT = ((IGoodProperty) iGood).GetType();
            IGoodProperty iValue = Value as IGoodProperty;
            //            pi.SetValue(Target, iValue, null);
//            if (pi.PropertyType.IsSubclassOf(IGoodProperty.GetType())) {
            if(ImplementsIFace(typeof(IGoodProperty), pi.PropertyType) || (typeof(IGoodProperty) == pi.PropertyType)){ 
                pi.SetValue(Target, Value, null);
            } else {
                if (iValue != null) {
                    pi.SetValue(Target, iValue.propertyValue(), null);
                } else {
                    pi.SetValue(Target, Value, null);
                }
            }
        }
        public static void SetValue(IGoodProperty Parameter, IConvertible Value) {
            Parameter.Set(Value);
        }

        public static IGoodProperty PropertyFactory(string GenericType) {
            string typeName = "System." + GenericType;
            Type[] gType = new Type[1] { Type.GetType(typeName) };
            Type t;
            Assembly a = Assembly.LoadFrom("GoodStuff.dll");
            Type parameterType = a.GetType("GoodStuff.GoodProperty`1");

            t = parameterType.MakeGenericType(gType);

            ConstructorInfo ci = t.GetConstructor(new Type[0]);
            IGoodProperty c = (IGoodProperty)ci.Invoke(null);
            return c;
        }

        public static void ReadFile(string path) {
            XmlTextReader r = new XmlTextReader(path);

            //Type goodVariableType = Type.GetType("GoodStuff.GoodVariable`1");
            //Type goodNumericVariableType = Type.GetType("GoodStuff.GoodNumericVariable`1");

            while (r.Read()) {
                // string s;
                // int j;

                if (r.NodeType == XmlNodeType.Element) {
                    switch (r.Name) {
                        case "GoodObject": {
                                string name = r.GetAttribute("Name");
                                string type = r.GetAttribute("Type");
                                string assembly = r.GetAttribute("Assembly");
                                ObjectManager.Add(name, Instantiate(assembly, type));
                            }
                            break;
                        case "GenericVariable": {
                                string name = r.GetAttribute("Name");
                                string templateTypeName = r.GetAttribute("TemplateType");
                                string templateAssemblyName = r.GetAttribute("TemplateAssembly");
                                string genericTypeName = r.GetAttribute("GenericType") + "`1";
                                string genericAssemblyName = r.GetAttribute("GenericAssembly");
                                ObjectManager.Add(name, GenericInstantiate(templateTypeName, templateAssemblyName, genericTypeName, genericAssemblyName));
                            }
                            break;
                        case "Property": {
                                string name = r.GetAttribute("Name");
                                string type = r.GetAttribute("Type");
                                IGoodProperty gp = PropertyFactory(type);
                                r.Read();
                                gp.Set(r.Value);
                                ObjectManager.Add(name, gp);
                            }
                            break;
                        case "PushBind": {
                                string fromName = r.GetAttribute("Name");
                                string toName = r.GetAttribute("To");
                                IGoodProperty from = (IGoodProperty)ObjectManager.Get(fromName);
                                GoodControlBase to = (GoodControlBase)ObjectManager.Get(toName);
                                to.pBind(from);
                            }
                            break;
                        case "GoodVariableBinding": {
                                string fromVarName = r.GetAttribute("FromVar");
                                string toControlName = r.GetAttribute("ToControl");
                                IGoodControl toControl = (IGoodControl)ObjectManager.Get(toControlName);
                                IGoodVariable fromVar = (IGoodVariable)ObjectManager.Get(fromVarName);
                                toControl.GoodVariableBinding = fromVar;
                            }
                            break;
                        case "Connection": {
                                string from = r.GetAttribute("From");
                                string eventName = r.GetAttribute("Event");
                                string to = r.GetAttribute("To");
                                string handler = r.GetAttribute("Handler");

                                object fromObject = ObjectManager.Get(from);
                                object toObject = ObjectManager.Get(to);

                                ConnectEvent(fromObject, eventName, toObject, handler);
                            }
                            break;

                        case "Reference": {
                                string from = r.GetAttribute("From");
                                string key = r.GetAttribute("PropertyName");
                                string to = r.GetAttribute("To");

                                object fromObject = ObjectManager.Get(from);
                                object toObject = ObjectManager.Get(to);

                                ConnectProperty(fromObject, key, toObject);
                            }
                            break;

                        case "ConControl": {
                                string fromName = r.GetAttribute("Owner");
                                string controlName = r.GetAttribute("Owned");
                                IGoodControl gw = ObjectManager.Get(fromName) as IGoodControl;
                                IGoodControl gc = ObjectManager.Get(controlName) as IGoodControl;
                                if (gw == null) {
                                    FormCaptureControl gf = ObjectManager.Get(fromName) as FormCaptureControl;
                                    gf.Controls.Add((Control)gc);
                                } else {
                                    gw.Add((IGoodControl)gc);
                                }
                            }
                            break;

                        case "WinControl": {
                                string windowName = r.GetAttribute("Window");
                                string controlName = r.GetAttribute("Control");
                                GoodWindow gw = ObjectManager.Get(windowName) as GoodWindow;
                                IGoodControl gc = ObjectManager.Get(controlName) as IGoodControl;
                                gw.Add((IGoodControl)gc);
                            }
                            break;
                        case "Init": {
                                string objectName = r.GetAttribute("Name");
                                IInitializable gw = ObjectManager.Get(objectName) as IInitializable;
                                if (gw is IInitializable) {
                                    gw.Initialize();
                                }
                            }
                            break;
                        case "Show": {
                                string formName = r.GetAttribute("Form");
                                string controlName = r.GetAttribute("Control");
                                Form form = (Form)ObjectManager.Get(formName);
                                IWin32Window control = (IWin32Window)ObjectManager.Get(controlName);
                                form.Show(control);
                            }
                            break;
                        case "Run": {
                                string formName = r.GetAttribute("Name");
                                Form form = (Form)ObjectManager.Get(formName);
                                Application.Run(form);
                            }
                            break;
                    }
                } else {
                    Trace.WriteLine("NodeType {0}", r.NodeType.ToString());
                }

                //if ((r.NodeType == XmlNodeType.Element) && (r.Name == "GoodObject"))
                //{
                //}
                //if ((r.NodeType == XmlNodeType.Element) && (r.Name == "Property"))
                //{
                //    string key = r.GetAttribute("Key");
                //    string name = r.GetAttribute("Name");
                //    string type = r.GetAttribute("Key");
                //    string reference = r.GetAttribute("Key");



                //    switch (r.GetAttribute("Type"))
                //    {
                //        case "instanceName":
                //            break;

                //        default:
                //            string typeName = "System." + r.GetAttribute("Type");
                //            Type[] gvType = new Type[1] { Type.GetType(typeName) };
                //            Type t;

                //            if (gvType[0].GetInterface("IConvertible") == null)
                //                t = goodVariableType.MakeGenericType(gvType);
                //            else
                //                t = goodNumericVariableType.MakeGenericType(gvType);



                //            ConstructorInfo ci = t.GetConstructor(gvType);
                //            object[] initialValue = new object[1] { r.ReadElementContentAs(gvType[0], null) };
                //            IGoodVariable c = (IGoodVariable)ci.Invoke(initialValue);
                //            PropertyInfo pi = t.GetProperty("blort");
                //            MethodInfo mi = pi.GetSetMethod();
                //            //                  mi.Invoke(c, params);
                //            break;
                //    }
                //}

                //Trace.WriteLine(r.NodeType.ToString());
                //for (int i = 0; i < r.AttributeCount; ++i)
                //{
                //    string attr = r.GetAttribute(i);
                //}

            }
        }
    }
}
