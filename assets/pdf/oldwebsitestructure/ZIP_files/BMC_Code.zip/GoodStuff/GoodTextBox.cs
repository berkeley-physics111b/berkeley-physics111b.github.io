using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Windows.Forms;
using GoodStuff;

namespace GoodStuff
{
    public class GoodTextBox : IGoodControl, IInitializable
    {
        IGoodProperty _label;

        public IGoodProperty Label {
            get { return _label; }
            set { _label = value; _textBox.Text = _label.ToString(); }
        }

        public event SampleEventHandler TextValueChanged;

        IGoodProperty _text;
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        /*public void pBind(IGoodControl gCon) {
            if (_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase) gCon;
            pushPopIndex++;
        }*/

        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }

        public IGoodProperty Text {
            get { return _text; }
            set { _text = value; _textBox.Text = _text.ToString(); }
        }

        IGoodProperty _width;

        public void Add(IGoodControl somethingToAdd) {
            if (!(somethingToAdd is Control)) {
                _textBox.Controls.Add(somethingToAdd.Control);
            } else {
                _textBox.Controls.Add((Control)somethingToAdd);
            }
        }
        public IGoodProperty Width {
            get { return _width; }
            set { _width = value; }
        }

        TextBox _textBox;

        IGoodProperty _updateTextKey;

        public IGoodProperty UpdateTextKey {
            get { return _updateTextKey; }
            set { _updateTextKey = value; }
        }
        delegate void CallBack(object sender, SampleEventArgs sArgs);
        public void UpdateText(object sender, SampleEventArgs args) {
            if (_textBox.InvokeRequired)
            {
                CallBack d = new CallBack(UpdateText);
                _textBox.Invoke(d, new object[] { sender, args });
            }
            else
            {
                _text.Set(args.Sample[_updateTextKey.ToString()].ToString());
                _textBox.Text = args.Sample[_updateTextKey.ToString()].ToString();
            }
        }

        protected void OnTextChanged(object sender, EventArgs args) 
        {
            _textBox.Text = _text.ToString();
        }

        public  GoodTextBox() 
        {
            Trace.WriteLine("Initializing GoodTextBox");
            _text = (IGoodProperty)new GoodProperty<string>();
            _text.Set("Default");

            _textBox = new TextBox();
            _textBox.TextAlign = HorizontalAlignment.Left;
            _textBox.Text = _text.ToString();
            //_textBox.TextChanged += OnValueChanged;
            _textBox.TextChanged += OnValueChanged;
            

        }

        protected void OnValueChanged(object sender, EventArgs e) 
        {
            if (TextValueChanged != null)
            {
                SampleEventArgs s = new SampleEventArgs();
                s.Sample.Add("Value", _textBox.Text);
                TextValueChanged(this, s);
            }
        }


        #region IGoodControl Members

        public Control Control {
            get { return _textBox; }
//          set { _textBox = (TextBox) value; }
        }

        public void Initialize() {
            TextBox _textBox = new TextBox();
        }


        public IGoodVariable GoodVariableBinding {
            get {
                return _text as IGoodVariable;
            }
            set {
                _text = (IGoodProperty) value;
            }
        } 
        #endregion
    }
}
