using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Text;
using System.Threading;
using System.ComponentModel;


namespace GoodStuff
{
    public class GoodPictureBox : GroupBox, IGoodControl, IInitializable
    {
        public event SampleEventHandler ReportStateVariables;
        public event SampleEventHandler StateChanged;
        GoodVariable<Bitmap> _variable;
        Graphics _controlGraphics;
        #region IGoodControl Members
        protected Control _control;
        public Control Control{
            get { return this as Control; }
//            set { _control = value; }
        }
        protected int pushPopIndex;
        protected GoodVariableBase[] _gv;
        protected GoodControlBase[] _gc;
        /*public void pBind(IGoodControl gCon) {
            if (_gc == null) {
                _gc = new GoodControlBase[4];
            }
            Array.Resize(ref _gc, _gc.Length + 1);
            _gc[pushPopIndex] = (GoodControlBase) gCon;
            pushPopIndex++;
        }*/

        public void pBind(IGoodProperty gProp) {
            if (_gv == null) {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }

        public void Initialize() {
            Text = _variable.DisplayName;
            _variable.ValueChanged += OnBitmapChanged;
            _control = new Control();
            
        }
#endregion
        #region xmliorate
        public GoodProperty<int> Height2 {
            get {
                GoodProperty<int> q = new GoodProperty<int>(); q.Value = Size.Height; return q;
            }
            set {
                Size = new Size(Size.Width, value.Value);
               // DisplayRectangle.Height = Height2.Value;
            }
        }
        public GoodProperty<int> Width2 {
            get {
                GoodProperty<int> q = new GoodProperty<int>(); q.Value = Size.Width; return q; 
            }
            set {
                Size = new Size(value.Value, Size.Height);
                //DisplayRectangle= new Rectangle(DisplayRectangle.Location, new Size(Width2.Value, DisplayRectangle.Height));
            }
        }
#endregion
        GoodProperty<string> _title;
        public GoodProperty<string> Title
        {
            get { return _title; }
            set { _title = value; Text = value.Value; }
        }

        delegate void GoodPictureBox_ResizeCallback(object sender, EventArgs e);
        delegate void RequestStateVariables_Callback(object sender, SampleEventArgs sArgs);
        public GoodPictureBox()
        {
            
            Margin = new Padding(3, 15, 3, 3);
            //RequestStateVariables(this, new SampleEventArgs());
            //Resize += new EventHandler(GoodPictureBox_Resize);
            Click += GoodPictureBox_Resize;
            Text = "GoodPictureBox";
        }

        void GoodPictureBox_Resize(object sender, EventArgs e)
        {
            if (InvokeRequired)
            {
                GoodPictureBox_ResizeCallback d = new GoodPictureBox_ResizeCallback(GoodPictureBox_Resize);
                Invoke(d, new object[] { sender, e});
            }
            else
            {
                SampleEventArgs s = new SampleEventArgs();
                s.Sample.Add("Graphics", _controlGraphics);
                s.Sample.Add("ClientSize", DisplayRectangle.Size);
                s.Sample.Add("ClientRectangle", DisplayRectangle);
                s.Sample.Add("Margin", Margin);
                //if (StateChanged != null)
                    //StateChanged(this, s);
            }
            

            
        }
        


        #region IGoodControl Members

        public void Add(IGoodControl somethingToAdd) {
            if (!(somethingToAdd is Control)) {
                Controls.Add(somethingToAdd.Control);
            } else {
                Controls.Add((Control)somethingToAdd);
            }
        }
        GoodProperty<Int32> sizefication;
        public GoodProperty<Int32> Sizefier {
            get {
                return sizefication;
            }
            set {
                sizefication = value;
                Size = new Size(sizefication.Value + Margin.Horizontal, sizefication.Value + Margin.Vertical);
            }
            
        }
        public void WriteGraphics(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("BufferedGraphics"))
            {
                //_controlGraphics = (Graphics)sArgs.Sample["Graphics"];
                BufferedGraphics bg = (BufferedGraphics)sArgs.Sample["BufferedGraphics"];
                bg.Render(CreateGraphics());
            }
            
        }
        public void RequestStateVariables(object sender, SampleEventArgs sArgs)
        {
            //this is here because we call this function from a different thread. We check if thats true (InvokeRequired) and then call it from our own thread
            if (InvokeRequired)
            {
                RequestStateVariables_Callback d = new RequestStateVariables_Callback(RequestStateVariables);
                Invoke(d, new object[] { sender, sArgs });
            }
            else
            {
                SampleEventArgs s = new SampleEventArgs();
                s.Sample.Add("Graphics", CreateGraphics());
                s.Sample.Add("ClientSize", DisplayRectangle.Size);
                s.Sample.Add("ClientRectangle", DisplayRectangle);
                s.Sample.Add("Margin", Margin);
                
                if (StateChanged != null)
                    StateChanged(this, s);
            }
        }


        public void OnBitmapChanged(object sender, EventArgs args)
        {
            if(_controlGraphics == null)
                _controlGraphics = this.CreateGraphics();

            _controlGraphics.SetClip(new Rectangle(
                Margin.Left,
                Margin.Top,
                Size.Width - Margin.Horizontal,
                Size.Height - Margin.Vertical));

            Bitmap b = _variable.Value;
            _controlGraphics.DrawImage(
                b,
                _controlGraphics.VisibleClipBounds,
                new Rectangle(0, 0, b.Size.Width, b.Size.Height),
                GraphicsUnit.Pixel);
        }
        
        #endregion

        #region IGoodControl Members
     

        public IGoodVariable GoodVariableBinding {
            get {
                return _variable as IGoodVariable;
            }
            set {
                _variable = (GoodVariable<Bitmap>)value;
            }
        }

        #endregion
    }
}
