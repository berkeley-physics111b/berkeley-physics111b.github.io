using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;

namespace GoodStuff
{
    class GoodNumeric : IGoodControl
    {
        GoodProperty<double> _value;
        
        NumericUpDown _nud;
        Panel _panel;
        Label _label;
        public event SampleEventHandler NumericValueChanged;
        GoodProperty<string> _text;
        public GoodProperty<string> Text
        {
            get { return _text; }
            set { _text = value; _label.Text = value.Value; }
        }

            


        public GoodProperty<double> Value
        {
            get
            {
                return _value;
            }
            set
            {
                _nud.Value = (decimal)value.Value;
                _value = value;
            }
        }
        public GoodNumeric()
        {
            Trace.WriteLine("GoodNumericUpDown constructor called");
            _value = new GoodProperty<double>();
            _nud = new NumericUpDown();
            _nud.ValueChanged += new EventHandler(_nud_ValueChanged);
            
            _label = new Label();
            _panel = new Panel();
            
            _label.Text = "Default";

            _label.Location = new Point(
                _panel.Margin.Left,
                _panel.Margin.Top + Math.Max(0, (_nud.Height - _label.Height) / 2));
            _nud.Location = new Point(
                _label.Right + _panel.Padding.Horizontal,
                _panel.Margin.Top + Math.Max(0, (_label.Height - _nud.Height) / 2));

            _panel.AutoSize = true;
            _panel.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            _panel.Controls.Add(_label);
            _panel.Controls.Add(_nud);
            _nud.Maximum = 1e16M;
            
        }
        void _nud_ValueChanged(object sender, EventArgs e)
        {
            _value.Value = (double)_nud.Value;

            if (NumericValueChanged != null)
            {
                SampleEventArgs s = new SampleEventArgs();
                s.Sample.Add("Value", _nud.Value);
                NumericValueChanged(this, s);
            }
        }
        #region IGoodControl Members

        public Control Control
        {
            get { return _panel; }
            //          set { _textBox = (TextBox) value; }
        }
        public void Add(IGoodControl somethingToAdd)
        {
            if (!(somethingToAdd is Control))
            {
                _panel.Controls.Add(somethingToAdd.Control);
            }
            else
            {
                _panel.Controls.Add((Control)somethingToAdd);
            }
        }
        protected GoodVariableBase[] _gv;
        protected int pushPopIndex;
        public void pBind(IGoodProperty gProp)
        {
            if (_gv == null)
            {
                _gv = new GoodVariableBase[4];
            }
            Array.Resize(ref _gv, _gv.Length + 1);
            _gv[pushPopIndex] = (GoodVariableBase)gProp;
            pushPopIndex++;
        }
        public void Initialize()
        {
            NumericUpDown _nud = new NumericUpDown();
        }


        public IGoodVariable GoodVariableBinding
        {
            get
            {
                return Value as IGoodVariable;
            }
            set
            {
                Value= (GoodProperty<double>)value;
            }
        }
        #endregion
    }
}
