using GoodStuff;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;

namespace CameraDriver {
    public class Camera : WorkerThread, IInitializable {
        
        public event SampleEventHandler UIUpdate;
        public event SampleEventHandler BitmapsReady;
        public event SampleEventHandler ReportStatus;
        public SampleEventArgs initialArgs;
        public static DateTime StartedCapture;
        GoodVariable<Rectangle> captureRegion;
        GoodVariable<Rectangle> newCaptureRegion;

        //PassThruForm state
        bool _shiftPressed;
        bool _controlPressed;
        bool EchoDebug; 
        Size FormPassThruSize;
        Rectangle FormPassThruClientRectangle;

        #region Instance Variables

/*
        RawFrameProcessor rfpInstance;
        public RawFrameProcessor RFPInstance {
            get {
                return rfpInstance;
            }
            set {
                rfpInstance = value;
                FrameComplete += rfpInstance.ProcessFrame;
            }
        }
  */      
        IntPtr _cameraHandle;
        public IntPtr CameraHandle {
            get { return _cameraHandle; }
            set { _cameraHandle = value; }
        }
     
        enum AcquisitionMode {
            Idle = 0,
            Continuous = 1,
            Shot = 2
        }
        AcquisitionMode _specifiedMode;
        AcquisitionMode _acquisitionMode;

        ArrayList _parameters = new ArrayList();

        #endregion

        #region Instance Variables and Properties for Buffers
        public int SpecifiedMode {
            get {
                return (int) _specifiedMode;
            }
            set {
                _specifiedMode = (AcquisitionMode) value;
            }
        }

        public void Initialize() {
            
            StartedCapture = DateTime.Now; //start the clock
            Open();        
            if (_specifiedMode == AcquisitionMode.Continuous) {
                this.StartContinuousImaging();
            }
            if (_specifiedMode == AcquisitionMode.Shot) {
                this.StartShotMode(this, new SampleEventArgs());
            }
        }
        public void init(object sender, SampleEventArgs sArgs)
        {
            initialArgs = sArgs;
            Initialize();
        }

        static OrderedDictionary _allocatedBuffers;
        public OrderedDictionary AllocatedBuffers { get { return _allocatedBuffers; } }
        UInt32 _bufferIndex = 0;
        int _numberOfBuffers;
        public int NumberOfBuffers {
            get { return _numberOfBuffers; }
            set { _numberOfBuffers = value; }
        }
        public int AllocatedBufferCount {
            get { return _allocatedBuffers.Count; }
        }
        UInt32 _frameSize;
        public UInt32 FrameSize {
            get { return _frameSize; }
        }
        static DriverFunctions.PdtFrameCallback _onFrameAcquired = OnFrameAcquired;
        ThreadSafeQueue<SampleEventArgs> _bufferQueue;
        #endregion

        #region Instance Variables and Properties for Image Format
        DriverFunctions.PdtImageFormat _format;
        public DriverFunctions.PdtImageFormat Format {
            get { return _format; }
            set { _format = value; }
        }
        UInt32 _formatSupport;
        public UInt32 FormatSupport {
            get { return _formatSupport; }
        }

        private GoodVariable<Size> _maximumImageDimensions;
        public GoodVariable<Size> MaxImageDimensions
        {
            get { return _maximumImageDimensions; }
            set { _maximumImageDimensions = (GoodVariable<Size>)value; }
        }
        UInt32 _numberOfPixels;
        public UInt32 NumberOfPixels {
            get { return _numberOfPixels; }
        }
        UInt32 _pixelSize;
        public UInt32 PixelSize {
            get { return _pixelSize; }
        }
        #endregion

        #region Constructor, Destructor, and Dispose
        public Camera() {
            Trace.WriteLine("Camera Constructor Called");
            
            // set default values
            _numberOfBuffers = 1;

            // create external variables
            _maximumImageDimensions = new GoodVariable<Size>();
            _maximumImageDimensions.Name = "MaximumImageDimensions";
            _maximumImageDimensions.DisplayName = "Maximum Image Dimensions";


            _parameters = new ArrayList();
            _allocatedBuffers = new OrderedDictionary();
            _bufferQueue = new ThreadSafeQueue<SampleEventArgs>(25);
            _acquisitionMode = AcquisitionMode.Idle;
            
            Format = DriverFunctions.PdtImageFormat.fmtRgb24;
            
            //Initialize();
            captureRegion = new GoodVariable<Rectangle>();
            captureRegion.Value = new Rectangle(0, 0, 200, 200);
            newCaptureRegion = new GoodVariable<Rectangle>();
            newCaptureRegion.Value = captureRegion.Value;

            EchoDebug = false;
        }

        #region Idispose
        public void Dispose(object sender, SampleEventArgs sArgs) {
            Trace.WriteLine("Camera.Dispose() called on handle: " + _cameraHandle.ToString());

            if (_acquisitionMode == AcquisitionMode.Continuous)
                StopContinuousImaging();
            if (_acquisitionMode == AcquisitionMode.Shot)
                StopShotMode(this, new SampleEventArgs());

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            Close();
            DisposeBuffers();
            GC.SuppressFinalize(this);
        }
        #endregion
        ~Camera() {
            Dispose(this, new SampleEventArgs());
        }
        #endregion

        #region Count, Open, and Close
        static public UInt32 Count() {
            DriverFunctions.PdtCamListItem item = new DriverFunctions.PdtCamListItem();
            UInt32 numberOfCameras;

            UInt32 connectedNumber;
            numberOfCameras = DriverFunctions.PdListCameras(ref item, 1, out connectedNumber);
            return connectedNumber;
        }

        private CameraParameter paramGain;

        public CameraParameter ParamGain {
            get {
                return paramGain;
            }
            set {
                paramGain = value;
            }
        }

        

        public IntPtr Open() {
            Trace.WriteLine("Camera.Open() called");
            DriverFunctions.PdtErr errcode;
            DriverFunctions.PdtCamListItem item = new DriverFunctions.PdtCamListItem();

            try {
                UInt32 connectedNumber;
                UInt32 numberOfCameras = DriverFunctions.PdListCameras(ref item, 1, out connectedNumber);
                if (connectedNumber >= 1) {
                    errcode = DriverFunctions.PdOpenCamera(item.UniqueId, out _cameraHandle);
                    if (errcode != DriverFunctions.PdtErr.errSuccess)
                        throw (new Exception("Could not open camera"));
                }

                // get all the parameters for this camera

                DriverFunctions.PdGetFrameSize(_cameraHandle, out _frameSize, out _numberOfPixels, out _pixelSize);
                DriverFunctions.PdGetFormatSupport(_cameraHandle, out _formatSupport);
                DriverFunctions.PdGetFormat(_cameraHandle, out _format);

                UInt32 maxWidth, maxHeight;
                DriverFunctions.PdGetRegionMax(_cameraHandle, out maxWidth, out maxHeight);
                _maximumImageDimensions.Value = new Size((int)maxWidth, (int)maxHeight);

                for (PdtParamKey k = 0; k < PdtParamKey.__param_count; ++k) {
                    CameraParameter p = new CameraParameter(this, k, "");
                    p.Update();
                    _parameters.Add(p);
                }
                CameraParameter paramGain = new CameraParameter(this, PdtParamKey.paramGain, "paramGain");
                paramGain.DisplayName = "Gain";
                
//                StateStore.Store.AddVariable((GoodNumericVariable<UInt32>)paramGain);
                CreateThread(
                    "Camera " + _cameraHandle.ToString() + " acquisition thread",
                    System.Threading.ThreadPriority.Normal);
                StartThread();

            } catch (Exception e) {
                System.Diagnostics.Trace.WriteLine(e.Message);
            }

            return _cameraHandle;
        }

        public void Close() {
            Trace.WriteLine("Camera.Close() called on camera " + _cameraHandle.ToString());

            StopThread();
            DriverFunctions.PdAbortFrames(_cameraHandle);
            if (_acquisitionMode == AcquisitionMode.Continuous)
                StopContinuousImaging();
            if (_cameraHandle != IntPtr.Zero)
                DriverFunctions.PdCloseCamera(_cameraHandle);
            _cameraHandle = IntPtr.Zero;
        }

        #endregion
        #region Countinuous Imaging

        public void StartContinuousImaging() {
            Trace.WriteLine("Starting continuous imaging on " + _cameraHandle.ToString());

            _acquisitionMode = AcquisitionMode.Continuous;
            DriverFunctions.PdSetFormat(_cameraHandle, _format);
            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeStreaming);
            AllocateBuffers();
        }
        public void StopContinuousImaging() {
            Trace.WriteLine("Stopping continuous imaging on " + _cameraHandle.ToString());

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            DisposeBuffers();
            _acquisitionMode = AcquisitionMode.Idle;
        }
        #endregion Continuous Imaging
        #region Shot Mode
        public void StartShotMode(object sender, SampleEventArgs sArgs) {
            NumberOfBuffers = 25;

            Trace.WriteLine("Shot Mode set on camera " + _cameraHandle.ToString());

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            _acquisitionMode = AcquisitionMode.Shot;
            DriverFunctions.PdSetFormat(_cameraHandle, _format);
            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeShot);
            AllocateBuffers();
        }
        public void StopShotMode(object sender, SampleEventArgs sArgs)
        {
            Trace.WriteLine("Shot Mode stopped on camera " + _cameraHandle.ToString());

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            DriverFunctions.PdAbortFrames(_cameraHandle);
            DisposeBuffers();
            _acquisitionMode = AcquisitionMode.Idle;
        }
        public void TriggerShot(object sender, SampleEventArgs sArgs) 
        {
            DriverFunctions.PdTrigger(_cameraHandle, 1);
        }
        #endregion Shot Mode
        #region Frame Reduction to Bitmaps and data Arrays and UI interation
        public void ReportStatusLocal(string messageout)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("Message", messageout);
            if(ReportStatus!=null)
                ReportStatus(this, s);
        }
        public void PassThruStateChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("ClientSize"))
                FormPassThruSize = (Size)sArgs.Sample["ClientSize"];
            if (sArgs.Sample.ContainsKey("ClientRectangle"))
                FormPassThruClientRectangle = (Rectangle)sArgs.Sample["ClientRectangle"];
        }
        public void PassThruMouseClick(object sender, SampleEventArgs sArgs)
        {
            System.Windows.Forms.MouseEventArgs mArgs;
            if (sArgs.Sample.ContainsKey("MouseArgs"))
                mArgs = (System.Windows.Forms.MouseEventArgs)sArgs.Sample["MouseArgs"];
            else
                return;

            Size max = MaxImageDimensions.Value;
            //((GoodVariable<Size>)StateStore.Store["MaximumImageDimensions"]).Value;

            if (!_shiftPressed && !_controlPressed)
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width);
                x = Math.Max(0, x);
                x = Math.Min(max.Width - captureRegion.Value.Width, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height);
                y = Math.Max(0, y);
                y = Math.Min(max.Height - captureRegion.Value.Height, y);
                newCaptureRegion.Value = new Rectangle(
                    x,
                    y,
                    captureRegion.Value.Width,
                    captureRegion.Value.Height);
            }
            else if (!_controlPressed)
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);
                newCaptureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    y);
            }
            else
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);

                x = Math.Max(x, y);
                x = Math.Min(Math.Min(x, max.Width - captureRegion.Value.X), max.Height - captureRegion.Value.Y);
                //y = Math.Max(x, y);
                newCaptureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    x);
            }
            ReportStatusLocal("CaptureRegion Changed. size:" + captureRegion.Value.Width.ToString() + " by " + captureRegion.Value.Height.ToString() + " pixels");

        }
        public void PassThruKeyUpDown(object sender, SampleEventArgs sArgs)
        {
            System.Windows.Forms.KeyEventArgs kArgs;
            if (sArgs.Sample.ContainsKey("KeyArgs"))
                kArgs = (System.Windows.Forms.KeyEventArgs)sArgs.Sample["KeyArgs"];
            else
                return;
            _shiftPressed = kArgs.Shift;
            _controlPressed = kArgs.Control;
        }
        public void ReduceFrame(object sender, SampleEventArgs inParticlePacket)
        {

            Size maxCaptureSize = new Size();
            GoodVariable<Bitmap> _captureBitmap = new GoodVariable<Bitmap>();
            GoodVariable<Bitmap> _passthruBitmap = new GoodVariable<Bitmap>();

            if (maxCaptureSize.IsEmpty)
            {
                if (inParticlePacket.Sample.ContainsKey("MaximumImageDimensions"))
                    maxCaptureSize = ((GoodVariable<Size>)inParticlePacket.Sample["MaximumImageDimensions"]).Value;
                else
                    maxCaptureSize = new Size(659, 493);
            }

            FrameInfo fi = inParticlePacket.Sample["FrameInfo"] as FrameInfo;
            //                        Trace.Assert(fi != null, "Invalid FrameInfo retreived by RawFrameProcessor");

            #region bitMassage
            bool isColor = false;
            if ((fi.Format == DriverFunctions.PdtImageFormat.fmtRgb24) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw8) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw16) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRgb48))
                isColor = true;

            // create a bitmap from the captured data buffer for display in the passthru window
            // generate a histogram of values
            // generate a monochrome bitmap if the capture mode is color
            // create a Frame structure and put all of that into it

            // allocate a new Frame structure to hold the capture region
            //Frame captureFrame = new Frame();

            Bitmap mono = null, color = null;
            BitmapData monoData = null, colorData = null;
            if (isColor)
            {
                color = new Bitmap(
                    (int)fi.Width,
                    (int)fi.Height,
                    System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                colorData = color.LockBits(
                    new Rectangle(0, 0, color.Width, color.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format24bppRgb);
            }
            else
            {
                // allocate a monochrome bitmap the size of the captured buffer
                mono = new Bitmap(
                        (int)fi.Width,
                        (int)fi.Height,
                        System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                MonochromeBitmapFunctions.SetMonochromePalette(mono);
                monoData = mono.LockBits(
                    new Rectangle(0, 0, mono.Width, mono.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format8bppIndexed);
            }

            Bitmap monoCapture = null;
            Bitmap colorCapture = null;
            BitmapData monoCaptureData = null, colorCaptureData = null;

            // allocate a monochrome bitmap for the capture region

            Rectangle captureRectangle;
            captureRectangle = captureRegion.Value;

            Byte[,] monoArray = new Byte[captureRectangle.Width, captureRectangle.Height];

            monoCapture = new Bitmap(
                captureRectangle.Width,
                captureRectangle.Height,
                System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
            MonochromeBitmapFunctions.SetMonochromePalette(monoCapture);
            inParticlePacket.Sample.Add("Bitmap 8BppMonoCapture", monoCapture);
            monoCaptureData = monoCapture.LockBits(
                new Rectangle(0, 0, monoCapture.Width, monoCapture.Height),
                ImageLockMode.ReadWrite,
                PixelFormat.Format8bppIndexed);

            int xx = 0, yy = 0;
            // allocate a color bitmap for the capture rectangle if in a color capture mode
            if (isColor)
            {
                colorCapture = new Bitmap(
                    captureRectangle.Width,
                    captureRectangle.Height,
                    System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                inParticlePacket.Sample.Add("CaptureBitmap", colorCapture);
                colorCaptureData = colorCapture.LockBits(
                    new Rectangle(0, 0, colorCapture.Width, colorCapture.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format24bppRgb);

            }

            // allocate an array to hold the brightness histogram
            // histogram is only of capture region
            int[] histogram = new int[256];

            switch (fi.Format)
            {

                case DriverFunctions.PdtImageFormat.fmtMono8:
                    //                    Debug.Assert(fi.Owner.PixelSize == 1, "Unexpected pixel size");
                    unsafe
                    {
                        Byte* i = (Byte*)fi.Buffer;
                        Byte* o = (Byte*)monoData.Scan0;
                        Byte* firstLineOfCapture =
                            i +                                                         // beginning of buffer
                            captureRectangle.Y * fi.Width;                              // down Y
                        Byte* firstLineAfterCapture =
                            firstLineOfCapture +                                       // start of capture area
                            captureRectangle.Height * fi.Width;                        // down height
                        Byte* endOfLine = i + monoData.Width;
                        Byte* lastInputPixel = i + fi.Width * fi.Height;
                        int padding = monoData.Stride - monoData.Width;

                        // copy the region up to the beginning of the capture rectangle
                        while (i < firstLineOfCapture)
                        {
                            while (i < endOfLine)
                            {
                                *o++ = *i++;
                            }
                            o += padding;
                            endOfLine += fi.Width;
                        }

                        // copy the region from the top to the bottom of the capture rectangle to 
                        // both the passthru and the capture bitmaps
                        Byte* captureStart = i + captureRectangle.X;
                        Byte* captureStop = captureStart + captureRectangle.Width;
                        Byte* capturePointer = (Byte*)monoCaptureData.Scan0;
                        int capturePadding = monoCaptureData.Stride - monoCaptureData.Width;

                        while (i < firstLineAfterCapture)
                        {
                            while (i < captureStart)
                            {
                                *o++ = *i++;
                            }
                            while (i < captureStop)
                            {
                                
                                ++histogram[*i];
                                *capturePointer++ = *i;
                                monoArray[xx, yy] = *i;
                                *o++ = *i++;
                                xx++;
                           }
                            yy++; xx = 0;
                            while (i < endOfLine)
                            {
                                *o++ = *i++;
                            }
                            endOfLine += fi.Width;
                            captureStart += fi.Width;
                            captureStop += fi.Width;
                            o += padding;
                            capturePointer += capturePadding;
                        }

                        // copy the remainder of the captured image into the passthru buffer
                        while (i < lastInputPixel)
                        {
                            while (i < endOfLine)
                            {
                                *o++ = *i++;
                            }
                            o += padding;
                            endOfLine += fi.Width;
                        }
                    }
                    break;

                case DriverFunctions.PdtImageFormat.fmtRgb24:

                    //                    Debug.Assert(fi.Owner.PixelSize == 3, "Unexpected pixel size");
                    unsafe
                    {
                        Byte* i = (Byte*)fi.Buffer;
                        Byte* o = (Byte*)colorData.Scan0;
                        Byte* firstLineOfCapture =
                            i +                                                         // beginning of buffer
                            3 * captureRectangle.Y * fi.Width;                          // down Y
                        Byte* firstLineAfterCapture =
                            firstLineOfCapture +                                        // start of capture area
                            3 * captureRectangle.Height * fi.Width;                     // down height
                        Byte* endOfLine = i + 3 * colorData.Width;
                        Byte* lastInputPixel = i + 3 * fi.Width * fi.Height;
                        int padding = colorData.Stride - 3 * colorData.Width;
                        Byte* monoCapturePointer = (Byte*)monoCaptureData.Scan0;
                        int monoCapturePadding = monoCaptureData.Stride - monoCaptureData.Width;
                        Byte* colorCapturePointer = (Byte*)colorCaptureData.Scan0;
                        int colorCapturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;
                        Byte r, g, b, y;


                        // copy the region up to the beginning of the capture rectangle
                        // change the order for the silly Windows BGR ordering
                        while (i < firstLineOfCapture)
                        {
                            while (i < endOfLine)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            o += padding;
                            endOfLine += 3 * fi.Width;
                        }

                        // copy the region from the top to the bottom of the capture rectangle to 
                        // both the passthru and the capture bitmaps
                        Byte* captureStart = i + 3 * captureRectangle.X;
                        Byte* captureStop = captureStart + 3 * captureRectangle.Width;
                        Byte* capturePointer = (Byte*)colorCaptureData.Scan0;
                        int capturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;
                        
                        while (i < firstLineAfterCapture)
                        {
                            while (i < captureStart)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            while (i < captureStop)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;

                                *colorCapturePointer++ = b;
                                *colorCapturePointer++ = g;
                                *colorCapturePointer++ = r;

                                y = (Byte)((77 * r + 150 * g + 29 * b) >> 8);
                                ++histogram[y];
                                *monoCapturePointer++ = y;
                                monoArray[xx, yy] = y;
                                xx++;
                            }
                            yy++; xx = 0;
                            while (i < endOfLine)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            endOfLine += 3 * fi.Width;
                            captureStart += 3 * fi.Width;
                            captureStop += 3 * fi.Width;
                            o += padding;
                            capturePointer += capturePadding;
                            monoCapturePointer += monoCapturePadding;
                            colorCapturePointer += colorCapturePadding;
                        }

                        // copy the remainder of the captured image into the passthru buffer
                        while (i < lastInputPixel)
                        {
                            while (i < endOfLine)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            o += padding;
                            endOfLine += 3 * fi.Width;
                        }
                    }
                    break;
            }

            // release all of the bitmaps created
            if (monoData != null)
                mono.UnlockBits(monoData);
            if (colorData != null)
                color.UnlockBits(colorData);
            if (monoCaptureData != null)
                monoCapture.UnlockBits(monoCaptureData);
            if (colorCaptureData != null)
                colorCapture.UnlockBits(colorCaptureData);

            // find the blobs
            //Blob[] blobs = BlobFinder.FindBlobs(monoCapture, _threshold.Value);

            // update the passthru bitmap
            if (isColor)
                _passthruBitmap.Value = color;
            else
                _passthruBitmap.Value = mono;

            // update _captureBitmap for the preview window, etc...
            if (isColor)
                _captureBitmap.Value = colorCapture;
            else
                _captureBitmap.Value = monoCapture;

            #endregion bitMassage

            inParticlePacket.Sample.Add("PassthruBitmap", _passthruBitmap);
            if (inParticlePacket.Sample.ContainsKey("CaptureBitmap"))
                inParticlePacket.Sample["CaptureBitmap"] = _captureBitmap.Value;
            else
                inParticlePacket.Sample.Add("CaptureBitmap", _captureBitmap.Value);
            inParticlePacket.Sample.Add("CaptureRegionArray", monoArray);
            inParticlePacket.Sample.Add("CaptureRegion", captureRegion);

            inParticlePacket.Sample.Add("SourceName", "Camera");

            BitmapsReady(this, inParticlePacket);


        }


        #endregion

        #region Callback -- handle completed frame
        /// <summary>
        /// Callback function for Prosilica driver -- never called from user code
        /// </summary>
        /// <param name="f">acquired PdtFrame</param>
        static void OnFrameAcquired(ref DriverFunctions.PdtFrame f) {
            // find the camera object that owns the acquired PdtFrame
            uint i = FrameInfo.GetFrameIndex(f);                                    // frame index points to the owner
            FrameInfo fi = (FrameInfo)_allocatedBuffers[i];                         // look it up in the allocated buffer list
            
            
            if (fi == null)
                throw (new Exception("Buffer returned was not in allocated buffer list"));

            SampleEventArgs s = new SampleEventArgs();
            
            s.Sample.Add("FrameInfo", fi);
            s.Sample.Add("Time", DateTime.Now);

            fi.Owner.HandleFrame(s);                                               // queue the buffer for processing by the worker thread
        }

        /// <summary>
        /// Do not call -- only called by OnFrameAcquired.
        /// </summary>
        /// <param name="fi">FrameInfo structure containing acquired frame</param>
        public void HandleFrame(SampleEventArgs s) {

            FrameInfo fi = s.Sample["FrameInfo"] as FrameInfo;
            
            Trace.Assert(_acquisitionMode != AcquisitionMode.Idle, "HandleFrame called whilst in idle mode");

            if (fi.Status != DriverFunctions.PdtErr.errCancelled)                   // ignore cancelled frame (after abort)
            {
                if (fi.Status != DriverFunctions.PdtErr.errSuccess)                 // make sure frame status is good
                    throw (new Exception("HandleFrame: Frame returned with error " + fi.Status.ToString()));

                if (_acquisitionMode != AcquisitionMode.Idle)                       // check for stale buffer
                    _bufferQueue.Enqueue(s);                                       // queue the buffer for processing by the worker thread-
            }
        }
        #endregion Callback
        /// <summary>
        /// Function runs in its own thread for handling acquired frames queued in the _bufferQueue
        /// </summary>
        override protected void ThreadProc() {
            int FrameNumber = 1;
            while (KeepGoing()) {
                FrameInfo fi;
                _bufferQueue.Wait(250);
                while (_bufferQueue.Count > 0) {
                    //TODO: there is a race condition here if the queue is cleared
                    SampleEventArgs sArgs = _bufferQueue.Dequeue() as SampleEventArgs;
                    fi = (FrameInfo)sArgs.Sample["FrameInfo"];
                    Debug.Assert(fi != null && fi.Buffer != null, "Invalid frame buffer!");
                    if (captureRegion.Value != newCaptureRegion.Value)
                        captureRegion = newCaptureRegion;
                    // create a Frame structure
                   // if (FrameComplete != null) {
                                                
                        FrameNumber++;
                        sArgs.Sample.Add("FrameNumber", FrameNumber);//just indexing the frames
                        sArgs.Sample.Add("MaximumImageDimensions", MaxImageDimensions);
                        //fcea.Frame._objects.Add("FrameInfo", fi);
                        DateTime start = DateTime.Now;
                        ReduceFrame(this, sArgs);
                        TimeSpan S = DateTime.Now - start;
                        if(EchoDebug)
                            ReportStatusLocal("Reducing took " + S.TotalMilliseconds);
                        //FrameComplete(this, sArgs);
                    //} else {
                        //DriverFunctions.PdQueueFrame(_cameraHandle, fi.FramePtr, cb);
                    //}
                    

                }
            }
        }



        #region IFrameProcessor Members
        public event SampleEventHandler FrameComplete;

        // the following declaration is included to prevent having to do any monkey business with the callback
        // delegate -- the runtime complains that a callback on a garbage collected delegate is taking place
        // otherwise this static declaration should never be CGd
        static DriverFunctions.PdtFrameCallback cb = new DriverFunctions.PdtFrameCallback(OnFrameAcquired);

        // take back the complete frames and requeue them
        public void FrameReturned(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("SourceName") && sArgs.Sample["SourceName"] == "Camera")
            {
                if (_acquisitionMode != AcquisitionMode.Idle && sArgs.Sample.ContainsKey("FrameInfo"))
                {
                    FrameInfo fi = sArgs.Sample["FrameInfo"] as FrameInfo;
                    if (fi == null)
                        throw (new Exception("Invalid frame returned to Camera in frame queue"));

                    DriverFunctions.PdQueueFrame(fi.Owner.CameraHandle, fi.FramePtr, cb);
                }
            }
        }

        #endregion
        public void AllocateBuffers() {
            Trace.WriteLine("Allocating " + _numberOfBuffers.ToString() + "buffers for camera " + _cameraHandle.ToString());

            DriverFunctions.PdtErr error;
            // make sure frame size variables are updated
            error = DriverFunctions.PdGetFrameSize(_cameraHandle, out _frameSize, out _numberOfPixels, out _pixelSize);

            for (int i = 0; i < _numberOfBuffers; ++i) {
                FrameInfo fi = new FrameInfo(_frameSize);
                fi.SetContext(0, _bufferIndex);
                fi.Owner = this;
                _allocatedBuffers.Add(_bufferIndex, fi);

                ++_bufferIndex;

                error = DriverFunctions.PdQueueFrame(_cameraHandle, fi.FramePtr, _onFrameAcquired);
                if (error != DriverFunctions.PdtErr.errSuccess)
                    throw (new Exception("Error returned when queueing frame"));
            }
        }
        public void DisposeBuffers() {
            Trace.WriteLine("Disposing of buffers for camera " + _cameraHandle.ToString());

            _bufferQueue.Clear();
            DriverFunctions.PdAbortFrames(_cameraHandle);
            IDictionaryEnumerator i = _allocatedBuffers.GetEnumerator();
            while (i.MoveNext()) {
                FrameInfo fi = i.Value as FrameInfo;
                if (fi != null)
                    fi.Dispose();
            }
            _allocatedBuffers.Clear();
        }

    
    }

    public unsafe class FrameInfo
    {
        DriverFunctions.PdtFrame* _framePtr;
        public IntPtr FramePtr { get { return (IntPtr)_framePtr; } }
        Camera _owner;
        public Camera Owner { get { return _owner; } set { _owner = value; } }

        #region PdtFrame Structure Field Accessors

        //-----	In -----

        public IntPtr Buffer
        {
            get { return _framePtr->Buffer; }
            set { _framePtr->Buffer = value; }
        }
        public UInt32 BufferSize			        // Size of your image buffer in bytes
        {
            get { return _framePtr->BufferSize; }
            set { _framePtr->BufferSize = value; }
        }

        public void SetContext(int index, UInt32 i)
        {
            _framePtr->Context[index] = i;
        }

        public UInt32 GetContext(int index)
        {
            return _framePtr->Context[index];
        }
        //-----	Out -----

        public DriverFunctions.PdtErr Status				// Status of this frame (PdtErr marshalled as Int32)
        {
            get { return _framePtr->Status; }
        }
        public DriverFunctions.PdtImageFormat Format { get { return _framePtr->Format; } }
        public UInt32 BitDepth { get { return _framePtr->BitDepth; } }
        public UInt32 Width { get { return _framePtr->Width; } }
        public UInt32 Height { get { return _framePtr->Height; } }
        public UInt32 Size { get { return _framePtr->Size; } }				        // Frame size, in bytes

        public UInt32 FrameCount { get { return _framePtr->FrameCount; } }
        public UInt32 Timestamp { get { return _framePtr->Timestamp; } }
        public UInt32 Tag { get { return _framePtr->Tag; } }

        public UInt32 BayerPattern { get { return _framePtr->BayerPattern; } }

        //public fixed UInt32 _reserved2[30];

        #endregion

        public FrameInfo(UInt32 bufferSize)
        {
            Trace.WriteLine("FrameInfo constructor called");

            _framePtr = (DriverFunctions.PdtFrame*)Marshal.AllocHGlobal(sizeof(DriverFunctions.PdtFrame));
            if (_framePtr == null)
                throw (new Exception("FrameInfo: Unable to allocate unmanaged memory"));

            _framePtr->Buffer = Marshal.AllocHGlobal((int)bufferSize);
            if (_framePtr->Buffer == null)
                throw (new Exception("FrameInfo: Unable to allocate unmanaged memory"));

            _framePtr->BufferSize = bufferSize;
        }

        ~FrameInfo()
        {
            Trace.WriteLine("Warning: FrameInfo destructor called -- object was not Disposed");
            Dispose();
        }

        public void Dispose()
        {
            Trace.WriteLine("FrameInfo Dispose() called");
            if (_framePtr != null)
            {
                Marshal.FreeHGlobal((IntPtr)_framePtr->Buffer);
                Marshal.FreeHGlobal((IntPtr)_framePtr);
                _framePtr = null;
            }
            else
                Trace.WriteLine("Warning: Dispose() called on FrameInfo object with null _framePtr");

            GC.SuppressFinalize(this);
        }

        public static uint GetFrameIndex(DriverFunctions.PdtFrame f)
        {
            uint i;
            unsafe
            {
                i = f.Context[0];
            }
            return i;
        }
       /* public Bitmap ToBitmap()
        {
           
            Bitmap inputImage = new Bitmap(1024, 1024);
            
            System.Drawing.Imaging.PixelFormat a ;//= new System.Drawing.Imaging.PixelFormat;
            //a = System.Drawing.Imaging.PixelFormat.;
            System.Drawing.Imaging.BitmapData bd = inputImage.LockBits(
                    new Rectangle(0, 0, inputImage.Width, inputImage.Height),
                    System.Drawing.Imaging.ImageLockMode.ReadOnly,
                    a);
            
            Bitmap B = new Bitmap((int)Width, (int)Height, 1, System.Drawing.Imaging.PixelFormat.Format8bppIndexed, bd.Scan0);
            return B;
        }*/
    }
}
