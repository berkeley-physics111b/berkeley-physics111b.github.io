using System;
using System.Collections.Generic;
using System.Text;
using  System.Drawing;

namespace CameraDriver {

    public delegate void GenericEventHandler(object sender, GenericEventArgs args);


    public class GenericEventArgs : EventArgs
    {
        Frame frame;

        public GenericEventArgs(Frame f)
        {
            frame = f;
        }

        public Frame Frame
        {
            get { return frame; }
            set { frame = value; }
        }
    }

    
        public interface IFrameProcessor {
            void ProcessFrame(object sender, GenericEventHandler args);
            event GenericEventHandler FrameComplete;
        }

        public class Frame {
            public Dictionary<string, object> _objects;

            public Frame() {
                _objects = new Dictionary<string, object>();
            }
        }
    }
