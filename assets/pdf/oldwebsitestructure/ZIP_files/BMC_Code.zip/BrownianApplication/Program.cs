using System;
using System.Collections.Generic;
using System.Windows.Forms;
using GoodStuff;
using CameraDriver;
using System.Threading;
using BrownianMotion;
namespace BrownianApplication
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Dictionary<string, object> o = new Dictionary<string, object>();
            GoodObjectBuilder.ReadFile("brownianMotion.xml");
            //Camera cam = ObjectManager.Get("Camera") as Camera;
            //Camera Cam = ObjectManager.Get("camera") as Camera;

            GoodWindow GW = ObjectManager.Get("ControlWindow") as GoodWindow;
            Thread MyThread = new Thread(new ThreadStart(GW.Run));
            MyThread.Start();
            GoodWindow PTW = ObjectManager.Get("PassThruWindow") as GoodWindow;
            Thread MyThread2 = new Thread(new ThreadStart(PTW.Run));
            MyThread2.Start();
            GoodWindow IW = ObjectManager.Get("ImageWindow") as GoodWindow;
            Thread MyThread3 = new Thread(new ThreadStart(IW.Run));
            MyThread3.Start();
            //GoodPlotWindow2 PW = ObjectManager.Get("Plot") as GoodPlotWindow2;
            //Thread MyThread4 = new Thread(new ThreadStart(PW.Run));
            //MyThread4.Start();            


//            BioPhysicsUI BPUI = ObjectManager.Get("bioPhysicsUI") as BioPhysicsUI;
  //          Thread MyThread4 = new Thread(new ThreadStart(BPUI.Start));
            //MyThread2.Start();
            //Application.Run(BPUI.formPassthru);
            
            //cam.Close();
            //Cam.Close(); 
        }
    }
}