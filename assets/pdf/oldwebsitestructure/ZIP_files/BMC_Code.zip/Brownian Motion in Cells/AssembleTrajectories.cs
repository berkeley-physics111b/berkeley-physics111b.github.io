using System;

/// <summary>
/// Summary description for Class1
/// </summary>
/// 


// John Crocker's algorithm in MatLab needs to be cloned into C#
//% ; This code 'track.pro' is copyright 1999, by John C. Crocker. 
//% ; It should be considered 'freeware'- and may be distributed freely 
//% ; (outside of the military-industrial complex) in its original form 
//% ; when properly attributed.

partial class ParticleTracker
{
    // assembleTrajectories takes frames of particleInfo and generates 
    // trajectories, which are linked lists of particleInfo
    int memory_b;
        int goodEnough;
        int numFrames;
        int quiet;

    public Trajectory [] assembleTrajectories(ParticlePacket [] particlePackets, int maximumDisplacement,  TrackingParameters parameters)
	{
		
totalFrames = particlePackets.Length;
   
//use default parameters if none given
if (parameters.Default) {
    memory_b=0; // if mem is not needed set to zero
    goodEnough = 0;  // if goodenough is not wanted set to zero
    numFrames = totalFrames - 1;
    quiet=0;
}
else {
    memory_b    =   param.mem;
    goodEnough  =   param.good;
    dim         =   param.dim;
    quiet       =   param.quiet;
}


//checking the input time vector
particlePacket = particlePackets[totalFrames-1];
shiftedParticlePacket = particlePackets.CircShift(1);

shiftedParticlePacket = particlePacket.Subtract(shiftedParticlePacket);

 if  (shiftedParticle.SumNegatives() != 0)
 {
   throw new SystemException("packets are out of order");    
 }
int info = 1;
int [] positiveIndices = shiftedParticlePacket.Positives();
        numPositives = positiveParticlePacket.ParticleInfo.Length;
    numPositives = numPositives+1;

if (positiveParticlePacket.Count ==0) {
    throw new SystemException("All positions are at the same time... go back!")
}
    

// partitioning the data with unique times

//res = unq(t);
//implanting unq directly
       int [] res;
        int [] indices = particlePacket.NotEqual(particlePackets.CircShift(-1));
        count = indices.Length;;
        if (count > 0)
            res = indices;
        else  
            res = length(t) -1;
        
// //////////////////////////////////////////////
        int newResLength = res.Length+2;
int [] newRes;        
        newRes = new int[newResLength];
        newRes[0] = 1;
for(i=0; i<res.Length; i++) {
  newRes[i+1] = res[i];
}
newRes[i+1] = totalFrames;
int nGood = newRes[2]- newRes[1] + 1;
//int [] eyes ;
//eyes = new int[nGood];
ParticlePackets [] posPackets = new ParticlePackets()[nGood];
   for(i=0; i<ngood; i++) {
//        eyes[i] = i+1;
       posPackets[i] = particlePackets[i]; 
    }
int iStart = 2;
int n = ngood;

int zSpan = 50;
if (n > 200)
    zSpan = 20;

if (n > 500) 
    zSpan = 10;

int [,] resX = new int[zSpan, n];
for(i=0; i<zSpan; i++) {
    for (j=0; j<n; j++) {
        resX[i, j] = -1;
    }
}

int [,] bigResX = new intp[numPositives,n];
for(i=0; i<zSpan; i++) {
    for (j=0; j<n; j++) {
        bigResX[i, j] = - 1;
    }
}
    
int [] mem = new int[n];
////  whos resx
////  whos bigresx

int [] uniqId = new int[n];
        for(i=0; i< n; i++) {
            uniqId[i] = i+1;
        }
int maxId = n;
int [] olist = new int[2];

if (goodEnough > 0) {
    int []dumpHash = new int[n];
    int [] nValid = new int[n];
    for(i=0; i<n;i++) {
        nValid[i] =1;
    }
}
   

////  whos eyes;
for(i=0; i<n; i++) {
   resX[0, i] = eyes[i];  
}

//// setting up constants
int maxDisQ = maximumDisplacement^2;

//// John calls this the setup for "fancy code" ???
int notNSqrd = (sqrt(n*nGood) > 200) & (dim < 7);
int notNSqrd = notNSqrd(1);

if (notNSqrd>0) {
//    //;   construct the vertices of a 3x3x3... d-dimensional hypercube
    
    int [,] cube = new int[3^dim,dim];
    
    
    for (d=0; d<dim; d++) {
        int numb = 0;
        for (j=0; j<(3^dim)-1; j=j+3^d) {
            for(k=0; k<(3^d); k++) {
                cube[j+k,d+1] = numb;
            }
            numb = mod(numb+1,3);
        }
    }
    
    
//    //   calculate a blocksize which may be greater than maxdisp, but which
//    //   keeps nblocks reasonably small.  
    
  int   volume = 1;
    for (d = 0; d< dim-1; d++) {
        minn = particlePackets[d].min(positiveIndices);
        maxx = particlePackets[d].max(positiveIndices);
        volume = volume * (maxx-minn);
    }
        blocksize = max( maximumDisplacement, ((volume)/(20*nGood))^(1.0/dim));
}
    ////   Start the main loop over the frames.
for (i=istart; i<numPositives; i++) {
    ispan = mod(i-1,zspan)+1;
//    //disp(ispan)
//    // get new particle positions
    int m = res[i+1] - res[i];
//    res(i);
    int [] eyes = new int[m];
    for(j=0; j<m; j++) {
        eyes[j] = 1;
        eyes[j] = eyes[j] + res[i];
    }
    
    if (m > 0) {
        ParticlePackets [] iPackets = new ParticlePackets[eyes.Length];
        for(k=0; k<eyes.Length; k++) {
          iParticles[k] = particlePackets[eyes[k]];
          int [] found =  new int[m];
        
       // // THE TRIVIAL BOND CODE BEGINS   
        
        if (notNSqrd) {
//            //Use the raster metric code to do trivial bonds
            
//            // construct "s", a one dimensional parameterization of the space 
//            // which consists of the d-dimensional raster scan of the volume.)
            
            ParticlePacket [] abIParticles = new ParticlePackets[iParticles.Length];
            ParticlePacket [] abPosParticles = new ParticlePackets[postParticles.Length];
            abIParticles = iParticles.DivideBy(blocksize);
            abPosParticles = posPacket.DivideBy(blocksize);
            int [] si = new int[m];
            int [] sPos = new int[n];
            int [] dimm = new int[dim];
            int coff = 1;
            int min;
            int max;
            ParticleInfo [] abPos;
            for (j=1; j<dim; j++) {
                ParticlePacket minParticlePacket;
                int minn= min(abiParticles[j].min(), abPosParticles[j].min());
                int maxx= max(abIParticles[j].max(), abPosParticles[j].max());
                abIParticles[j] = abIParticles[j].Subtract(minn);
                abPosParticles[j] = abPosParticles[j].Subtract(minn);
                dimm[j] = maxx-minn + 1;
                si = (abiPosParticles[j].Add(si)).Multiply(coff);
                for(l=0; l<abPosParticles.Length; l++) {
                   sPos[l] = sPos + (abPosParticles[j].Multiply(coff)).;
                }
                coff = dimm(j).*coff;
            }
            nblocks = coff;
           // // trim down (intersect) the hypercube if its too big to fit in the
            //// particle volume. (i.e. if dimm(j) lt 3)
            
            cub = cube;
            deg = find( dimm < 3);
            if (deg.Length()) {
                for(j = 0; j<length(deg)-1; j++) {
                    cub = cub(find(cub(:,deg(j+1)) < dimm(deg(j+1))));
                }
            } 
            
            // calculate the "s" coordinates of hypercube (with a corner @ the origin)
            scube = zeros(length(cub(:,1)),1);
            coff = 1;
            for j=1:dim
                scube = scube + cub(:,j).*coff;
                coff = coff*dimm(j);      
            }
            
            // shift the hypercube "s" coordinates to be centered around the origin
            
            coff = 1;
            for j=1:dim
                if dimm(j) > 3
                    scube = scube - coff;
                }
                coff = dimm(j).* coff;
            }
            scube = mod((scube + nblocks),nblocks);
            // get the sorting for the particles by their "s" positions.
            [ed,isort] = sort(si);
            
            // make a hash table which will allow us to know which new particles
            // are at a given si.
            strt = zeros(nblocks,1) -1;
            fnsh = zeros(nblocks,1);
            h = find(si == 0);
            lh = length(h);
            if lh > 0
                
            si(h) = 1;  
            }
            
    for (j=1; j<m; j++) {
                if (strt(si(isort(j))) == -1) {
                    strt(si(isort(j))) = j;
                    fnsh(si(isort(j))) = j;
                }
                else {
                    fnsh(si(isort(j))) = j;
                }
            }
            if (lh > 0){ 
                si(h) = 0;   
            }
            coltot = zeros(m,1);
            rowtot = zeros(n,1);
            which1 = zeros(n,1);
            for (j=1; j<n; j++) {                               
                map = fix(-1);                
                scub_spos = scube + spos(j);
                s = mod(scub_spos,nblocks);
                whzero = find(s == 0 );
                if (~isempty(whzero)) {
                    nfk = s.NotZero()l;
                    s = s(nfk);
                }
            }
               
            w = s.Equals(-1); 
               
            ngood = length(w);
            ltmax=0;
            if (nGood != 0){
                    s = s(w);
                    for (k=1; k<nGood; k++) {
                        map = [map;isort( strt(s(k)):fnsh(s(k)))];
                    }
            }
                    map = map(2:});
//                     if length(map) == 2
//                         if (map(1) - map(2)) == 0
//                             map = unique(map);
//                          }
//                     }
                    //   map = map(umap);
                    //}
                    // find those trival bonds
                    distq = zeros(length(map),1);
                    for (d=1; d<dim; d++) {     
                        distq = distq + (xyi(map,d) - pos(j,d)).^2;
                    }
                    ltmax = distq < maxdisq;
                    
                    rowtot(j) = sum(ltmax);
                    
                    if rowtot(j) >= 1 
                        w = find(ltmax == 1);
                        coltot( map(w) ) = coltot( map(w)) +1;
                        which1(j) = map( w(1) );
                    }
                }

            }
            
          
            ntrk = fix(n - sum(rowtot == 0));
        
            w = find( rowtot == 1);
            ngood = length(w);

           
            if ngood ~= 0 
                ww = find(coltot( which1(w) ) == 1);
                ngood = length(ww);
                if ngood ~= 0 
                     //disp(size(w(ww)))
                    resx(ispan,w(ww)) = eyes( which1(w(ww)));
                    found( which1( w(ww))) = 1;
                    rowtot( w(ww)) = 0;
                    coltot( which1(w(ww))) = 0;
                }
            }
            
            labely = find( rowtot > 0);
            ngood = length(labely);
            if ngood ~= 0 
                labelx = find( coltot > 0);
                
                nontrivial = 1;
            else
                nontrivial = 0;
            }

        else 
    
            //   or: Use simple N^2 time routine to calculate trivial bonds      
    
            // let's try a nice, loopless way!
            // don't bother tracking perm. lost guys.
            wh = find( pos(:,1) >= 0);
            ntrack = length(wh);
            if ntrack == 0 {
                system.ThrowException('There are no valid particles to track idiot!');
                break
                }
            }
            xmat = zeros(ntrack,m);
            count = 0;
            for kk=1:ntrack
                for ll=1:m
                    xmat(kk,ll) = count;
                    count = count+1;
                }
            }
            count = 0;
            for kk=1:m
                for ll=1:ntrack
                    ymat(kk,ll) = count;
                    count = count+1;
                }
            }

            xmat = (mod(xmat,m) + 1);
            ymat = (mod(ymat,ntrack) +1)';
            [lenxn,lenxm] = size(xmat);
//            whos ymat
//            whos xmat
//            disp(m)

            for d=1:dim
                x = xyi(:,d);
                y = pos(wh,d);
                xm = x(xmat);
                ym = y(ymat(1:lenxn,1:lenxm));
                if size(xm) ~= size(ym)
                    xm = xm';
                }
                
                if d == 1
                    dq = (xm -ym).^2;
                    //dq = (x(xmat)-y(ymat(1:lenxn,1:lenxm))).^2;
                else
                    dq = dq + (xm-ym).^2;
                    //dq = dq + (x(xmat)-y(ymat(1:lenxn,1:lenxm)) ).^2;
                }
            }
            
            ltmax = dq < maxdisq;
            
            // figure out which trivial bonds go with which
            
            rowtot = zeros(n,1);
            rowtot(wh) = sum(ltmax,2);
            
            
            if ntrack > 1 
                coltot = sum(ltmax,1);
            else
                coltot = ltmax;
            }
            which1 = zeros(n,1);
            for j=1:ntrack 
                [mx, w] = max(ltmax(j,:));
                which1(wh(j)) = w;
            }
            
            ntrk = fix( n - sum(rowtot == 0));
            w= find( rowtot == 1) ;
            ngood = length(w);
            if ngood ~= 0
                ww = find(coltot(which1(w)) == 1);
                ngood = length(ww);
                if ngood ~= 0 
                    resx( ispan, w(ww) ) = eyes( which1( w(ww)));
                    found(which1( w(ww))) = 1;
                    rowtot(w(ww)) = 0;
                    coltot(which1(w(ww))) = 0;
                }
            }
            
            labely = find( rowtot > 0);
            ngood = length(labely);
            
            if ngood ~= 0
                labelx = find( coltot > 0);
                nontrivial = 1;
            else
                nontrivial = 0;
            }
        }
        
        //THE TRIVIAL BOND CODE ENS
        
        if nontrivial
            
            xdim = length(labelx);
            ydim = length(labely);
            
            //  make a list of the non-trivial bonds            
            
            bonds = zeros(1,2);
            bondlen = 0;
            
            for j=1:ydim
                distq = zeros(xdim,1);
                
                for d=1:dim
                    //distq
                    distq = distq + (xyi(labelx,d) - pos(labely(j),d)).^2;
                    //distq    
                }
                
                w= find(distq <  maxdisq)' - 1;
                ngood = length(w);
                newb = [w;(zeros(1,ngood)+j)];
                
                
                bonds = [bonds;newb'];
               
                bondlen = [ bondlen;distq( w + 1) ];
                
            }
            bonds = bonds(2:},:);
            
            bondlen = bondlen(2:});
            numbonds = length(bonds(:,1));
            mbonds = bonds;
            max([xdim,ydim]);
                
                
            if max([xdim,ydim]) < 4
                nclust = 1;
                maxsz = 0;
                mxsz = xdim;
                mysz = ydim;
                bmap = zeros(length(bonds(:,1)+1),1) - 1;
               
            else
           

                //   THE SUBNETWORK CODE BEGINS            
                lista = zeros(numbonds,1);
                listb = zeros(numbonds,1);
                nclust = 0;
                maxsz = 0;
                thru = xdim;
                
                while thru ~= 0
                    //  the following code extracts connected 
                    //   sub-networks of the non-trivial 
                    //   bonds.  NB: lista/b can have redundant entries due to 
                    //   multiple-connected subnetworks      
                    
                    
                    w = find(bonds(:,2) >= 0);
   //                 size(w)
                    
                    lista(1) = bonds(w(1),2);
                    listb(1) = bonds(w(1),1);
                    bonds(w(1),:) = -(nclust+1);
                    bonds;
                    adda = 1;
                    addb = 1;
                    donea = 0;
                    doneb = 0;
                    if (donea ~= adda) | (doneb ~= addb)
                        true = 0;
                    else
                    true = 1;   
                    }
                                        
                    while ~true
                        
                        if (donea ~= adda)
                            w = find(bonds(:,2) == lista(donea+1));
                            ngood = length(w);
                            if ngood ~= 0 
                                listb(addb+1:addb+ngood,1) = bonds(w,1);
                                bonds(w,:) = -(nclust+1);
                                addb = addb+ngood;
                            }
                            donea = donea+1;
                        }
                        if (doneb ~= addb) 
                            w = find(bonds(:,1) == listb(doneb+1));
                            ngood = length(w);
                            if ngood ~= 0
                                lista(adda+1:adda+ngood,1) = bonds(w,2);
                                bonds(w,:) = -(nclust+1);
                                adda = adda+ngood;
                            }
                            doneb = doneb+1;
                        }
                      if (donea ~= adda) | (doneb ~= addb) 
                          true = 0;
                      else  
                          true = 1;
                      }
                    }
                    
                    [pp,pqx] = sort(listb(1:doneb));
                    //unx =  unq(listb(1:doneb),pqx);
                    //implanting unq directly
                        arr = listb(1:doneb);
                        q = arr(pqx);
                        indices = find(q ~= circshift(q,-1));
                        count = length(indices);
                        if count > 0
                            unx = pqx(indices);
                        else
                            unx = length(q) -1;
                        }
                    //////////////////////////////////////////////////////////////
                    
                    xsz = length(unx);
                    [pp,pqy] = sort(lista(1:donea));
                    //uny =  unq(lista(1:donea),pqy);
                    //implanting unq directly
                        arr = lista(1:donea);
                        q = arr(pqy);
                        indices = find(q ~= circshift(q,-1));
                        count = length(indices);
                        if count > 0
                            uny = pqy(indices);
                        else
                            uny = length(q) -1;
                        }
                    //////////////////////////////////////////////////////////////                   
                    
                    
                    
                    
                    ysz = length(uny);
                    if xsz*ysz > maxsz
                        maxsz = xsz*ysz;
                        mxsz = xsz;
                        mysz = ysz; 
                    }
                    
                    
                    thru = thru -xsz;
                    nclust = nclust + 1;
                }
                bmap = bonds(:,2);                    
            }
            // THE SUBNETWORK CODE }S
            // put verbose in for Jaci
            
            //   THE PERMUTATION CODE BEGINS
            
            for nc =1:nclust
                w = find( bmap == -1*(nc));
                
                nbonds = length(w);
                bonds = mbonds(w,:);
                lensq = bondlen(w);
                [pq,st] = sort( bonds(:,1));
                //un = unq(bonds(:,1),st);
                   //implanting unq directly     
                        arr = bonds(:,1);
                        q = arr(st);
                        indices = find(q ~= circshift(q,-1));
                        count = length(indices);
                        if count > 0
                            un = st(indices);
                        else
                            un = length(q) -1;
                        }
                    //////////////////////////////////////////////////////////////////////
                
                
                uold = bonds(un,1);
                
                nold = length(uold);
                
                //un = unq(bonds(:,2));
                
                //implanting unq directly  
                indices = find(bonds(:,2) ~= circshift(bonds(:,2),-1));
                count = length(indices);
                    if count > 0
                        un = indices;
                    else  
                        un = length(bonds(:,2)) -1;
                    }
                 //////////////////////////////////////////////////////////////////////   
                    
                unew = bonds(un,2);
                nnew = length(unew);
                
                if nnew > 5
                    rnsteps = 1;
                    for ii =1:nnew
                        rnsteps = rnsteps * length( find(bonds(:,2) == ...
                            unew(ii)));
                        if rnsteps > 5.e+4
                            disp('Warning: difficult combinatorics encountered.')
                        }
                        if rnsteps > 2.e+5
                            disp(['Excessive Combinitorics you FOOL LOOK WHAT YOU HAVE' ...
                                    ' DONE TO ME!!!'])
                            tracks = [];
                            return
                        }
                    }
                }
                st = zeros(nnew,1);
                fi = zeros(nnew,1);
                h = zeros(nbonds,1);
                ok = ones(nold,1);
                nlost = (nnew - nold) > 0;
                
                
                for ii=1:nold 
                    h(find(bonds(:,1) == uold(ii))) = ii;
                }
                st(1) = 1 ;
                fi(nnew) = nbonds; // check this later
                if nnew > 1 
                    sb = bonds(:,2);
                    sbr = circshift(sb,1);
                    sbl = circshift(sb,-1);
                    st(2:}) = find( sb(2:}) ~= sbr(2:})) + 1;
                    fi(1:nnew-1) = find( sb(1:nbonds-1) ~= sbl(1:nbonds-1));
                }
//                if i-1 == 13
//                    hi
//                }
                checkflag = 0;
                while checkflag ~= 2
                    
                    pt = st -1;
                    lost = zeros(nnew,1);
                    who = 0;
                    losttot = 0;
                    mndisq = nnew*maxdisq;
                    
                    
                    while who ~= -1
                    
                        if pt(who+1) ~= fi(who+1)
                            
                            
                            w = find( ok( h( pt( who+1 )+1:fi( who+1 ) ) ) ); // check this -1
                            ngood = length(w);
                            if ngood > 0
                                if pt(who+1) ~= st(who+1)-1
                                    ok(h(pt(who+1))) = 1;
                                }
                                pt(who+1) = pt(who+1) + w(1);
                                ok(h(pt(who+1))) = 0;
                                if who == nnew -1
                                    ww = find( lost == 0);
                                    dsq = sum(lensq(pt(ww))) + losttot*maxdisq;
                                    
                                    if dsq < mndisq 
                                        minbonds = pt(ww);
                                        mndisq = dsq;
                                    }
                                else
                                    who = who+1;
                                }
                            else
                                if ~lost(who+1) & (losttot ~= nlost)
                                    lost(who+1) = 1;
                                    losttot = losttot + 1;
                                    if pt(who+1) ~= st(who+1) -1;
                                        ok(h(pt(who+1))) = 1;
                                    }
                                    if who == nnew-1
                                        ww = find( lost == 0);
                                        dsq = sum(lensq(pt(ww))) + losttot*maxdisq;
                                        if dsq < mndisq
                                            minbonds = pt(ww);
                                            mndisq = dsq;
                                        }
                                    else    
                                       who = who + 1;
                                    }
                                   
                                else
                                    if pt(who+1) ~= (st(who+1) -1) 
                                        ok(h(pt(who+1))) = 1;
                                    }
                                    pt(who+1) = st(who+1) -1;
                                    if lost(who+1) 
                                        lost(who+1) = 0;
                                        losttot = losttot -1;
                                    }
                                    who = who -1;
                                }
                            }
                        else  
                            if ~lost(who+1) & (losttot ~= nlost)
                                lost(who+1) = 1;
                                losttot = losttot + 1;
                                if pt(who+1) ~= st(who+1)-1
                                    ok(h(pt(who+1))) = 1;
                                }
                                if who == nnew -1
                                    ww = find( lost == 0);
                                    dsq = sum(lensq(pt(ww))) + losttot*maxdisq;
                                    
                                    if dsq < mndisq
                                        minbonds = pt(ww);
                                        mndisq = dsq;
                                    }
                                else
                                    who = who + 1;
                                }
                            else
                                if pt(who+1) ~= st(who+1) -1
                                    ok(h(pt(who+1))) = 1;
                                }
                                pt(who+1) = st(who+1) -1;
                                if lost(who+1) 
                                    lost(who+1) = 0;
                                    losttot = losttot -1;
                                }
                                who = who -1;
                            }
                        }
                    }
                    
                    checkflag = checkflag + 1;
                    if checkflag == 1
                        plost = min([fix(mndisq/maxdisq) , (nnew -1)]);
                        if plost > nlost 
                            nlost = plost; 
                        else
                            checkflag = 2;
                        }
                    }
                    
                }  
                //   update resx using the minimum bond configuration               
                
                resx(ispan,labely(bonds(minbonds,2))) = eyes(labelx(bonds(minbonds,1)+1));
                found(labelx(bonds(minbonds,1)+1)) = 1;

            }

            //   THE PERMUTATION CODE }S
        }
        
        w = find(resx(ispan,:) >= 0);
        nww = length(w);
        
        if nww > 0 
            pos(w,:) = xyzs( resx(ispan,w) , 1:dim);
            if goodenough > 0 
                nvalid(w) = nvalid(w) + 1;
            }
        }  //go back and add goodenough keyword thing   
        newguys = find(found == 0);
        
       nnew = length(newguys);
      
        if (nnew > 0) // & another keyword to workout inipos
            newarr = zeros(zspan,nnew) -1;
            resx = [resx,newarr];

            resx(ispan,n+1:}) = eyes(newguys);
            pos = [[pos];[xyzs(eyes(newguys),1:dim)]];
            nmem = zeros(nnew,1);
            mem = [mem;nmem];
            nun = 1:nnew;
            uniqid = [uniqid,((nun) + maxid)];
            maxid = maxid + nnew;
            if goodenough > 0 
                dumphash = [dumphash;zeros(1,nnew)'];
                nvalid = [nvalid;zeros(1,nnew)'+1];
            }
            // put in goodenough 
            n = n + nnew;
                
        }
 
    else
        ' Warning- No positions found for t='
    }
    w = find( resx(ispan,:) ~= -1);
    nok = length(w);
    if nok ~= 0
        mem(w) =0;
    }
    
    mem = mem + (resx(ispan,:)' == -1);
    wlost = find(mem == memory_b+1);
    nlost =length(wlost);

    if nlost > 0 
        pos(wlost,:) = -maxdisp;
        if goodenough > 0
            wdump = find(nvalid(wlost) < goodenough);
            ndump = length(wdump);
            if ndump > 0
                dumphash(wlost(wdump)) = 1;
            }
        }
        // put in goodenough keyword stuff if 
    }
    if (ispan == zspan) | (i == z)
        nold = length(bigresx(1,:));
        nnew = n-nold;
        if nnew > 0
            newarr = zeros(z,nnew) -1;
            bigresx = [bigresx,newarr];
        }
        if goodenough > 0  
            if (sum(dumphash)) > 0
                wkeep = find(dumphash == 0);
                nkeep = length(wkeep);
                resx = resx(:,wkeep);
                bigresx = bigresx(:,wkeep);
                pos = pos(wkeep,:);
                mem = mem(wkeep);
                uniqid = uniqid(wkeep);
                nvalid = nvalid(wkeep);
                n = nkeep;
                dumphash = zeros(nkeep,1);
            }
        }
        
        // again goodenough keyword
        if quiet~=1
            disp(strcat(num2str(i), ' of ' ,num2str(z), ' done.  Tracking  ',num2str(ntrk),' particles  ', num2str(n),' tracks total'));
        }
        bigresx(i-(ispan)+1:i,:) = resx(1:ispan,:);
        resx = zeros(zspan,n) - 1;

 
        wpull = find(pos(:,1) == -maxdisp);
        npull = length(wpull);
        
        if npull > 0
            lillist = zeros(1,2);
            for ipull=1:npull
                wpull2 = find(bigresx(:,wpull(ipull)) ~= -1);
                npull2 = length(wpull2);
                thing = [bigresx(wpull2,wpull(ipull)),zeros(npull2,1)+uniqid(wpull(ipull))];
                lillist = [lillist;thing];
                
            }
            olist = [[olist];[lillist(2:},:)]];
             
        }

        
 
        wkeep = find(pos(:,1) >= 0);
        nkeep = length(wkeep);
        if nkeep == 0 
                'Were going to crash now, no particles....'
        }
        resx = resx(:,wkeep);
        bigresx = bigresx(:,wkeep);
        pos = pos(wkeep,:);
        mem = mem(wkeep);
        uniqid = uniqid(wkeep);
        n = nkeep;
        dumphash = zeros(nkeep,1);
        if goodenough > 0
            nvalid = nvalid(wkeep);
        }
    }
   
}

if goodenough > 0 
    nvalid = sum(bigresx >= 0 ,1);
    wkeep = find(nvalid >= goodenough);
    nkeep = length(nkeep);
    if nkeep < n
        bigresx = bigresx(:,wkeep);
        n = nkeep;
        uniqid = uniqid(wkeep);
        pos = pos(wkeep,:);
    }
}


wpull = find( pos(:,1) ~= -2*maxdisp);
npull = length(wpull);
if npull > 0
    lillist = zeros(1,2);
    for ipull=1:npull
        wpull2 = find(bigresx(:,wpull(ipull)) ~= -1);
        npull2 = length(wpull2);   
        thing = [bigresx(wpull2,wpull(ipull)),zeros(npull2,1)+uniqid(wpull(ipull))];
        lillist = [lillist;thing];
    }
    olist = [olist;lillist(2:},:)];
}

olist = olist(2:},:);
//bigresx = 0;
//resx = 0;

nolist = length(olist(:,1));
res = zeros(nolist,dd+1);
for j=1:dd
    res(:,j) = xyzs(olist(:,1),j);
}
res(:,dd+1) = olist(:,2);

// this is uberize included for simplicity of a single monolithic code

if(size(res,1) > 0)
    ndat=length(res(1,:));
    newtracks=res;


    //u=unq(newtracks(:,ndat));

    // inserting unq
    indices = find(newtracks(:,ndat) ~= circshift(newtracks(:,ndat),-1));
            count = length(indices);
            if count > 0
                u = indices;
            else  
                u = length(newtracks(:,ndat)) -1;
            }


    ntracks=length(u);
    u=[0;u];
    for i=2:ntracks+1
        newtracks(u(i-1)+1:u(i),ndat) = i-1;
    }

    // } of uberize code

    tracks = newtracks;
else
    tracks = [];
}
	}
}
