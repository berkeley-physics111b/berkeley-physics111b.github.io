using System;
using System.Collections.Generic;
using System.Text;
using GoodStuff;
using System.IO;
using System.Threading;
using System.Diagnostics;
using System.Drawing;

namespace BrownianMotion
{
    public class FileWriter : WorkerThread, IInitializable
    {
        GoodProperty<string> _outputDirectory;
        GoodProperty<string> _movieName;
        GoodProperty<string> _movieFrameElement;

        bool dumpFramesToMemory;
        bool RecordFrames;
        int movieNumber;
        int framenumber;
        public event SampleEventHandler FrameComplete;
        public event SampleEventHandler FinishedSaving;
        public event SampleEventHandler ReportStatus;

        ThreadSafeQueue<SampleEventArgs> _frameQueue;

        FileStream _frameInfoFileStream;
        StreamWriter _frameInfoStreamWriter;

        string _currentMoviePath;
        string _currentMovieName;

        public GoodProperty<string> MovieName
        {
            get
            {
                return _movieName;
            }
            set
            {
                _movieName = value;
            }
        }
        public void UIDirectoryChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                _outputDirectory.Value = (string)sArgs.Sample["Value"];
        }
        public void UIMovieNameChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
//                _movieName.Value = (string)sArgs.Sample["Value"];
                _currentMovieName = (string)sArgs.Sample["Value"];
        }
        public void ReportStatusLocal(string messageout)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("Message", messageout);
            if (ReportStatus != null)
                ReportStatus(this, s);
        }
        public void Initialize()
        {
            string threadString = "FileWriterThread." + this.ToString();
            CreateThread(threadString, ThreadPriority.Normal);
            StartThread();
        }
        public SampleEventArgs CleanFrame(SampleEventArgs sArgs)
        {
            string[] wantedArgs = new string[2];
            wantedArgs[0] = _movieFrameElement.Value;
            wantedArgs[1] = "Time";

            SampleEventArgs s = new SampleEventArgs();

            foreach (string str in wantedArgs)
                s.Sample.Add(str, sArgs.Sample[str]);
            return s;
        }

        public void IncomingFrame(object sender, SampleEventArgs sArgs)
        {
            if (RecordFrames && sArgs.Sample.ContainsKey(_movieFrameElement.Value))
                _frameQueue.Enqueue(CleanFrame(sArgs));
        }
        public void UISaysDumpFramesToMemory(object sender, SampleEventArgs sArgs)
        {
            dumpFramesToMemory = !dumpFramesToMemory;
        }
        public void UIRecordFramesChanged(object sender, SampleEventArgs sArgs)
        {
            if(sArgs.Sample.ContainsKey("Value"))
            {
                RecordFrames = (bool) sArgs.Sample["Value"];
            }
        }
        public void Quit(object sender, SampleEventArgs sArgs)
        {
            StopThread();
        }
            
        public FileWriter()
        {
            _frameQueue = new ThreadSafeQueue<SampleEventArgs>(300);

            _outputDirectory = new GoodProperty<string>();
            _outputDirectory.Name = "MovieOutputDirectory";
            _outputDirectory.DisplayName = "Movie Output Directory";
            _outputDirectory.Value = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\BIO Lab Work\Movies";

            _movieName = new GoodProperty<string>();
            _movieName.Name = "MovieName";
            _movieName.DisplayName = "Movie Name";
            _movieName.Value = "Movie";

            _movieFrameElement = new GoodProperty<string>();
            _movieFrameElement.Name = "MovieFrameElement";
            _movieFrameElement.Value = "CaptureBitmap";
            
            dumpFramesToMemory = false;
            movieNumber = 0;
            framenumber = 0;
            //StartCapture();
        }
        override protected void ThreadProc()
        {
            bool newrun = true;
            while (KeepGoing(500))                                           // loop until quit signal
            {
                _frameQueue.Wait(500);                                       // wait for a frame to be queued

                while (_frameQueue.Count > 0 && dumpFramesToMemory)                                // loop until all queued frames processed
                {
                    if (newrun)
                    {
                        StartCapture();
                        newrun = false;
                    }
                    SampleEventArgs s = _frameQueue.Dequeue();                         // get the next frame
                    WriteFrame(s);                                       // write out a .bmp file
                    if(FrameComplete!=null)
                        FrameComplete(this, s);  // pass frame on to next object for processing
                }
                if (dumpFramesToMemory)
                {
                    framenumber = 0;
                    dumpFramesToMemory = false;
                    newrun = true;
                    EndCapture();
                    if(FinishedSaving!=null)
                        FinishedSaving(this, new SampleEventArgs());
                    ReportStatusLocal("Files Saved to " + _outputDirectory.Value + "\\" + _currentMovieName);

                }

            }                                                                // end of while(KeepGoing())

                                                          // make sure file streams are close before quitting
        }
        private void WriteFrame(SampleEventArgs s)
        {
            framenumber++;
            Debug.Assert(s.Sample.ContainsKey(_movieFrameElement.Value), "Frame does not contain movie element");
            
            if (s.Sample.ContainsKey("Time"))
            {
                DateTime DT = (DateTime)s.Sample["Time"];
            }
            Bitmap b;
            b = (Bitmap)s.Sample[_movieFrameElement.Value];
            //_movieFrameElement.Value
            string frameName = _currentMovieName + @" Frame " + (framenumber).ToString() + @".bmp";
            string fullPath = _currentMoviePath + frameName;                                                   // frame name
            b.Save(fullPath);
            _frameInfoStreamWriter.WriteLine(frameName);
            if (s.Sample.ContainsKey("Time"))
            {
                DateTime DT = (DateTime)s.Sample["Time"];
                _frameInfoStreamWriter.WriteLine(DT.ToLongTimeString());
                _frameInfoStreamWriter.WriteLine(DT.Millisecond.ToString());
            }
            
            

        }
        void StartCapture()
        {
            // stop a capture in progress, if any
            //StopCapture(this, sArgs);

            // create the directory, if needed
            //_currentMovieName = _movieName.Value + " " + (movieNumber).ToString();

            _currentMoviePath = _outputDirectory.Value + @"\" + _currentMovieName + @"\";

            if (!System.IO.Directory.Exists(_currentMoviePath))
                System.IO.Directory.CreateDirectory(_currentMoviePath);

            // write out the movie parameters
            string fn;
            fn = _currentMoviePath + @"\" + _currentMovieName + @" info" + @".txt";
            FileStream fs = new FileStream(fn, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(
                "Capture Started at: " + DateTime.Now.ToString()); /*+
                " Sample Period: " +
                    (StateStore.Store["Sample Period"] as GoodNumericVariable<int>).ToString() +
                    "ms"+
                " Dimensions: " +
                    (StateStore.Store["CaptureRegion"] as GoodVariable<Rectangle>).ToString());*/
            sw.Close();
            fs.Close();

            // open the frame info stream
            fn = _currentMoviePath + @"\" + _currentMovieName + @" frames" + @".txt";
            _frameInfoFileStream = new FileStream(fn, FileMode.Create);
            _frameInfoStreamWriter = new StreamWriter(_frameInfoFileStream);

            Trace.WriteLine("MovieWriter.StartCaptue: beginning movie: " + _currentMovieName);
        }
        public void EndCapture()
        {
            Trace.WriteLine("Ending Movie Capture " + _currentMovieName);

            if (_frameInfoStreamWriter != null)
            {
                _frameInfoStreamWriter.Close();
                _frameInfoStreamWriter = null;
            }
            if (_frameInfoFileStream != null)
            {
                _frameInfoFileStream.Close();
                _frameInfoFileStream = null;
            }
            ++movieNumber;
            
        }

    }
}
