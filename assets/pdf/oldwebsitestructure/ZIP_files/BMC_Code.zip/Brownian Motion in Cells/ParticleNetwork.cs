using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace BrownianMotion
{
    class Particle
    {
        public double x;
        public double y;
        public ParticleNetwork Network;
        public ParticleNetwork NetworkNumber;
        public int FrameNumber;
        public Particle Future;
        public Particle Past;
        public Particle()
        {
            x = 0;
            y = 0;
            Network = null;
            FrameNumber = 0;
        }
        public int PastLength()
        {
            Particle temp = this;
            int length = 1;
            while(temp.Past!=null)
            {
                temp = temp.Past;
                length++;
            }
            return length;
        }
        public Particle[] ToArray()
        {
            int length = PastLength();
            Particle[] outParticles = new Particle[length];
            Particle temp = this;
            for (int i = 0; i < length; i++)
            {
                outParticles[i] = temp;
                temp = temp.Past;
            }
            return outParticles;
        }
        public double Metric(Particle B)
        {
            return (Math.Pow(x - B.x, 2) + Math.Pow(y - B.y, 2));
        }



    }

    class ParticleNetwork
    {
        public Particle Ghost;
        public List<Particle> FrameOneList;
        public List<Particle> FrameTwoList;
        public Particle[] FrameOneArray;
        public Particle[] FrameTwoArray;

        public ParticleNetwork()
        {
            Ghost = new Particle();
            Ghost.x = 123456;
            Ghost.x = 123456;
            Ghost.FrameNumber = -1;
            
            FrameOneList = new List<Particle>(100);
            FrameTwoList = new List<Particle>(100);
        }

        public void ConvertListsToArrays()
        {
            //convert our slow lists to fast Arrays once we've figured out how large things need to be
            //We'll end up doing lots of computations on our arrays
            FrameOneArray = new Particle[FrameOneList.Count];
            FrameTwoArray = new Particle[FrameTwoList.Count];
            FrameOneList.CopyTo(FrameOneArray);
            FrameTwoList.CopyTo(FrameTwoArray);
        }

        public double ParticleMetric(Particle A, Particle B)
        {
            //computes a distance metric by which we judge how "close" probabilistically the two particles are to each other
            //often this should either be euclidian distance or a probability that Particle A could have moved to Particle B
            //currently using euclidian metric squared
            return (Math.Pow(A.x - B.x, 2) + Math.Pow(A.y - B.y, 2));
        }

        public double ComputeBulkMetric(Particle[] A, Particle[] B, int[] permutation, double maxdistance)
        {
            int n = A.Length;
            double metric = 0;
            for(int i = 0 ; i < n ; i++)
            {
                metric += Math.Min(ParticleMetric(A[i], B[permutation[i]]), maxdistance); //add the next match's distance to the total metric. We cap distances at maxdistance.
            }
            return metric;
        }
                        
        public void Populate(Particle[] Frame1, Particle[] Frame2, double Reach)
        {
            //we require that we have exactly one startparticle
            //Look for our startparticle
            if (Frame1.Length == 0 || Frame2.Length == 0) //empty Frame?
                return;
            List<Particle> NewList;
            List<Particle> NewerList; 
            int frame1 = Frame1[0].FrameNumber;
            int frame2 = Frame2[0].FrameNumber; 
            Particle CurrentParticle;
            Particle[] DestinationFrame;
            List<Particle> DestinationList = new List<Particle>(100);
            if (FrameOneList.Count == 1)
                CurrentParticle = (Particle)FrameOneList[0];
            else if (FrameTwoList.Count == 1)
                CurrentParticle = (Particle)FrameTwoList[0];
            else
                throw new Exception("Particle Lists are Empty. Please Load in exactly one Starting Particle");

            NewList = new List<Particle>(100); //home of all of the particles that we've just found
            NewList.Add(CurrentParticle); // our starting condition


            while (NewList.Count != 0)
            {
                NewerList = new List<Particle>(100); //home of all the particles that we're going to find
                foreach (Particle B in NewList)
                {
                    if (B.FrameNumber == frame1) //figure out where we should be looking and where we should be placing things
                    {
                        DestinationFrame = Frame2;
                        DestinationList = FrameTwoList;
                    }
                    else
                    {
                        DestinationFrame = Frame1;
                        DestinationList = FrameOneList;
                    }   
                    NewerList.AddRange(AddinRange(B, DestinationFrame, Reach)); //Find 'em!
                }
                DestinationList.AddRange(NewerList); // Add our newly found particles to the proper list
                NewList = NewerList; // need to watch this. We destroy newerlist, Does that also remove all information in Newlist?
            }
        }

        public List<Particle> AddinRange(Particle StartParticle, Particle[] Frame, double Reach)
        {
            //Looks for particles in list Frame that do not yet have a network and are within a range of Reach
            //Ideally the two conditions should always coincide
            List<Particle> Outlist = new List<Particle>(100);
            double R2 = Reach * Reach;
            foreach (Particle B in Frame)
            {
                if (B.Network==null && Math.Pow(B.x - StartParticle.x,2) + Math.Pow(B.y - StartParticle.y,2)  < R2) //Blob is not married yet and is within reach of StartBlob?
                {
                    Outlist.Add(B);//add it to our goodlist
                    B.Network = StartParticle.Network; //Blob is now married to the network
                }

            }
            return Outlist;
        }

        public static int[] Permutation(long index, int order)
        {
            //returns the index-th permutation of order n - used for brute force particle matching
            int[] A = new int[order];
            for (int i = 0; i < order; i++)
                A[i] = i;
            return Permutation(index, A);
        }
        
        public static int[] Permutation(long index, int[] A)
        {
            //returns the index-th permutation of order n - used for brute force particle matching
            //This is the recursive function that allows one to use an arbitrary starting array A, normally {0,1,2,3...}
            int n = A.Length;
            int[] OUT = new int[n];
            long spacing = factorial(n - 1);
            int SelectedIndex = (int)(index / spacing);
            OUT[0] = A[SelectedIndex];

            if (n > 1) // Need to recurse
            {

                int[] Anew = new int[n - 1];
                // construct array of numbers not yet used, ie copy A while skipping over A[SelectedIndex]
                for (int i = 0; i < SelectedIndex; i++)
                    Anew[i] = A[i];
                for (int i = SelectedIndex+ 1; i < n; i++)
                    Anew[i - 1] = A[i];
                Permutation(index - (SelectedIndex) * spacing, Anew).CopyTo(OUT, 1); // Recurse on smaller system, copy elements into latter elements of OUT array.
            }
            return OUT;
        }

        public static long factorial(int i)
        {
            //computes i!
            long o = 1;
            for (; i > 1; i--)
                o *= i;
            return o;
        }

        public int[] ClosestPermutation(double maxdistance)
        {
            //pad arrays
            int F1Length = FrameOneArray.Length;
            int F2Length = FrameTwoArray.Length;
            int N = Math.Max(F1Length, F2Length);

            Particle[] F1 = new Particle[N]; //our working arrays
            Particle[] F2 = new Particle[N];
            FrameOneArray.CopyTo(F1, 0);
            FrameTwoArray.CopyTo(F2, 0);
            //pad with ghosts which are Phantom particles used in the event that we have found an unequal number of particles 
            //in our two frames, ie trying to match up four particles in frame 1 to three particles in frame 2
            for (int i = F1Length; i < N; i++)
                F1[i] = Ghost;
            for (int i = F2Length; i < N; i++)
                F2[i] = Ghost;


            if (factorial(N) > Math.Pow(2,16) ) //if our system has way too many possible computations
                throw new Exception("Excessive computation required. Particles are too closely gathered and too numerous.");

            int NumPermutations = (int)factorial(N);
            
            int ClosestPermutation = 0;
            double SmallestMetric = 0;
            double thisMetric;
            //run through all possible permutations of the network. find the one with the smallest metric
            for (int i = 0; i < NumPermutations; i++)
            {
                thisMetric = ComputeBulkMetric(F1, F2, Permutation(i, N), maxdistance);
                if (thisMetric < SmallestMetric) // found a new best choice?
                {
                    SmallestMetric = thisMetric;
                    ClosestPermutation = i;
                }
            }
            return Permutation(ClosestPermutation,N);
        }

        public void EnactPermutation(int[] permutation)
        {
            //takes a permutation and connects Past and Future nodes of Particles in our ParticleArrays
            for (int i = 0; i < FrameOneArray.Length; i++)
            {
                if (permutation[i] < FrameTwoArray.Length) // connection is valid, not linking to a ghost
                {
                    FrameOneArray[i].Future = FrameTwoArray[permutation[i]];
                    FrameTwoArray[permutation[i]].Past = FrameOneArray[i];
                }
            }
        }


   /*     static void Main(string[] args)
        {
            Double Reach =5 ;
            List<ParticleNetwork> NetworkList = new List<ParticleNetwork>();
            bool FoundUnMarried;

            Particle[] Frame1 = new Particle[6];
            for (int i = 0; i < Frame1.Length; i++)
                Frame1[i] = new Particle();
            Particle[] Frame2 = new Particle[3];
            for (int i = 0; i < Frame2.Length; i++)
                Frame2[i] = new Particle();
            Frame1[0].x = 0; Frame1[0].y = 0;
            Frame1[1].x = 2; Frame1[1].y = 2;
            Frame1[2].x = 4; Frame1[2].y = 4;
            Frame1[3].x = 4.5; Frame1[3].y = 4.5;
            Frame1[4].x = 20; Frame1[4].y = 20;
            Frame1[5].x = 24; Frame1[5].y = 25;
            foreach (Particle P in Frame1)
                P.FrameNumber = 1;
            Frame2[0].x = 20; Frame2[0].y = 20;
            Frame2[1].x = 3; Frame2[1].y = 2;
            Frame2[2].x = 21; Frame2[2].y = 22;
            foreach (Particle P in Frame2)
                P.FrameNumber = 2;

            do{
                //find an unmatched particle
                int i = 0;
                FoundUnMarried = false;
                //Look for an unmarried particle in Frame1
                while(!FoundUnMarried && i<Frame1.Length)
                {
                    if(Frame1[i].Network==null) FoundUnMarried = true;
                    else i++;
                }

                if (FoundUnMarried) // Did we find an unmarried particle in Frame1?
                {
                    ParticleNetwork N = new ParticleNetwork();
                    N.FrameOneList.Add(Frame1[i]);
                    Frame1[i].Network = N;

                    N.Populate(Frame1,Frame2,Reach);

                    NetworkList.Add(N);
                }
                else //still haven't found a particle
                {
                    i = 0;

                    while (!FoundUnMarried && i < Frame2.Length) //run through frame2 until we find something or run out of particles
                    {
                        if(Frame2[i].Network==null) FoundUnMarried = true;
                        else i++;
                    }
                    if(FoundUnMarried)
                    {   
                        ParticleNetwork N = new ParticleNetwork();
                        N.FrameTwoList.Add(Frame2[i]);
                        Frame2[i].Network = N;
    
                        N.Populate(Frame1,Frame2,Reach);

                        NetworkList.Add(N);
                    }

                }
            } while (FoundUnMarried); //while we keep finding new particles

            int[] A = new int[10];
            for(int i = 0; i < A.Length ; i++)
                A[i] = i;
            int[] P0 = Permutation(0, A);
            int[] P4644 = Permutation(4644, A);
            int[] P546743 = Permutation(52543, A);

            foreach (ParticleNetwork PN in NetworkList)
            {
                PN.ConvertListsToArrays();
                PN.EnactPermutation(PN.ClosestPermutation(10));
            }


/*
            BlobNetwork NN = NetworkList[1];
            NN.ConvertListsToArrays();
            int[] p = NN.ClosestPermutation(10);
            NN.EnactPermutation(p);
            */
            


            /*
            BlobNetwork N = new BlobNetwork();
            N.FrameOneList.Add(Frame1[4]);
            Frame1[4].Network = N;

            N.Populate(Frame1, Frame2, 5);
            
            Blob[] whatever1 = new Blob[N.FrameOneList.Count];
            N.FrameOneList.CopyTo(whatever1);
            Blob[] whatever2 = new Blob[N.FrameTwoList.Count];
            N.FrameTwoList.CopyTo(whatever2);
            
            int allowfordebug = 1;
        
            




        }*/
    }
}
