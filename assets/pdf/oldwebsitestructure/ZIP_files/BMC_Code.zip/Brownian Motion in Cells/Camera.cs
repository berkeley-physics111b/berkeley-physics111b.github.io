using GoodStuff;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

namespace CameraDriver {
    public class Camera : WorkerThread, IInitializable {

        #region Instance Variables


        RawFrameProcessor rfpInstance;
        public RawFrameProcessor RFPInstance {
            get {
                return rfpInstance;
            }
            set {
                rfpInstance = value;
                FrameComplete += rfpInstance.ProcessFrame;
            }
        }
        
        IntPtr _cameraHandle;
        public IntPtr CameraHandle {
            get { return _cameraHandle; }
            set { _cameraHandle = value; }
        }
     
        enum AcquisitionMode {
            Idle = 0,
            Continuous = 1,
            Shot = 2
        }
        AcquisitionMode _specifiedMode;
        AcquisitionMode _acquisitionMode;

        ArrayList _parameters = new ArrayList();

        #endregion

        #region Instance Variables and Properties for Buffers
        public int SpecifiedMode {
            get {
                return (int) _specifiedMode;
            }
            set {
                _specifiedMode = (AcquisitionMode) value;
            }
        }

        public void Initialize() {
            Open();        
            if (_specifiedMode == AcquisitionMode.Continuous) {
                this.StartContinuousImaging();
            }
            if (_specifiedMode == AcquisitionMode.Shot) {
                this.StartShotMode();
            }
        }
        static OrderedDictionary _allocatedBuffers;
        public OrderedDictionary AllocatedBuffers { get { return _allocatedBuffers; } }
        UInt32 _bufferIndex = 0;
        int _numberOfBuffers;
        public int NumberOfBuffers {
            get { return _numberOfBuffers; }
            set { _numberOfBuffers = value; }
        }
        public int AllocatedBufferCount {
            get { return _allocatedBuffers.Count; }
        }
        UInt32 _frameSize;
        public UInt32 FrameSize {
            get { return _frameSize; }
        }
        static DriverFunctions.PdtFrameCallback _onFrameAcquired = OnFrameAcquired;
        ThreadSafeQueue<FrameInfo> _bufferQueue;
        #endregion

        #region Instance Variables and Properties for Image Format
        DriverFunctions.PdtImageFormat _format;
        public DriverFunctions.PdtImageFormat Format {
            get { return _format; }
            set { _format = value; }
        }
        UInt32 _formatSupport;
        public UInt32 FormatSupport {
            get { return _formatSupport; }
        }

        private GoodVariable<Size> _maximumImageDimensions;
        public GoodVariable<Size> MaxImageDimensions
        {
            get { return _maximumImageDimensions; }
            set { _maximumImageDimensions = (GoodVariable<Size>)value; }
        }

        UInt32 _numberOfPixels;
        public UInt32 NumberOfPixels {
            get { return _numberOfPixels; }
        }
        UInt32 _pixelSize;
        public UInt32 PixelSize {
            get { return _pixelSize; }
        }
        #endregion

        #region Constructor, Destructor, and Dispose
        public Camera() {
            Trace.WriteLine("Camera Constructor Called");

            // set default values
            _numberOfBuffers = 1;

            // create external variables
            _maximumImageDimensions = new GoodVariable<Size>();
            _maximumImageDimensions.Name = "MaximumImageDimensions";
            _maximumImageDimensions.DisplayName = "Maximum Image Dimensions";
            StateStore.Store.AddVariable(_maximumImageDimensions);

            _parameters = new ArrayList();
            _allocatedBuffers = new OrderedDictionary();
            _bufferQueue = new ThreadSafeQueue<FrameInfo>(25);
            _acquisitionMode = AcquisitionMode.Idle;
            Format = DriverFunctions.PdtImageFormat.fmtRgb24;
        }

        #region Idispose
        public void Dispose() {
            Trace.WriteLine("Camera.Dispose() called on handle: " + _cameraHandle.ToString());

            if (_acquisitionMode == AcquisitionMode.Continuous)
                StopContinuousImaging();
            if (_acquisitionMode == AcquisitionMode.Shot)
                StopShotMode();

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            Close();
            DisposeBuffers();
            GC.SuppressFinalize(this);
        }
        #endregion
        ~Camera() {
            Dispose();
        }
        #endregion

        #region Count, Open, and Close
        static public UInt32 Count() {
            DriverFunctions.PdtCamListItem item = new DriverFunctions.PdtCamListItem();
            UInt32 numberOfCameras;

            UInt32 connectedNumber;
            numberOfCameras = DriverFunctions.PdListCameras(ref item, 1, out connectedNumber);
            return connectedNumber;
        }

        private CameraParameter paramGain;

        public CameraParameter ParamGain {
            get {
                return paramGain;
            }
            set {
                paramGain = value;
            }
        }

        

        public IntPtr Open() {
            Trace.WriteLine("Camera.Open() called");
            DriverFunctions.PdtErr errcode;
            DriverFunctions.PdtCamListItem item = new DriverFunctions.PdtCamListItem();

            try {
                UInt32 connectedNumber;
                UInt32 numberOfCameras = DriverFunctions.PdListCameras(ref item, 1, out connectedNumber);
                if (connectedNumber >= 1) {
                    errcode = DriverFunctions.PdOpenCamera(item.UniqueId, out _cameraHandle);
                    if (errcode != DriverFunctions.PdtErr.errSuccess)
                        throw (new Exception("Could not open camera"));
                }

                // get all the parameters for this camera

                DriverFunctions.PdGetFrameSize(_cameraHandle, out _frameSize, out _numberOfPixels, out _pixelSize);
                DriverFunctions.PdGetFormatSupport(_cameraHandle, out _formatSupport);
                DriverFunctions.PdGetFormat(_cameraHandle, out _format);

                UInt32 maxWidth, maxHeight;
                DriverFunctions.PdGetRegionMax(_cameraHandle, out maxWidth, out maxHeight);
                _maximumImageDimensions.Value = new Size((int)maxWidth, (int)maxHeight);

                for (PdtParamKey k = 0; k < PdtParamKey.__param_count; ++k) {
                    CameraParameter p = new CameraParameter(this, k, "");
                    p.Update();
                    _parameters.Add(p);
                }
                CameraParameter paramGain = new CameraParameter(this, PdtParamKey.paramGain, "paramGain");
                paramGain.DisplayName = "Gain";

                StateStore.Store.AddVariable((GoodNumericVariable<UInt32>)paramGain);
                CreateThread(
                    "Camera " + _cameraHandle.ToString() + " acquisition thread",
                    System.Threading.ThreadPriority.Normal);
                StartThread();

            } catch (Exception e) {
                System.Diagnostics.Trace.WriteLine(e.Message);
            }

            return _cameraHandle;
        }

        public void Close() {
            Trace.WriteLine("Camera.Close() called on camera " + _cameraHandle.ToString());

            StopThread();
            DriverFunctions.PdAbortFrames(_cameraHandle);
            if (_acquisitionMode == AcquisitionMode.Continuous)
                StopContinuousImaging();
            if (_cameraHandle != IntPtr.Zero)
                DriverFunctions.PdCloseCamera(_cameraHandle);
            _cameraHandle = IntPtr.Zero;
        }

        #endregion
        #region Countinuous Imaging

        public void StartContinuousImaging() {
            Trace.WriteLine("Starting continuous imaging on " + _cameraHandle.ToString());

            _acquisitionMode = AcquisitionMode.Continuous;
            DriverFunctions.PdSetFormat(_cameraHandle, _format);
            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeStreaming);
            AllocateBuffers();
        }
        public void StopContinuousImaging() {
            Trace.WriteLine("Stopping continuous imaging on " + _cameraHandle.ToString());

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            DisposeBuffers();
            _acquisitionMode = AcquisitionMode.Idle;
        }
        #endregion Continuous Imaging
        #region Shot Mode
        public void StartShotMode() {
            Trace.WriteLine("Shot Mode set on camera " + _cameraHandle.ToString());

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            _acquisitionMode = AcquisitionMode.Shot;
            DriverFunctions.PdSetFormat(_cameraHandle, _format);
            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeShot);
            AllocateBuffers();
        }
        public void StopShotMode() {
            Trace.WriteLine("Shot Mode stopped on camera " + _cameraHandle.ToString());

            DriverFunctions.PdSetCaptureMode(_cameraHandle, DriverFunctions.PdtCaptureMode.modeIdle);
            DriverFunctions.PdAbortFrames(_cameraHandle);
            DisposeBuffers();
            _acquisitionMode = AcquisitionMode.Idle;
        }
        public void TriggerShot() {
            DriverFunctions.PdTrigger(_cameraHandle, 1);
        }
        #endregion Shot Mode
        #region Callback -- handle completed frame
        /// <summary>
        /// Callback function for Prosilica driver -- never called from user code
        /// </summary>
        /// <param name="f">acquired PdtFrame</param>
        static void OnFrameAcquired(ref DriverFunctions.PdtFrame f) {
            // find the camera object that owns the acquired PdtFrame
            uint i = FrameInfo.GetFrameIndex(f);                                    // frame index points to the owner
            FrameInfo fi = (FrameInfo)_allocatedBuffers[i];                         // look it up in the allocated buffer list

            if (fi == null)
                throw (new Exception("Buffer returned was not in allocated buffer list"));

            fi.Owner.HandleFrame(fi);                                               // queue the buffer for processing by the worker thread
        }

        /// <summary>
        /// Do not call -- only called by OnFrameAcquired.
        /// </summary>
        /// <param name="fi">FrameInfo structure containing acquired frame</param>
        public void HandleFrame(FrameInfo fi) {
            Trace.Assert(_acquisitionMode != AcquisitionMode.Idle, "HandleFrame called whilst in idle mode");

            if (fi.Status != DriverFunctions.PdtErr.errCancelled)                   // ignore cancelled frame (after abort)
            {
                if (fi.Status != DriverFunctions.PdtErr.errSuccess)                 // make sure frame status is good
                    throw (new Exception("HandleFrame: Frame returned with error " + fi.Status.ToString()));

                if (_acquisitionMode != AcquisitionMode.Idle)                       // check for stale buffer
                    _bufferQueue.Enqueue(fi);                                       // queue the buffer for processing by the worker thread
            }
        }
        #endregion Callback
        /// <summary>
        /// Function runs in its own thread for handling acquired frames queued in the _bufferQueue
        /// </summary>
        override protected void ThreadProc() {
            while (KeepGoing()) {
                FrameInfo fi;
                _bufferQueue.Wait(250);
                while (_bufferQueue.Count > 0) {
                    //TODO: there is a race condition here if the queue is cleared
                    fi = (FrameInfo)_bufferQueue.Dequeue();
                    Debug.Assert(fi != null && fi.Buffer != null, "Invalid frame buffer!");

                    // create a Frame structure
                    if (FrameComplete != null) {
                        Frame f = new Frame();
                        f._objects.Add("FrameInfo", fi);
                        GenericEventHandler fcea = new GenericEventHandler(f);
                        FrameComplete(this, fcea);
                    } else {
                        DriverFunctions.PdQueueFrame(_cameraHandle, fi.FramePtr, cb);
                    }
                }
            }
        }
        #region IFrameProcessor Members
        public event GenericEventHandler FrameComplete;

        // the following declaration is included to prevent having to do any monkey business with the callback
        // delegate -- the runtime complains that a callback on a garbage collected delegate is taking place
        // otherwise this static declaration should never be CGd
        static DriverFunctions.PdtFrameCallback cb = new DriverFunctions.PdtFrameCallback(OnFrameAcquired);

        // take back the complete frames and requeue them
        public void ProcessFrame(object sender, GenericEventHandler args) {
            if (_acquisitionMode != AcquisitionMode.Idle) {
                FrameInfo fi = args.Frame._objects["FrameInfo"] as FrameInfo;
                if (fi == null)
                    throw (new Exception("Invalid frame returned to Camera in frame queue"));

                DriverFunctions.PdQueueFrame(fi.Owner.CameraHandle, fi.FramePtr, cb);
            }
        }

        #endregion
        public void AllocateBuffers() {
            Trace.WriteLine("Allocating " + _numberOfBuffers.ToString() + "buffers for camera " + _cameraHandle.ToString());

            DriverFunctions.PdtErr error;
            // make sure frame size variables are updated
            error = DriverFunctions.PdGetFrameSize(_cameraHandle, out _frameSize, out _numberOfPixels, out _pixelSize);

            for (int i = 0; i < _numberOfBuffers; ++i) {
                FrameInfo fi = new FrameInfo(_frameSize);
                fi.SetContext(0, _bufferIndex);
                fi.Owner = this;
                _allocatedBuffers.Add(_bufferIndex, fi);

                ++_bufferIndex;

                error = DriverFunctions.PdQueueFrame(_cameraHandle, fi.FramePtr, _onFrameAcquired);
                if (error != DriverFunctions.PdtErr.errSuccess)
                    throw (new Exception("Error returned when queueing frame"));
            }
        }
        public void DisposeBuffers() {
            Trace.WriteLine("Disposing of buffers for camera " + _cameraHandle.ToString());

            _bufferQueue.Clear();
            DriverFunctions.PdAbortFrames(_cameraHandle);
            IDictionaryEnumerator i = _allocatedBuffers.GetEnumerator();
            while (i.MoveNext()) {
                FrameInfo fi = i.Value as FrameInfo;
                if (fi != null)
                    fi.Dispose();
            }
            _allocatedBuffers.Clear();
        }

    
    }

    public unsafe class FrameInfo {
        DriverFunctions.PdtFrame* _framePtr;
        public IntPtr FramePtr { get { return (IntPtr)_framePtr; } }
        Camera _owner;
        public Camera Owner { get { return _owner; } set { _owner = value; } }

        #region PdtFrame Structure Field Accessors

        //-----	In -----

        public IntPtr Buffer {
            get { return _framePtr->Buffer; }
            set { _framePtr->Buffer = value; }
        }
        public UInt32 BufferSize			        // Size of your image buffer in bytes
        {
            get { return _framePtr->BufferSize; }
            set { _framePtr->BufferSize = value; }
        }

        public void SetContext(int index, UInt32 i) {
            _framePtr->Context[index] = i;
        }

        public UInt32 GetContext(int index) {
            return _framePtr->Context[index];
        }
        //-----	Out -----

        public DriverFunctions.PdtErr Status				// Status of this frame (PdtErr marshalled as Int32)
        {
            get { return _framePtr->Status; }
        }
        public DriverFunctions.PdtImageFormat Format { get { return _framePtr->Format; } }
        public UInt32 BitDepth { get { return _framePtr->BitDepth; } }
        public UInt32 Width { get { return _framePtr->Width; } }
        public UInt32 Height { get { return _framePtr->Height; } }
        public UInt32 Size { get { return _framePtr->Size; } }				        // Frame size, in bytes

        public UInt32 FrameCount { get { return _framePtr->FrameCount; } }
        public UInt32 Timestamp { get { return _framePtr->Timestamp; } }
        public UInt32 Tag { get { return _framePtr->Tag; } }

        public UInt32 BayerPattern { get { return _framePtr->BayerPattern; } }

        //public fixed UInt32 _reserved2[30];

        #endregion

        public FrameInfo(UInt32 bufferSize) {
            Trace.WriteLine("FrameInfo constructor called");

            _framePtr = (DriverFunctions.PdtFrame*)Marshal.AllocHGlobal(sizeof(DriverFunctions.PdtFrame));
            if (_framePtr == null)
                throw (new Exception("FrameInfo: Unable to allocate unmanaged memory"));

            _framePtr->Buffer = Marshal.AllocHGlobal((int)bufferSize);
            if (_framePtr->Buffer == null)
                throw (new Exception("FrameInfo: Unable to allocate unmanaged memory"));

            _framePtr->BufferSize = bufferSize;
        }

        ~FrameInfo() {
            Trace.WriteLine("Warning: FrameInfo destructor called -- object was not Disposed");
            Dispose();
        }

        public void Dispose() {
            Trace.WriteLine("FrameInfo Dispose() called");
            if (_framePtr != null) {
                Marshal.FreeHGlobal((IntPtr)_framePtr->Buffer);
                Marshal.FreeHGlobal((IntPtr)_framePtr);
                _framePtr = null;
            } else
                Trace.WriteLine("Warning: Dispose() called on FrameInfo object with null _framePtr");

            GC.SuppressFinalize(this);
        }

        public static uint GetFrameIndex(DriverFunctions.PdtFrame f) {
            uint i;
            unsafe {
                i = f.Context[0];
            }
            return i;
        }
    }
}
