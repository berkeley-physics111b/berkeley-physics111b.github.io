using System.Drawing;
using System.Collections.Generic;
using CameraDriver;
/// <summary>
/// Summary description for Class1
/// </summary>
namespace BrownianMotion {
    public class Blob
    {
        int _area;
        public int Area { get { return _area; } }

        List<Rectangle> _spans;

        public Blob(Blob idol)
        {
            _area = idol.Area;
            _spans = idol.Spans;
        }

        public Blob()
        {
            _spans = new List<Rectangle>();
        }

        public Point location() {
            Point outPoint = _spans[0].Location; // b.AddSpan(new Rectangle(startIndex, y, x - startIndex, 1));
            return outPoint;
        }

        public Point Location()
        {
            Point outPoint = _spans[0].Location; // b.AddSpan(new Rectangle(startIndex, y, x - startIndex, 1));
            return outPoint;
        }

        public List<Rectangle> Spans
        {
            get { return _spans; }
        }

        public void AddSpan(Rectangle r)
        {
            _spans.Add(r);
            _area += r.Width;
        }
    }
  }

