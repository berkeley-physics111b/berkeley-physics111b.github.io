using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GoodStuff;

namespace BrownianMotion
{
    public partial class FormCaptureControl : Form, IInitializable, IGoodControl {
        Graphics _moviePreview;
        public FormCaptureControl() {
            InitializeComponent();
            folderBrowserDialogChooseMovieFolder.SelectedPath =
                System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\Octopus Movies";
        }

        private void FormCaptureControl_FormClosing(object sender, FormClosingEventArgs e) {
//            Housekeeper.Cleanup();
        }
        public void SetBitmap(Bitmap b) {
              _moviePreview.DrawImage(
                  b, 
                  new Rectangle(
                      3, 
                      10, 
                      groupBoxCapturePreview.Width - 6,
                      groupBoxCapturePreview.Height - 13)
              );
        }

        public void Initialize() {
            
            Show();
        }

        #region IGoodControl Members


        public IGoodVariable GoodVariableBinding {
            get {
                throw new Exception("The method or operation is not implemented.");
            }
            set {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        public Control Control {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public void Add(IGoodControl somethingToAdd) {
            if (somethingToAdd is Control) {
                Controls.Add((Control)somethingToAdd);
            } else {
                Controls.Add((Control)somethingToAdd.Control);
            }
        }

        public void pBind(IGoodProperty newControl) {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }
   }