using System;
using GoodStuff;
using System.Drawing;
using System.Drawing.Imaging;
using CameraDriver;
/// <summary>
/// Summary description for Class1
/// </summary>
namespace BrownianMotion {
    enum AcquisitionMode {
        Idle = 0, 
        Continuous = 1,
        Shot = 2
    }

/*     public class regionChangedEventArgs : EventArgs {
        Rectangle captureRegion;

        public regionChangedEventArgs(Rectangle cRegion) {
            captureRegion = cRegion;
        }
    }

    public delegate void regionChangedEventHandler(object sender, regionChangedEventArgs args);
    */

    public class FrameGrabber : IInitializable {
        //public Camera cameraInstance;
        private FileReader fileReader;
        //ThreadSafeQueue<Frame> _displayFrameQueue;
        //ThreadSafeQueue<Frame> _grabFrameQueue;
        //ThreadSafeQueue<Frame> _fileFrameQueue;
        
        public event SampleEventHandler displayFrameReady;
        public event SampleEventHandler grabFrameReady;
        public event SampleEventHandler fileFrameReady;
        public event SampleEventHandler regionChanged;
        
        public event SampleEventHandler BitmapsReadyForDisplay;
        private GoodVariable<Rectangle> captureRegion;
        //private GoodTimer sampleTimer;
        public event SampleEventHandler UIUpdate;

        public FrameGrabber() {
            _acquisitionMode = AcquisitionMode.Shot;
            //cameraInstance = new Camera();// this needs to be changed. Camera should not belong to FrameGrabber

        }
        private IntPtr _cameraHandle;
        private AcquisitionMode _acquisitionMode;

        //PassThruForm state
        bool _shiftPressed;
        bool _controlPressed;
        Size FormPassThruSize;
        Rectangle FormPassThruClientRectangle;

        public void PassThruStateChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("ClientSize"))
                FormPassThruSize = (Size)sArgs.Sample["ClientSize"];
            if (sArgs.Sample.ContainsKey("ClientRectangle"))
                FormPassThruClientRectangle = (Rectangle)sArgs.Sample["ClientRectangle"];
        }
        public void PassThruMouseClick(object sender, SampleEventArgs sArgs)
        {
            System.Windows.Forms.MouseEventArgs mArgs;
            if(sArgs.Sample.ContainsKey("MouseArgs"))
                mArgs = (System.Windows.Forms.MouseEventArgs)sArgs.Sample["MouseArgs"];
            else
                return;

            Size max = FormPassThruSize;
            //((GoodVariable<Size>)StateStore.Store["MaximumImageDimensions"]).Value;

            if (!_shiftPressed && !_controlPressed)
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width - captureRegion.Value.Width / 2);
                x = Math.Max(0, x);
                x = Math.Min(max.Width - captureRegion.Value.Width, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height - captureRegion.Value.Height / 2);
                y = Math.Max(0, y);
                y = Math.Min(max.Height - captureRegion.Value.Height, y);
                captureRegion.Value = new Rectangle(
                    x,
                    y,
                    captureRegion.Value.Width,
                    captureRegion.Value.Height);
            }
            else if (!_controlPressed)
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);
                captureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    y);
            }
            else
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);

                x = Math.Max(x, y);
                y = Math.Max(x, y);
                captureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    y);
            }
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("CaptureRegion", captureRegion);
            //if(regionChanged!=null) 
                //regionChanged(this, s);
            
        }
        public void PassThruKeyUpDown(object sender, SampleEventArgs sArgs)
        {
            System.Windows.Forms.KeyEventArgs kArgs;
            if (sArgs.Sample.ContainsKey("KeyArgs"))
                kArgs = (System.Windows.Forms.KeyEventArgs)sArgs.Sample["KeyArgs"];
            else
                return;
            _shiftPressed = kArgs.Shift;
            _controlPressed = kArgs.Control;
        }

       /* public void grabAFrameFromFile(SampleEventArgs gArgs)
        {
            fileReader.FrameComplete += new SampleEventHandler(grabFrameComplete);
            fileReader.ReadFrame(gArgs);
        }*/
        public void UIStateChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("CaptureRegion"))
                captureRegion = (GoodVariable<Rectangle>)sArgs.Sample["CaptureRegion"];
        }

/*
       public void ReduceFrame(object sender, SampleEventArgs inParticlePacket)
       {

            Size maxCaptureSize = new Size();
            GoodVariable<Bitmap> _captureBitmap = new GoodVariable<Bitmap>();
            GoodVariable<Bitmap> _passthruBitmap = new GoodVariable<Bitmap> ();

            if (maxCaptureSize.IsEmpty)
            {
                if (inParticlePacket.Sample.ContainsKey("MaximumImageDimensions"))
                    maxCaptureSize = ((GoodVariable<Size>)inParticlePacket.Sample["MaximumImageDimensions"]).Value;
                else
                    maxCaptureSize = new Size(659, 493);
            }
            
            FrameInfo fi = inParticlePacket.Sample["FrameInfo"] as FrameInfo;
//                        Trace.Assert(fi != null, "Invalid FrameInfo retreived by RawFrameProcessor");

            #region bitMassage
            bool isColor = false;
            if ((fi.Format == DriverFunctions.PdtImageFormat.fmtRgb24) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw8) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw16) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRgb48))
                isColor = true;

            // create a bitmap from the captured data buffer for display in the passthru window
            // generate a histogram of values
            // generate a monochrome bitmap if the capture mode is color
            // create a Frame structure and put all of that into it

            // allocate a new Frame structure to hold the capture region
            //Frame captureFrame = new Frame();

            Bitmap mono = null, color = null;
            BitmapData monoData = null, colorData = null;
            if (isColor)
            {
                color = new Bitmap(
                    (int)fi.Width,
                    (int)fi.Height,
                    System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                colorData = color.LockBits(
                    new Rectangle(0, 0, color.Width, color.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format24bppRgb);
            }
            else
            {
                // allocate a monochrome bitmap the size of the captured buffer
                mono = new Bitmap(
                        (int)fi.Width,
                        (int)fi.Height,
                        System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                MonochromeBitmapFunctions.SetMonochromePalette(mono);
                monoData = mono.LockBits(
                    new Rectangle(0, 0, mono.Width, mono.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format8bppIndexed);
            }

            Bitmap monoCapture = null;
            Bitmap colorCapture = null;
            BitmapData monoCaptureData = null, colorCaptureData = null;

            // allocate a monochrome bitmap for the capture region

            Rectangle captureRectangle;
            captureRectangle = captureRegion.Value;

            Byte[,] monoArray = new Byte[captureRectangle.Width, captureRectangle.Height];

            monoCapture = new Bitmap(
                captureRectangle.Width,
                captureRectangle.Height,
                System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
            MonochromeBitmapFunctions.SetMonochromePalette(monoCapture);
            inParticlePacket.Sample.Add("Bitmap 8BppMonoCapture", monoCapture);
            monoCaptureData = monoCapture.LockBits(
                new Rectangle(0, 0, monoCapture.Width, monoCapture.Height),
                ImageLockMode.ReadWrite,
                PixelFormat.Format8bppIndexed);

            // allocate a color bitmap for the capture rectangle if in a color capture mode
            if (isColor)
            {
                colorCapture = new Bitmap(
                    captureRectangle.Width,
                    captureRectangle.Height,
                    System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                inParticlePacket.Sample.Add("CaptureBitmap", colorCapture);
                colorCaptureData = colorCapture.LockBits(
                    new Rectangle(0, 0, colorCapture.Width, colorCapture.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format24bppRgb);

            }

            // allocate an array to hold the brightness histogram
            // histogram is only of capture region
            int[] histogram = new int[256];

            switch (fi.Format)
            {

                case DriverFunctions.PdtImageFormat.fmtMono8:
                    //                    Debug.Assert(fi.Owner.PixelSize == 1, "Unexpected pixel size");
                    unsafe
                    {
                        Byte* i = (Byte*)fi.Buffer;
                        Byte* o = (Byte*)monoData.Scan0;
                        Byte* firstLineOfCapture =
                            i +                                                         // beginning of buffer
                            captureRectangle.Y * fi.Width;                              // down Y
                        Byte* firstLineAfterCapture =
                            firstLineOfCapture +                                       // start of capture area
                            captureRectangle.Height * fi.Width;                        // down height
                        Byte* endOfLine = i + monoData.Width;
                        Byte* lastInputPixel = i + fi.Width * fi.Height;
                        int padding = monoData.Stride - monoData.Width;

                        // copy the region up to the beginning of the capture rectangle
                        while (i < firstLineOfCapture)
                        {
                            while (i < endOfLine)
                            {
                                *o++ = *i++;
                            }
                            o += padding;
                            endOfLine += fi.Width;
                        }

                        // copy the region from the top to the bottom of the capture rectangle to 
                        // both the passthru and the capture bitmaps
                        Byte* captureStart = i + captureRectangle.X;
                        Byte* captureStop = captureStart + captureRectangle.Width;
                        Byte* capturePointer = (Byte*)monoCaptureData.Scan0;
                        int capturePadding = monoCaptureData.Stride - monoCaptureData.Width;

                        while (i < firstLineAfterCapture)
                        {
                            while (i < captureStart)
                            {
                                *o++ = *i++;
                            }
                            while (i < captureStop)
                            {
                                ++histogram[*i];
                                *capturePointer++ = *i;
                                *o++ = *i++;
                            }
                            while (i < endOfLine)
                            {
                                *o++ = *i++;
                            }
                            endOfLine += fi.Width;
                            captureStart += fi.Width;
                            captureStop += fi.Width;
                            o += padding;
                            capturePointer += capturePadding;
                        }

                        // copy the remainder of the captured image into the passthru buffer
                        while (i < lastInputPixel)
                        {
                            while (i < endOfLine)
                            {
                                *o++ = *i++;
                            }
                            o += padding;
                            endOfLine += fi.Width;
                        }
                    }
                    break;

                case DriverFunctions.PdtImageFormat.fmtRgb24:

                    //                    Debug.Assert(fi.Owner.PixelSize == 3, "Unexpected pixel size");
                    unsafe
                    {
                        Byte* i = (Byte*)fi.Buffer;
                        Byte* o = (Byte*)colorData.Scan0;
                        Byte* firstLineOfCapture =
                            i +                                                         // beginning of buffer
                            3 * captureRectangle.Y * fi.Width;                          // down Y
                        Byte* firstLineAfterCapture =
                            firstLineOfCapture +                                        // start of capture area
                            3 * captureRectangle.Height * fi.Width;                     // down height
                        Byte* endOfLine = i + 3 * colorData.Width;
                        Byte* lastInputPixel = i + 3 * fi.Width * fi.Height;
                        int padding = colorData.Stride - 3 * colorData.Width;
                        Byte* monoCapturePointer = (Byte*)monoCaptureData.Scan0;
                        int monoCapturePadding = monoCaptureData.Stride - monoCaptureData.Width;
                        Byte* colorCapturePointer = (Byte*)colorCaptureData.Scan0;
                        int colorCapturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;
                        Byte r, g, b, y;
                        int xx = 0, yy = 0;

                        // copy the region up to the beginning of the capture rectangle
                        // change the order for the silly Windows BGR ordering
                        while (i < firstLineOfCapture)
                        {
                            while (i < endOfLine)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            o += padding;
                            endOfLine += 3 * fi.Width;
                        }

                        // copy the region from the top to the bottom of the capture rectangle to 
                        // both the passthru and the capture bitmaps
                        Byte* captureStart = i + 3 * captureRectangle.X;
                        Byte* captureStop = captureStart + 3 * captureRectangle.Width;
                        Byte* capturePointer = (Byte*)colorCaptureData.Scan0;
                        int capturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;

                        while (i < firstLineAfterCapture)
                        {
                            while (i < captureStart)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            while (i < captureStop)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;

                                *colorCapturePointer++ = b;
                                *colorCapturePointer++ = g;
                                *colorCapturePointer++ = r;

                                y = (Byte)((77 * r + 150 * g + 29 * b) >> 8);
                                ++histogram[y];
                                *monoCapturePointer++ = y;
                                monoArray[xx, yy] = y;
                                xx++;
                            }
                            yy++; xx = 0;
                            while (i < endOfLine)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            endOfLine += 3 * fi.Width;
                            captureStart += 3 * fi.Width;
                            captureStop += 3 * fi.Width;
                            o += padding;
                            capturePointer += capturePadding;
                            monoCapturePointer += monoCapturePadding;
                            colorCapturePointer += colorCapturePadding;
                        }

                        // copy the remainder of the captured image into the passthru buffer
                        while (i < lastInputPixel)
                        {
                            while (i < endOfLine)
                            {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            o += padding;
                            endOfLine += 3 * fi.Width;
                        }
                    }
                    break;
            }

            // release all of the bitmaps created
            if (monoData != null)
                mono.UnlockBits(monoData);
            if (colorData != null)
                color.UnlockBits(colorData);
            if (monoCaptureData != null)
                monoCapture.UnlockBits(monoCaptureData);
            if (colorCaptureData != null)
                colorCapture.UnlockBits(colorCaptureData);

            // find the blobs
            //Blob[] blobs = BlobFinder.FindBlobs(monoCapture, _threshold.Value);

            // update the passthru bitmap
            if (isColor)
                _passthruBitmap.Value = color;
            else
                _passthruBitmap.Value = mono;

            // update _captureBitmap for the preview window, etc...
            if (isColor)
                _captureBitmap.Value = colorCapture;
            else
                _captureBitmap.Value = monoCapture;

            #endregion bitMassage

            inParticlePacket.Sample.Add("PassthruBitmap", _passthruBitmap);
            if (inParticlePacket.Sample.ContainsKey("CaptureBitmap"))
                inParticlePacket.Sample["CaptureBitmap"] = _captureBitmap;
            else
                inParticlePacket.Sample.Add("CaptureBitmap", _captureBitmap);
            inParticlePacket.Sample.Add("CaptureRegionArray", monoArray);
            inParticlePacket.Sample.Add("CaptureRegion", captureRegion);
            BitmapsReadyForDisplay(this, inParticlePacket);


        }
*/

        public void Initialize()
        {
            captureRegion = new GoodVariable<Rectangle>();
            captureRegion.Value = new Rectangle(0, 0, 200, 200);
        }
    }
}