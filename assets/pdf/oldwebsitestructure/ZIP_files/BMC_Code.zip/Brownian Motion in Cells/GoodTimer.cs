using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using GoodStuff;


namespace CameraDriver
{
    public class GoodTimer : GoodNumericVariable<Decimal>, IInitializable
    {
        Timer _timer;
        public Camera cameraInstance;

        public Camera CameraInstance {
            get {
                return cameraInstance;
            }
            set {
                cameraInstance = (Camera) value;
            }
        }

        public GoodTimer()
        {
            _timer = new Timer();
            _timer.Tick += TickHandler;
            ValueChanged += OnIntervalChanged;
        }
        public void Initialize() {
            this.Start();
        }
        public void Start()
        {
            _timer.Interval = (int)Value;
            _timer.Start();
        }

        public void Stop()
        {
            _timer.Stop();
        }

        public void OnIntervalChanged(object sender, EventArgs args)
        {
            _timer.Stop();
            _timer.Interval = (int)Value;
            _timer.Start();
        }

        void TickHandler(object sender, EventArgs args)
        {
            cameraInstance.TriggerShot();
        }


    }
}
