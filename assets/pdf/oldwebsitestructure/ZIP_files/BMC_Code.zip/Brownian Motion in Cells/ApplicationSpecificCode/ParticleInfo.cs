using System;
using System.Drawing;

/// <summary>
/// Summary description for Class1
/// </summary>
namespace frameGrabber {
    public class ParticleInfo {
        private Point location;
        private Point delta; // delta between frames

        public ParticleInfo()
	{
        location = new Point();
        delta = new Point();
    }

    }
}
