using System;
using GoodStuff;
using System.Drawing;

/// <summary>
/// Summary description for Class1
/// </summary>
namespace frameGrabber {
    enum AcquisitionMode {
        Idle = 0, 
        Continuous = 1,
        Shot = 2
    }

     public class regionChangedEventArgs : EventArgs {
        Rectangle captureRegion;

        public regionChangedEventArgs(Rectangle cRegion) {
            captureRegion = cRegion;
        }
    }


    public class FrameGrabber: IInitializable {
        private Camera cameraInstance;
        ThreadSafeQueue<Frame> _displayFrameQueue;
        ThreadSafeQueue<Frame> _grabFrameQueue;
        ThreadSafeQueue<Frame> _fileFrameQueue;
        private event FrameCompleteEventHandler displayFrameReady;
        private event FrameCompleteEventHandler grabFrameReady;
        private event FrameCompleteEventHandler fileFrameReady;
        private Goodvariable<Rectangle> captureRegion;


        public FrameGrabber() {
            _acquisitionMode = AcquisitionMode.Shot;
            cameraInstance = new Camera();
        }   
        private IntPtr _cameraHandle; 
        private AcquisitionMode _acquisitionMode;
        public void Initialize() {
            cameraInstance.SpecifiedMode = _acquisitionMode;
            _cameraHandle = cameraInstance.Open();  
        }

        private FrameCompleteEventHandler displayFrameComplete(object sender, FrameCompleteEventArgs args) {
            displayFrameReady(this, args);
        }
        private FrameCompleteEventHandler grabFrameComplete(object sender, FrameCompleteEventArgs args) {
            grabFrameReady(this, args);
        }
        private FrameCompleteEventHandler grabFrameComplete(object sender, FrameCompleteEventArgs args) {
            grabFrameReady(this, args);
        }
        private regionChangedEventHandler regionChanged(object sender, regionChangedEventArgs args);

        public FrameCompleteEventArgs grabAndDisplayAFrame() {
            cameraInstance.FrameComplete += displayFrameComplete;
            cameraInstance.TriggerShot();     
        }

        public void specifyRegion(Rectangle cRegion) {
            captureRegion.Value = cRegion; 
            regionChangedEventArgs rArgs = new regionChangedEventArgs(cRegion);
            regionChanged(this, rArgs);            
        }
         
        public FrameCompleteEventArgs grabAFrame() {
            cameraInstance.FrameComplete += grabFrameComplete;
            cameraInstance.TriggerShot();
        }

        public FrameCompleteEventArgs grabAFrameFromFile() {
            cameraInstance.FrameComplete += fileFrameComplete;
            cameraInstance.TriggerShot();
        }


    }
}