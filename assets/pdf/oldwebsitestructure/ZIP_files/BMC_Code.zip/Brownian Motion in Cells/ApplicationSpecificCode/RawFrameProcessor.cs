using GoodStuff;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using System.Diagnostics;


namespace CameraDriver
{
   public class RawFrameProcessor : WorkerThread, IFrameProcessor, IInitializable
    {
        ThreadSafeQueue<Frame> _frameQueue;
       Camera cameraInstance;
       MovieWriter movieWriterInstance;
        Graphics _passthruGraphics;
        public Graphics PassthruGraphics
        {
            get { return _passthruGraphics; }
            set { _passthruGraphics = value; }
        }
        Rectangle _passthruArea;
       public MovieWriter MovieWriterInstance {
           get {
               return movieWriterInstance;
           }
           set {
               movieWriterInstance = value;
               FrameComplete += movieWriterInstance.ProcessFrame;
           }
       }
       public Camera CameraInstance {
           get {
               return cameraInstance;
           }
           set {
               cameraInstance = value;
               ReturnFrame += cameraInstance.ProcessFrame;
           }
       }

        public Rectangle PassthruArea
        {
            get { return _passthruArea; }
            set { _passthruArea = value; }
        }

        GoodNumericVariable<Byte> _threshold;
        GoodVariable<Rectangle> _captureRegion;
        GoodVariable<Bitmap> _captureBitmap;
        GoodVariable<Bitmap> _passthruBitmap;

        public GoodVariable<Rectangle> CaptureRegion {
            get {
                return _captureRegion;
            }
            set {
                _captureRegion = value;
            }
        }

        public GoodVariable<Bitmap> CaptureBitmap {
            get {
                return _captureBitmap;
            }
            set {
                _captureBitmap = value;
            }
        }
        public GoodVariable<Bitmap> PassthruBitmap {
            get {
                return _passthruBitmap;
            }
            set {
                _passthruBitmap = value;
            }
        }
        public GoodNumericVariable<Byte> BlobThreshold {
            get {
                return _threshold;
            }
            set {
                _threshold = value;
            }
        }

       public void Initialize() {
           string threadString = "RawFrameProcessorThread." + this.ToString();
           CreateThread(threadString, ThreadPriority.Highest);
           StartThread();
       }

        public RawFrameProcessor()
        {
            _frameQueue = new ThreadSafeQueue<Frame>(10);
            _threshold = new GoodNumericVariable<Byte>();
            _threshold.Name = "BlobThreshold";
            _threshold.DisplayName = "Threshold";
            _threshold.Value = 128;
            StateStore.Store.AddVariable((GoodNumericVariable<Byte>)_threshold);
            _captureRegion = new GoodVariable<Rectangle>();
            _captureRegion.Name = "CaptureRegion";
            _captureRegion.DisplayName = "Capture Region";
            StateStore.Store.AddVariable(_captureRegion);
            _captureBitmap = new GoodVariable<Bitmap>();
            _captureBitmap.Name = "CaptureBitmap";
            _captureBitmap.DisplayName = "Video Capture Preview";
            StateStore.Store.AddVariable(_captureBitmap);
            _passthruBitmap = new GoodVariable<Bitmap>();
            _passthruBitmap.Name = "PassthruBitmap";
            _passthruBitmap.DisplayName = "Video Passthrough";
            StateStore.Store.AddVariable(_passthruBitmap);
        }

        /// <summary>
        /// Thread procedure copies the raw frame grab from the Prosilica camera,
        /// displays it in the passthru window and creates a frame structure for
        /// processing by subsequent processes
        /// </summary>
        protected override void ThreadProc()
        {
            // initialize the capture region variable
            StateStore s = StateStore.GetStore();
            Size maxCaptureSize = ((GoodVariable<Size>)s["MaximumImageDimensions"]).Value;
            _captureRegion.Value = new Rectangle(
                maxCaptureSize.Width / 2 - 100,
                maxCaptureSize.Height / 2 - 100,
                200,
                200);

            while (KeepGoing(100))
            {
                Frame f;
                _frameQueue.Wait(100);
                while (_frameQueue.Count > 0)
                {
                    f = _frameQueue.Dequeue();

                    FrameInfo fi = f._objects["FrameInfo"] as FrameInfo;
                    Trace.Assert(fi != null, "Invalid FrameInfo retreived by RawFrameProcessor");

                    bool isColor = false;
                    if ((fi.Format == DriverFunctions.PdtImageFormat.fmtRgb24) ||
                        (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw8) ||
                        (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw16) ||
                        (fi.Format == DriverFunctions.PdtImageFormat.fmtRgb48))
                        isColor = true;

                    // create a bitmap from the captured data buffer for display in the passthru window
                    // generate a histogram of values
                    // generate a monochrome bitmap if the capture mode is color
                    // create a Frame structure and put all of that into it
                    
                    // allocate a new Frame structure to hold the capture region
                    Frame captureFrame = new Frame();

                    Bitmap mono = null, color = null;
                    BitmapData monoData =null, colorData = null;
                    if (isColor)
                    {
                        color = new Bitmap(
                            (int)fi.Width,
                            (int)fi.Height,
                            System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                        colorData = color.LockBits(
                            new Rectangle(0, 0, color.Width, color.Height),
                            ImageLockMode.ReadWrite,
                            PixelFormat.Format24bppRgb);
                    }
                    else
                    {
                        // allocate a monochrome bitmap the size of the captured buffer
                        mono = new Bitmap(
                                (int)fi.Width,
                                (int)fi.Height,
                                System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                        MonochromeBitmapFunctions.SetMonochromePalette(mono);
                        monoData = mono.LockBits(
                            new Rectangle(0, 0, mono.Width, mono.Height),
                            ImageLockMode.ReadWrite,
                            PixelFormat.Format8bppIndexed);
                    }

                    Bitmap monoCapture = null;
                    Bitmap colorCapture = null;
                    BitmapData monoCaptureData = null, colorCaptureData = null;

                    // allocate a monochrome bitmap for the capture region

                    Rectangle captureRectangle;
                    captureRectangle = _captureRegion.Value;

                    monoCapture = new Bitmap(
                        captureRectangle.Width,
                        captureRectangle.Height,
                        System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                    MonochromeBitmapFunctions.SetMonochromePalette(monoCapture);
                    captureFrame._objects.Add("Bitmap 8BppMono", monoCapture);
                    monoCaptureData = monoCapture.LockBits(
                        new Rectangle(0, 0, monoCapture.Width, monoCapture.Height),
                        ImageLockMode.ReadWrite,
                        PixelFormat.Format8bppIndexed);

                    // allocate a color bitmap for the capture rectangle if in a color capture mode
                    if (isColor)
                    {
                        colorCapture = new Bitmap(
                            captureRectangle.Width,
                            captureRectangle.Height,
                            System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                        captureFrame._objects.Add("Capture 24BppRgb", colorCapture);
                        colorCaptureData = colorCapture.LockBits(
                            new Rectangle(0, 0, colorCapture.Width, colorCapture.Height),
                            ImageLockMode.ReadWrite,
                            PixelFormat.Format24bppRgb);

                    }

                    // allocate an array to hold the brightness histogram
                    // histogram is only of capture region
                    int[] histogram = new int[256];

                    switch (fi.Format)
                    {

                        case DriverFunctions.PdtImageFormat.fmtMono8:
                            Debug.Assert(fi.Owner.PixelSize == 1, "Unexpected pixel size");
                            unsafe
                            {
                                Byte* i = (Byte*)fi.Buffer;
                                Byte* o = (Byte*)monoData.Scan0;
                                Byte* firstLineOfCapture =
                                    i +                                                         // beginning of buffer
                                    captureRectangle.Y * fi.Width;                              // down Y
                                Byte* firstLineAfterCapture =
                                    firstLineOfCapture +                                       // start of capture area
                                    captureRectangle.Height * fi.Width;                        // down height
                                Byte* endOfLine = i + monoData.Width;
                                Byte* lastInputPixel = i + fi.Width * fi.Height;
                                int padding = monoData.Stride - monoData.Width;

                                // copy the region up to the beginning of the capture rectangle
                                while (i < firstLineOfCapture)
                                {
                                    while (i < endOfLine)
                                    {
                                        *o++ = *i++;
                                    }
                                    o += padding;
                                    endOfLine += fi.Width;
                                }

                                // copy the region from the top to the bottom of the capture rectangle to 
                                // both the passthru and the capture bitmaps
                                Byte* captureStart = i + captureRectangle.X;
                                Byte* captureStop = captureStart + captureRectangle.Width;
                                Byte* capturePointer = (Byte*)monoCaptureData.Scan0;
                                int capturePadding = monoCaptureData.Stride - monoCaptureData.Width;

                                while (i < firstLineAfterCapture)                                   
                                {
                                    while (i < captureStart)
                                    {
                                        *o++ = *i++;
                                    }
                                    while (i < captureStop)
                                    {
                                        ++histogram[*i];
                                        *capturePointer++ = *i;
                                        *o++ = *i++;
                                    }
                                    while (i < endOfLine)
                                    {
                                        *o++ = *i++;
                                    }
                                    endOfLine += fi.Width;
                                    captureStart += fi.Width;
                                    captureStop += fi.Width;
                                    o += padding;
                                    capturePointer += capturePadding;
                                }

                                // copy the remainder of the captured image into the passthru buffer
                                while (i < lastInputPixel)
                                {
                                    while (i < endOfLine)
                                    {
                                        *o++ = *i++;
                                    }
                                    o += padding;
                                    endOfLine += fi.Width;
                                }
                            }
                            break;

                        case DriverFunctions.PdtImageFormat.fmtRgb24:

                            Debug.Assert(fi.Owner.PixelSize == 3, "Unexpected pixel size");
                            unsafe
                            {
                                Byte* i = (Byte*)fi.Buffer;
                                Byte* o = (Byte*)colorData.Scan0;
                                Byte* firstLineOfCapture =
                                    i +                                                         // beginning of buffer
                                    3 * captureRectangle.Y * fi.Width;                          // down Y
                                Byte* firstLineAfterCapture =
                                    firstLineOfCapture +                                        // start of capture area
                                    3 * captureRectangle.Height * fi.Width;                     // down height
                                Byte* endOfLine = i + 3 * colorData.Width;
                                Byte* lastInputPixel = i + 3 * fi.Width * fi.Height;
                                int padding = colorData.Stride - 3 * colorData.Width;
                                Byte* monoCapturePointer = (Byte*)monoCaptureData.Scan0;
                                int monoCapturePadding = monoCaptureData.Stride - monoCaptureData.Width;
                                Byte* colorCapturePointer = (Byte*)colorCaptureData.Scan0;
                                int colorCapturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;
                                Byte r, g, b, y;
                                
                                // copy the region up to the beginning of the capture rectangle
                                // change the order for the silly Windows BGR ordering
                                while (i < firstLineOfCapture)
                                {
                                    while (i < endOfLine)
                                    {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    o += padding;
                                    endOfLine += 3 * fi.Width;
                                }

                                // copy the region from the top to the bottom of the capture rectangle to 
                                // both the passthru and the capture bitmaps
                                Byte* captureStart = i + 3 * captureRectangle.X;
                                Byte* captureStop = captureStart + 3 * captureRectangle.Width;
                                Byte* capturePointer = (Byte*)colorCaptureData.Scan0;
                                int capturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;

                                while (i < firstLineAfterCapture)
                                {
                                    while (i < captureStart)
                                    {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    while (i < captureStop)
                                    {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;

                                        *colorCapturePointer++ = b;
                                        *colorCapturePointer++ = g;
                                        *colorCapturePointer++ = r;

                                        y = (Byte)((77*r + 150*g + 29 * b)>>8);
                                        ++histogram[y];
                                        *monoCapturePointer++ = y;
                                   }
                                    while (i < endOfLine)
                                    {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    endOfLine += 3 * fi.Width;
                                    captureStart += 3 * fi.Width;
                                    captureStop += 3 * fi.Width;
                                    o += padding;
                                    capturePointer += capturePadding;
                                    monoCapturePointer += monoCapturePadding;
                                    colorCapturePointer += colorCapturePadding;
                                }

                                // copy the remainder of the captured image into the passthru buffer
                                while (i < lastInputPixel)
                                {
                                    while (i < endOfLine)
                                    {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    o += padding;
                                    endOfLine += 3 * fi.Width;
                                }
                            }
                            break;
                    }

                    // release all of the bitmaps created
                    if(monoData != null)
                        mono.UnlockBits(monoData);
                    if (colorData != null)
                        color.UnlockBits(colorData);
                    if (monoCaptureData != null)
                        monoCapture.UnlockBits(monoCaptureData);
                    if (colorCaptureData != null)
                        colorCapture.UnlockBits(colorCaptureData);

                    // find the blobs
                    //Blob[] blobs = BlobFinder.FindBlobs(monoCapture, _threshold.Value);

                    // update the passthru bitmap
                    if (isColor)
                        _passthruBitmap.Value = color;
                    else
                        _passthruBitmap.Value = mono;

                    // update _captureBitmap for the preview window, etc...
                    if (isColor)
                        _captureBitmap.Value = colorCapture;
                    else
                        _captureBitmap.Value = monoCapture;
/*                    if (!isColor)
                    {
                        colorCapture = Bitmap(
                    }
                    Graphics captureGraphics;
                    if (isColor)
                        captureGraphics = Graphics.FromImage(colorCapture);
                    else
                    {
                        
                        captureGraphics = Graphics.FromImage(monoCapture);
                    }


                    // draw each blob
                    for (int i = 0; i < blobs.Length; ++i)
                    {
                        if (blobs[i].Spans.Count != 0)
                        {
                            captureGraphics.DrawString(
                                i.ToString() + " - " + blobs[i].Area.ToString(),
                                new Font(FontFamily.GenericSansSerif.Name, 9),
                                Brushes.Aquamarine,
                                new PointF(blobs[i].Spans[0].X + 10, blobs[i].Spans[0].Y));
                            foreach (Rectangle r in blobs[i].Spans)
                            {
                                captureGraphics.DrawLine(Pens.Blue, new Point(r.X, r.Y), new Point(r.X + r.Width, r.Y));
                            }
                        }
                    }
                    captureGraphics.DrawString(
                        "Blobs found: " + blobs.Length.ToString(),
                        new Font(FontFamily.GenericSansSerif.Name, 9),
                        Brushes.Aquamarine,
                        new PointF(0, 0));*/






                    //_passthruGraphics = s["PassthruGraphics"] as Graphics;
                    //// draw the image on the passthru graphics, if set
                    //if (_passthruGraphics != null)
                    //{
                    //    if (color != null)
                    //    {
                    //        _passthruGraphics.DrawImage(
                    //            color,
                    //            _passthruGraphics.VisibleClipBounds,
                    //            new RectangleF(0, 0, color.Width, color.Height),
                    //            GraphicsUnit.Pixel);
                    //    }
                    //    else
                    //    {
                    //        _passthruGraphics.DrawImage(
                    //            mono,
                    //            _passthruGraphics.VisibleClipBounds,
                    //            new RectangleF(0, 0, mono.Width, mono.Height),
                    //            GraphicsUnit.Pixel);
                    //    }
                    //}

                    // draw a rectangle around the capture region
                    //Rectangle drawingRectangle = new Rectangle(
                    //    (int)_passthruGraphics.VisibleClipBounds.X,
                    //    (int)_passthruGraphics.VisibleClipBounds.Y,
                    //    (int)_passthruGraphics.VisibleClipBounds.Width,
                    //    (int)_passthruGraphics.VisibleClipBounds.Height);

                    //Rectangle scaledCaptureRectangle = new Rectangle(
                    //    captureRectangle.X * drawingRectangle.Width / (int)fi.Width,
                    //    captureRectangle.Y * drawingRectangle.Height / (int)fi.Height,
                    //    captureRectangle.Width * drawingRectangle.Width / (int)fi.Width,
                    //    captureRectangle.Height * drawingRectangle.Height / (int)fi.Height);
                    //_passthruGraphics.DrawRectangle(Pens.Red, scaledCaptureRectangle);

                    ReturnFrame(this, new FrameCompleteEventArgs(f));

                    if( FrameComplete != null )
                        FrameComplete(this, new FrameCompleteEventArgs(captureFrame));
                }
            }
        }

        #region IFrameProcessor Members

        public void ProcessFrame(object sender, FrameCompleteEventArgs args)
        {
            _frameQueue.Enqueue(args.Frame);
        }

        public event FrameCompleteEventHandler FrameComplete;
        public event FrameCompleteEventHandler ReturnFrame;

        #endregion
    }
}
