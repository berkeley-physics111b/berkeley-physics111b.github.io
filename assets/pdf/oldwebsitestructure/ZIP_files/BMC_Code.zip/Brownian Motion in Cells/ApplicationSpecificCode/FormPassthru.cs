using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GoodStuff;

namespace Octopus111
{
    public partial class FormPassthru : Form
    {
        public FormPassthru()
        {
            InitializeComponent();
            _passthruGraphics = CreateGraphics();
        }

        public event MouseEventHandler MoveCenter;
        private Graphics _passthruGraphics;

        private void FormPassthru_Load(object sender, EventArgs e)
        {
            ClientSize = ((GoodVariable<Size>)StateStore.Store["MaximumImageDimensions"]).Value;
            ((IGoodProperty)StateStore.Store["PassthroughBitmap"]).ValueChanged += OnBitmapChanged;
            _passthruGraphics = CreateGraphics();
        }

        private void FormPassthru_MouseClick(object sender, MouseEventArgs e)
        {
            GoodVariable<Rectangle> captureRectangle = (GoodVariable<Rectangle>)StateStore.Store["CaptureRegion"];
            Size max = ((GoodVariable<Size>)StateStore.Store["MaximumImageDimensions"]).Value;

            if (!_shiftPressed && !_controlPressed)
            {
                int x = (e.X * max.Width / ClientSize.Width - captureRectangle.Value.Width / 2);
                x = Math.Max(0, x);
                x = Math.Min(max.Width - captureRectangle.Value.Width, x);
                int y = (e.Y * max.Height / ClientSize.Height - captureRectangle.Value.Height / 2);
                y = Math.Max(0, y);
                y = Math.Min(max.Height - captureRectangle.Value.Height, y);
                captureRectangle.Value = new Rectangle(
                    x,
                    y,
                    captureRectangle.Value.Width,
                    captureRectangle.Value.Height);
            }
            else if (!_controlPressed)
            {
                int x = (e.X * max.Width / ClientSize.Width) - captureRectangle.Value.X;
                x = Math.Max(10, x);
                int y = (e.Y * max.Height / ClientSize.Height) - captureRectangle.Value.Y;
                y = Math.Max(10, y);
                captureRectangle.Value = new Rectangle(
                    captureRectangle.Value.X,
                    captureRectangle.Value.Y,
                    x,
                    y);
            }
            else
            {
                int x = (e.X * max.Width / ClientSize.Width) - captureRectangle.Value.X;
                x = Math.Max(10, x);
                int y = (e.Y * max.Height / ClientSize.Height) - captureRectangle.Value.Y;
                y = Math.Max(10, y);

                x = Math.Max(x, y);
                y = Math.Max(x, y);
                captureRectangle.Value = new Rectangle(
                    captureRectangle.Value.X,
                    captureRectangle.Value.Y,
                    x,
                    y);
            }
        }

        private void FormPassthru_ResizeEnd(object sender, EventArgs e)
        {
            _passthruGraphics = CreateGraphics();
        }


        // save the state of the shift key
        private void FormPassthru_KeyUpDown(object sender, KeyEventArgs e)
        {
            _shiftPressed = e.Shift;
            _controlPressed = e.Control;
        }

        bool _shiftPressed;
        bool _controlPressed;

        private void FormPassthru_Click(object sender, EventArgs e)
        {

        }


        private void OnBitmapChanged(object sender, EventArgs args)
        {
            Bitmap b = ((GoodVariable<Bitmap>)StateStore.Store["PassthruBitmap"]).Value;
            _passthruGraphics.DrawImage(
                b,
                ClientRectangle,
                new Rectangle(0, 0, b.Width, b.Height),
                GraphicsUnit.Pixel);

            Rectangle captureRectangle = ((GoodVariable<Rectangle>)StateStore.Store["CaptureRegion"]).Value;

            Rectangle scaledRectangle = new Rectangle(
                captureRectangle.X * ClientSize.Width / b.Width,
                captureRectangle.Y * ClientSize.Height / b.Height,
                captureRectangle.Width * ClientSize.Width / b.Width,
                captureRectangle.Height * ClientSize.Height / b.Height);


            _passthruGraphics.DrawRectangle(Pens.Red, scaledRectangle);
        }

    }
}