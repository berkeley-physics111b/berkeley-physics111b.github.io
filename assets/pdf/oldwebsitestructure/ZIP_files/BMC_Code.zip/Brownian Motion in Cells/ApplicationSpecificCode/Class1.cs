using System;
using System.Collections.Generic;
using System.Text;

namespace frameGrabber {
    public class Class1 {
    }
}
