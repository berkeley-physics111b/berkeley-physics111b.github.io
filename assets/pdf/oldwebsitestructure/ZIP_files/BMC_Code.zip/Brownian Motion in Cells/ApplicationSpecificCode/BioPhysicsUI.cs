using System;

/// <summary>
/// Summary description for Class1
/// </summary>
public class BioPhysicsUI : IInitializable
{
    ThreadSafeQueue<Frame> _displayFrames;
    ThreadSafeQueue<> _renderedFrames;
    public BioPhysicsUI()
	{
    }




    public void Initialize() {
        Trace.WriteLine("DisplayGenericType(DisplayGenericType)");

        Dictionary<string, object> o = new Dictionary<string, object>();
        StateStore s = StateStore.GetStore();

        Camera c = new Camera();
        //            c.Open();
        c.Format = DriverFunctions.PdtImageFormat.fmtRgb24;
        s.AddVariable("CameraInstance", c);
        //create the raw frame processor
        RawFrameProcessor rfp = new RawFrameProcessor();
        c.FrameComplete += rfp.ProcessFrame;
        rfp.ReturnFrame += c.ProcessFrame;                    // return the frames
        s.AddVariable("RawFrameProcessor", rfp);
        // panel for capture control window


        GoodPanel captureControlPanel = new GoodPanel();
        captureControlPanel.Margin = new Padding(7);
        captureControlPanel.Padding = new Padding(5);

        // capture preview
        GoodPictureBox pb = (GoodPictureBox)MakeControl("CaptureBitmap");
        pb.Size = new Size(250 + pb.Margin.Horizontal, 250 + pb.Margin.Vertical);
        captureControlPanel.Add(pb);

        // sample period
        GoodTimer samplePeriod = new GoodTimer();
        samplePeriod.Name = "SamplePeriod";
        samplePeriod.DisplayName = "Sample Period (ms)";
        samplePeriod.Value = 50;
        s.AddVariable(samplePeriod);

        // create the movie writer
        MovieWriter mw = new MovieWriter();
        rfp.FrameComplete += mw.ProcessFrame;
        StateStore.Store.AddVariable("MovieWriter", mw);
        // add controls to the capture control panel
        captureControlPanel.Add(MakeControl("CaptureRegion"));
        captureControlPanel.Add(MakeControl("SamplePeriod"));
        captureControlPanel.Add(MakeControl("paramGain"));

        // TODO: this is a temporary hack until the blobfinder is refactored
        captureControlPanel.Add(MakeControl("BlobThreshold"));

        GoodGroupBox movieControls = new GoodGroupBox();
        movieControls.Text = "Movie Capture Controls";

        movieControls.Add(MakeControl("FramesToCapture"));
        GoodProgressBar p = new GoodProgressBar();
        p.BindTo(new string[3] { "FramesCaptured", null, "FramesToCapture" });
        p.Text = "Movie Capture Progress";
        p.Initialize();
        p.Control.Size = new Size(movieControls.Width - movieControls.Margin.Horizontal, 40);
        movieControls.Add(p);

        movieControls.Add(MakeControl("StartCapture"), true);
        movieControls.Add(MakeControl("StopCapture"), true);
        movieControls.Add(MakeControl("MovieName"));
        movieControls.Width = captureControlPanel.Width - captureControlPanel.Margin.Horizontal;

        captureControlPanel.Add((IGoodControl)movieControls);


        GoodVariable<string> path = (GoodVariable<string>)StateStore.Store["MovieOutputDirectory"];
        path.Value = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\BIO Lab Work\Movies";
        GoodVariable<string> movieElement = (GoodVariable<string>)StateStore.Store["MovieFrameElement"];
        movieElement.Value = "Bitmap 8BppMono";

        // main window
        FormCaptureControl f = new FormCaptureControl();
        f.StartPosition = FormStartPosition.Manual;
        f.DesktopLocation = new Point(10, 10);
        captureControlPanel.Location = new Point(0, 0);
        f.ClientSize = captureControlPanel.Size;
        f.Controls.Add(captureControlPanel);

        // passthru window
        FormPassthru ptw = new FormPassthru();
        ptw.StartPosition = FormStartPosition.Manual;
        ptw.DesktopLocation = new Point(f.DesktopBounds.Right + 10, f.DesktopBounds.Top);

        f.Show();
        ptw.Show(f);

        // start threads
        mw.CreateThread("Movie Writer Thread", ThreadPriority.AboveNormal);
        mw.StartThread();
        rfp.CreateThread("Raw Frame Processor thread", ThreadPriority.Highest);
        rfp.StartThread();

        c.NumberOfBuffers = 5;
        c.StartShotMode();
        samplePeriod.CameraInstance = c;
        samplePeriod.Start();

        Application.Run(ptw);
        c.Close(); 
    }

}
