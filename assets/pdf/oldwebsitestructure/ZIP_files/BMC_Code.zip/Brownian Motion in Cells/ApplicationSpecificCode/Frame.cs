using System;
using System.Collections.Generic;
using System.Text;
using  System.Drawing;

namespace frameGrabber {
    public class FrameCompleteEventArgs : EventArgs {
        public Frame frame;
        public Goodvariable<Rectangle> captureRegion;

        public FrameCompleteEventArgs(Frame f) {
            frame = f;
            captureRegion.Value = new Rectangle();
        }
        public Goodvariable<Rectangle> CaptureRegion {
            get { return captureRegion; }
            set { captureRegion = value; }
        }

    }

        

        public delegate void FrameCompleteEventHandler(object sender, FrameCompleteEventArgs args);

        public interface IFrameProcessor {
            void ProcessFrame(object sender, FrameCompleteEventArgs args);
            event FrameCompleteEventHandler FrameComplete;
        }

        public class Frame {
            public Dictionary<string, object> _objects;

            public Frame() {
                _objects = new Dictionary<string, object>();
            }
        }
    }
