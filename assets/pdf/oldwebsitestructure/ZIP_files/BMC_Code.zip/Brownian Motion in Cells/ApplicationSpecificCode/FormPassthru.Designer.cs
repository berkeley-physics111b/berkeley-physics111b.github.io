namespace Octopus111
{
    partial class FormPassthru
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // FormPassthru
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 466);
            this.Name = "FormPassthru";
            this.Text = "FormPassthru";
            this.SizeChanged += new System.EventHandler(this.FormPassthru_ResizeEnd);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.FormPassthru_MouseClick);
            this.Click += new System.EventHandler(this.FormPassthru_Click);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.FormPassthru_KeyUpDown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FormPassthru_KeyUpDown);
            this.ResizeEnd += new System.EventHandler(this.FormPassthru_ResizeEnd);
            this.Load += new System.EventHandler(this.FormPassthru_Load);
            this.ResumeLayout(false);

        }

        #endregion
    }
}