using CameraDriver;
using SampleProcessors;
using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.IO;
using System.Threading;
using System.Diagnostics;
using GoodStuff;

namespace CameraDriver
{
    public class MovieWriter : WorkerThread , IFrameProcessor, IInitializable
    {
        GoodProperty<uint> _framesToCapture;
        GoodVariable<EventHandler> _start;
        GoodVariable<EventHandler> _stop;
        GoodProperty<string> _outputDirectory;
        GoodProperty<string> _movieName;
        GoodProperty<uint> _movieNumber;
        GoodProperty<bool> _autoincrementName;
        GoodProperty<string> _movieFrameElement;

        GoodProperty<uint> _framesCaptured;
        ManualResetEvent _capturing;

        ThreadSafeQueue<Frame> _frameQueue;

        FileStream _frameInfoFileSream;
        StreamWriter _frameInfoStreamWriter;

        string _currentMoviePath;
        string _currentMovieName;

        public void Initialize() {
            string threadString = "MovieWriterThread."+this.ToString();
            CreateThread(threadString, ThreadPriority.AboveNormal);
            StartThread();
        }

        public MovieWriter() {
            _frameQueue = new ThreadSafeQueue<Frame>(300);
            _capturing = new ManualResetEvent(true);

            _framesToCapture = new GoodProperty<UInt32>();
            _framesToCapture.Name = "FramesToCapture";
            _framesToCapture.DisplayName = "Number of Frames";
            _framesToCapture.Value = 300;
            StateStore.Store.AddVariable(_framesToCapture);

            _start = new GoodVariable<EventHandler>();
            _start.Name = "StartCapture";
            _start.DisplayName = "Start Capturing";
            _start.Value = new EventHandler(StartCapture);
            StateStore.Store.AddVariable(_start);

            _stop = new GoodVariable<EventHandler>();
            _stop.Name = "StopCapture";
            _stop.DisplayName = "Stop Capturing";
            _stop.Value = new EventHandler(StopCapture);
            StateStore.Store.AddVariable(_stop);

            _outputDirectory = new GoodProperty<string>();
            _outputDirectory.Name = "MovieOutputDirectory";
            _outputDirectory.DisplayName = "Movie Output Directory";
            StateStore.Store.AddVariable(_outputDirectory);

            _movieName = new GoodProperty<string>();
            _movieName.Name = "MovieName";
            _movieName.DisplayName = "Movie Name";
            _movieName.Value = "Movie";
            StateStore.Store.AddVariable(_movieName);

            _movieNumber = new GoodProperty<uint>();
            _movieNumber.Name = "MovieNumber";
            _movieNumber.DisplayName = "Movie Number";
            _movieNumber.Value = 0;
            StateStore.Store.AddVariable(_movieNumber);

            _autoincrementName = new GoodProperty<bool>();
            _autoincrementName.Name = "AutoincrementMovieName";
            _autoincrementName.DisplayName = "Automatically Increment Movie Name";
            _autoincrementName.Value = true;
            StateStore.Store.AddVariable(_autoincrementName);

            _movieFrameElement = new GoodProperty<string>();
            _movieFrameElement.Name = "MovieFrameElement";
            _movieFrameElement.Value = "Bitmap 24BppRgb";
            StateStore.Store.AddVariable(_movieFrameElement);

            _framesCaptured = new GoodProperty<uint>();
            _framesCaptured.Name = "FramesCaptured";
            _framesCaptured.DisplayName = "Frames Captured";
            _framesCaptured.Value = _framesToCapture.Value;
            StateStore.Store.AddVariable(_framesCaptured);
        }

        public GoodProperty<string> MovieName {
            get {
                return _movieName;
            }
            set {
                _movieName = value;
            }
        }

        public GoodProperty<uint> FramesCaptured {
            get {
                return _framesCaptured;
            }
            set {
                _framesCaptured = value;
            }
        }

        override protected void ThreadProc()
        {
            while (KeepGoing(100))                                           // loop until quit signal
            {
                _frameQueue.Wait(100);                                       // wait for a frame to be queued

                while (_frameQueue.Count > 0)                                // loop until all queued frames processed
                {
                    Frame f = _frameQueue.Dequeue();                         // get the next frame

                    if (_framesCaptured.Value == 0)                                // starting a new movie
                        StartMovieCapture();                                 // write movie info and open frame info stream

                    if (_framesCaptured.Value < _framesToCapture.Value)            // movie capture in progress
                        WriteFrame(f);                                       // write out a .bmp file

                    if ((_framesCaptured.Value >= _framesToCapture.Value) &&       // movie capture ending
                        (_frameInfoStreamWriter != null))
                        EndMovieCapture();                                   // close all the open streams

                    if (FrameComplete != null)
                        FrameComplete(this, new FrameCompleteEventArgs(f));  // pass frame on to next object for processing
                    else
                        f = null;                                            // dispose of the frame
                }                                                            // end of while(_frames.Count > 0)
            }                                                                // end of while(KeepGoing())

            EndMovieCapture();                                               // make sure file streams are close before quitting
        }



        private void StartMovieCapture()
        {
            // let everybody know a movie is in progress
            _capturing.Reset();

            // write out the movie parameters
            string fn;
            fn = _currentMoviePath + @"\" + _currentMovieName + @" info" + @".txt";
            FileStream fs = new FileStream(fn, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(
                "Capture Started at: " + DateTime.Now.ToString()); /*+
                " Sample Period: " +
                    (StateStore.Store["Sample Period"] as GoodVariable<int>).ToString() +
                    "ms"+
                " Dimensions: " +
                    (StateStore.Store["CaptureRegion"] as GoodVariable<Rectangle>).ToString());*/
            sw.Close();
            fs.Close();

            // open the frame info stream
            fn = _currentMoviePath + @"\" + _currentMovieName + @" frames" + @".txt";
            _frameInfoFileSream = new FileStream(fn, FileMode.Create);
            _frameInfoStreamWriter = new StreamWriter(_frameInfoFileSream);
        }

        private void WriteFrame(Frame f)
        {
            Debug.Assert(f._objects.ContainsKey(_movieFrameElement.Value), "Frame does not contain movie element");

            Bitmap b;
            b = (Bitmap)f._objects[_movieFrameElement.Value];

            string frameName = _currentMovieName + @" Frame " + (_framesCaptured.Value).ToString() + @".bmp";
            string fullPath = _currentMoviePath + frameName;                                                   // frame name
            b.Save(fullPath);
            _frameInfoStreamWriter.WriteLine(frameName);

            lock (_framesToCapture)
                ++(_framesCaptured.Value);
        }

        private void EndMovieCapture()
        {
            Trace.WriteLine("Ending Movie Capture " + _currentMovieName);

            if (_frameInfoStreamWriter != null)
            {
                _frameInfoStreamWriter.Close();
                _frameInfoStreamWriter = null;
            }
            if (_frameInfoFileSream != null)
            {
                _frameInfoFileSream.Close();
                _frameInfoFileSream = null;
            }
            if (_autoincrementName.Value)                                // increase the movie number
                ++(_movieNumber.Value);

            _capturing.Set();
        }

        /// <summary>
        /// Event handler causes a movie capture to begin
        /// </summary>
        /// <param name="sender">Object requesting movie capture</param>
        /// <param name="args">Generic EventArgs</param>
        void StartCapture(object sender, EventArgs args)
        {
            // stop a capture in progress, if any
            StopCapture( this, new EventArgs());

            // create the directory, if needed
            _currentMovieName = _movieName.Value;
            if (_autoincrementName.Value)
                _currentMovieName += " " + (_movieNumber.Value).ToString();

            _currentMoviePath = _outputDirectory.Value + @"\" + _currentMovieName + @"\";

            if(!System.IO.Directory.Exists(_currentMoviePath))
                System.IO.Directory.CreateDirectory(_currentMoviePath);

            lock(_framesToCapture)
                _framesCaptured.Value = 0;

            Trace.WriteLine("MovieWriter.StartCaptue: beginning movie: " + _currentMovieName);
        }

        /// <summary>
        /// Event handler causes a movie capture in progress to stop.
        /// Blocks until capture has been stoppen or timed out.
        /// </summary>
        /// <param name="sender">Object requesting stop capture</param>
        /// <param name="args">Generic EventArgs</param>
        void StopCapture(object sender, EventArgs args)
        {
            if ( !_capturing.WaitOne(0, false))                                           // test to see if capturing
            {
                Trace.WriteLine("MovieWriter.StopCapture: ending movie " + _currentMovieName.ToString());

                _framesCaptured.Value = _framesToCapture.Value;

                // wait for acknowledgment from ThreadProc
                int timeout = (int)((GoodTimer)StateStore.Store["SamplePeriod"]) .Value;
                bool b = _capturing.WaitOne(2 * timeout, false);

                Trace.WriteLineIf(b != false, "StopCapture: wait for movie to end timed out");
            }
        }

        #region IFrameProcessor Members

        public void ProcessFrame(object sender, FrameCompleteEventArgs args)
        {
            _frameQueue.Enqueue(args.Frame);
        }

        public event FrameCompleteEventHandler FrameComplete;

        #endregion
    }
}
