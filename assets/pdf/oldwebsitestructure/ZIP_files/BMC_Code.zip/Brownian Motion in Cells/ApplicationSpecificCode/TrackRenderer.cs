using System;
using System.Drawing;
using GoodStuff;

/// <summary>
/// Summary description for Class1
/// </summary>
namespace frameGrabber {
    public delegate void BlobPacketEventHandler(object sender, BlobPacketEventArgs args);
    public class BlobPacket {
        public Rectangle captureRegion;
        public Frame frame;
        public Blob[] blobs;

        public Rectangle CaptureRegion {
            get { return captureRegion; }
            set { captureRegion = value; }
        }
            
        public Frame Frame {
            get { return frame; }
            set { frame = (Frame)value; }
        }

        public Blob[] Blobs {
            get { return blobs; }
            set { blobs = value; }
        }

        public BlobPacket(Frame f, Blob[] b, Rectangle cRegion) {
            frame = f;            
            blobs = new Blob[b.Legth];
            for (i = 0; i < b.Length; i++) {
                blobs[i] = new Blob(b[i]);
            }
            captureRegion = cRegion; 
        }

        public BlobPacket(BlobPacket bPacket) {
            frame = bPacket.Frame;
            blobs = bPacket.Blobs;
            captureRegion = bPacket.CaptureRegion;
        }
    }

    public class BlobPacketEventArgs : EventArgs {
        BlobPacket blobPacket;

        public BlobPacketEventArgs(BlobPacket bPacket) {
            blobPacket = bPacket;
        }
    }


    public class ParticlePacket {
        public Frame frame;
        public ParticleInfo[] particleInfo;
        public Blob[] blobs;
        public Rectangle captureRegion;
        GoodNumericVariable<Byte> _threshold;
        GoodVariable<Rectangle> _captureRegion;
        GoodVariable<Bitmap> _captureBitmap;
        GoodVariable<Bitmap> _passthruBitmap;

        public ParticlePacket(ParticlePacket rPacket) {
            frame = rPacket.frame;
            particleInfo = rPacket.particleInfo;
            blobs = rPacket.blobs;
            _threshold = rPacket.Threshold;
            _captureRegion = rPacket.CaptureRegion;
            _passthruBitmap = rPacket.PassthruBitmap;
        }


        public GoodVariable<Rectangle> CaptureRegion {
            get {
                return _captureRegion;
            }
            set {
                _captureRegion = value;
            }
        }

        public GoodVariable<Bitmap> CaptureBitmap {
            get {
                return _captureBitmap;
            }
            set {
                _captureBitmap = value;
            }
        }
        public GoodVariable<Bitmap> PassthruBitmap {
            get {
                return _passthruBitmap;
            }
            set {
                _passthruBitmap = value;
            }
        }
        public GoodNumericVariable<Byte> BlobThreshold {
            get {
                return _threshold;
            }
            set {
                _threshold = value;
            }
        }

        public ParticlePacket(Frame f, ParticleInfo[] pInfo, Blob[] b) {
            frame = f;
            particleInfo = new ParticleInfo[pInfo.Length];
            for (i = 0; i < pInfo.Length; i++) {
                particleInfo[i] = new ParticleInfo(pInfo[i]);
            }
            blobs = new Blob[b.Legth];
            for (i = 0; i < b.Length; i++) {
                blobs[i] = new Blob(b[i]);
            }
        }

        public Frame Frame {
            get { return frame; }
            set { frame = (Frame)value; }
        }
        public ParticleInfo[] ParticleInfo {
            get { return particleInfo; }
            set { particleInfo = value; }
        }
        public Blob[] blobs {
            get { return blobs; }
            set { blobs = value; }
        }

        public ParticlePacket(Frame f, ParticleInfo[] pInfo, Blob[] b) {
            frame = f;
            particleInfo = new ParticleInfo[pInfo.Length];
            for (i = 0; i < pInfo.Length; i++) {
                particleInfo[i] = new ParticleInfo(pInfo[i]);
            }
            blobs = new Blob[b.Legth];
            for (i = 0; i < b.Length; i++) {
                blobs[i] = new Blob(b[i]);
            }
        }
    }

    public class ParticlePacketEventArgs : EventArgs {
        ParticlePacket particlePacket;

        public ParticlePacket ParticlePacket {
            get { return particlePacket; }
            set { particlePacket = (ParticlePacket)value; }
        }

        public ParticlePacketEventArgs(ParticlePacket pPacket) {
            particlePacket = pPacket;
        }
    }


    public delegate void ParticlePacketEventHandler(object sender, ParticlePacketEventArgs args);

    public class TrackRenderer : IInitializable {
        ThreadSafeQueue<ParticlePacket> tracksToRenderQueue;
        private event ParticlePacketEventHandler renderedTracksReady;
        Graphics _passthruGraphics;
        public Graphics PassthruGraphics {
            get { return _passthruGraphics; }
            set { _passthruGraphics = value; }
        }
        Rectangle _passthruArea;
        public Rectangle PassthruArea {
            get { return _passthruArea; }
            set { _passthruArea = value; }
        }

        GoodNumericVariable<Byte> _threshold;
        GoodVariable<Rectangle> _captureRegion;
        GoodVariable<Bitmap> _captureBitmap;
        GoodVariable<Bitmap> _passthruBitmap;

        public GoodVariable<Rectangle> CaptureRegion {
            get {
                return _captureRegion;
            }
            set {
                _captureRegion = value;
            }
        }

        public GoodVariable<Bitmap> CaptureBitmap {
            get {
                return _captureBitmap;
            }
            set {
                _captureBitmap = value;
            }
        }
        public GoodVariable<Bitmap> PassthruBitmap {
            get {
                return _passthruBitmap;
            }
            set {
                _passthruBitmap = value;
            }
        }
        public GoodNumericVariable<Byte> BlobThreshold {
            get {
                return _threshold;
            }
            set {
                _threshold = value;
            }
        }
        public TrackRenderer() {
            _frameQueue = new ThreadSafeQueue<Frame>(10);
            _threshold = new GoodNumericVariable<Byte>();
            _threshold.Name = "BlobThreshold";
            _threshold.DisplayName = "Threshold";
            _threshold.Value = 128;

            _captureRegion = new GoodVariable<Rectangle>();
            _captureRegion.Name = "CaptureRegion";
            _captureRegion.DisplayName = "Capture Region";

            _captureBitmap = new GoodVariable<Bitmap>();
            _captureBitmap.Name = "CaptureBitmap";
            _captureBitmap.DisplayName = "Video Capture Preview";

            _passthruBitmap = new GoodVariable<Bitmap>();
            _passthruBitmap.Name = "PassthruBitmap";
            _passthruBitmap.DisplayName = "Video Passthrough";
        }

        public event ParticlePacketEventHandler RenderedTracksReady {
            add { RenderedTracksReady += value; }
            remove { RenderedTracksReady -= value; }
        }

        public ParticlePacketEventArgs renderedTrackingDone(object sender, ParticlePacketEventArgs args) {
            renderedTracksReady(this, args);
        }

        public void handleParticlePacket(object sender, ParticlePacketEventArgs pPacketEventArgs) {
            ParticlePacket inParticlePacket = pPacketEventArgs.ParticlePacket;
            ParticlePacket outParticlePacket = new ParticlePacket(inParticlePacket);
            Size maxCaptureSize = ((GoodVariable<Size>)s["MaximumImageDimensions"]).Value;
            _captureRegion.Value = new Rectangle(
                maxCaptureSize.Width / 2 - 100,
                maxCaptureSize.Height / 2 - 100,
                200,
                200);
            Frame f = inParticlePacket.Frame;

            FrameInfo fi = f._objects["FrameInfo"] as FrameInfo;
            Trace.Assert(fi != null, "Invalid FrameInfo retreived by RawFrameProcessor");
            #region bitMassage
            bool isColor = false;
            if ((fi.Format == DriverFunctions.PdtImageFormat.fmtRgb24) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw8) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw16) ||
                (fi.Format == DriverFunctions.PdtImageFormat.fmtRgb48))
                isColor = true;

            // create a bitmap from the captured data buffer for display in the passthru window
            // generate a histogram of values
            // generate a monochrome bitmap if the capture mode is color
            // create a Frame structure and put all of that into it

            // allocate a new Frame structure to hold the capture region
            Frame captureFrame = new Frame();

            Bitmap mono = null, color = null;
            BitmapData monoData = null, colorData = null;
            if (isColor) {
                color = new Bitmap(
                    (int)fi.Width,
                    (int)fi.Height,
                    System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                colorData = color.LockBits(
                    new Rectangle(0, 0, color.Width, color.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format24bppRgb);
            } else {
                // allocate a monochrome bitmap the size of the captured buffer
                mono = new Bitmap(
                        (int)fi.Width,
                        (int)fi.Height,
                        System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                MonochromeBitmapFunctions.SetMonochromePalette(mono);
                monoData = mono.LockBits(
                    new Rectangle(0, 0, mono.Width, mono.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format8bppIndexed);
            }

            Bitmap monoCapture = null;
            Bitmap colorCapture = null;
            BitmapData monoCaptureData = null, colorCaptureData = null;

            // allocate a monochrome bitmap for the capture region

            Rectangle captureRectangle;
            captureRectangle = _captureRegion.Value;

            monoCapture = new Bitmap(
                captureRectangle.Width,
                captureRectangle.Height,
                System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
            MonochromeBitmapFunctions.SetMonochromePalette(monoCapture);
            captureFrame._objects.Add("Bitmap 8BppMono", monoCapture);
            monoCaptureData = monoCapture.LockBits(
                new Rectangle(0, 0, monoCapture.Width, monoCapture.Height),
                ImageLockMode.ReadWrite,
                PixelFormat.Format8bppIndexed);

            // allocate a color bitmap for the capture rectangle if in a color capture mode
            if (isColor) {
                colorCapture = new Bitmap(
                    captureRectangle.Width,
                    captureRectangle.Height,
                    System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                captureFrame._objects.Add("Capture 24BppRgb", colorCapture);
                colorCaptureData = colorCapture.LockBits(
                    new Rectangle(0, 0, colorCapture.Width, colorCapture.Height),
                    ImageLockMode.ReadWrite,
                    PixelFormat.Format24bppRgb);

            }

            // allocate an array to hold the brightness histogram
            // histogram is only of capture region
            int[] histogram = new int[256];

            switch (fi.Format) {

                case DriverFunctions.PdtImageFormat.fmtMono8:
                    Debug.Assert(fi.Owner.PixelSize == 1, "Unexpected pixel size");
                    unsafe {
                        Byte* i = (Byte*)fi.Buffer;
                        Byte* o = (Byte*)monoData.Scan0;
                        Byte* firstLineOfCapture =
                            i +                                                         // beginning of buffer
                            captureRectangle.Y * fi.Width;                              // down Y
                        Byte* firstLineAfterCapture =
                            firstLineOfCapture +                                       // start of capture area
                            captureRectangle.Height * fi.Width;                        // down height
                        Byte* endOfLine = i + monoData.Width;
                        Byte* lastInputPixel = i + fi.Width * fi.Height;
                        int padding = monoData.Stride - monoData.Width;

                        // copy the region up to the beginning of the capture rectangle
                        while (i < firstLineOfCapture) {
                            while (i < endOfLine) {
                                *o++ = *i++;
                            }
                            o += padding;
                            endOfLine += fi.Width;
                        }

                        // copy the region from the top to the bottom of the capture rectangle to 
                        // both the passthru and the capture bitmaps
                        Byte* captureStart = i + captureRectangle.X;
                        Byte* captureStop = captureStart + captureRectangle.Width;
                        Byte* capturePointer = (Byte*)monoCaptureData.Scan0;
                        int capturePadding = monoCaptureData.Stride - monoCaptureData.Width;

                        while (i < firstLineAfterCapture) {
                            while (i < captureStart) {
                                *o++ = *i++;
                            }
                            while (i < captureStop) {
                                ++histogram[*i];
                                *capturePointer++ = *i;
                                *o++ = *i++;
                            }
                            while (i < endOfLine) {
                                *o++ = *i++;
                            }
                            endOfLine += fi.Width;
                            captureStart += fi.Width;
                            captureStop += fi.Width;
                            o += padding;
                            capturePointer += capturePadding;
                        }

                        // copy the remainder of the captured image into the passthru buffer
                        while (i < lastInputPixel) {
                            while (i < endOfLine) {
                                *o++ = *i++;
                            }
                            o += padding;
                            endOfLine += fi.Width;
                        }
                    }
                    break;

                case DriverFunctions.PdtImageFormat.fmtRgb24:

                    Debug.Assert(fi.Owner.PixelSize == 3, "Unexpected pixel size");
                    unsafe {
                        Byte* i = (Byte*)fi.Buffer;
                        Byte* o = (Byte*)colorData.Scan0;
                        Byte* firstLineOfCapture =
                            i +                                                         // beginning of buffer
                            3 * captureRectangle.Y * fi.Width;                          // down Y
                        Byte* firstLineAfterCapture =
                            firstLineOfCapture +                                        // start of capture area
                            3 * captureRectangle.Height * fi.Width;                     // down height
                        Byte* endOfLine = i + 3 * colorData.Width;
                        Byte* lastInputPixel = i + 3 * fi.Width * fi.Height;
                        int padding = colorData.Stride - 3 * colorData.Width;
                        Byte* monoCapturePointer = (Byte*)monoCaptureData.Scan0;
                        int monoCapturePadding = monoCaptureData.Stride - monoCaptureData.Width;
                        Byte* colorCapturePointer = (Byte*)colorCaptureData.Scan0;
                        int colorCapturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;
                        Byte r, g, b, y;

                        // copy the region up to the beginning of the capture rectangle
                        // change the order for the silly Windows BGR ordering
                        while (i < firstLineOfCapture) {
                            while (i < endOfLine) {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            o += padding;
                            endOfLine += 3 * fi.Width;
                        }

                        // copy the region from the top to the bottom of the capture rectangle to 
                        // both the passthru and the capture bitmaps
                        Byte* captureStart = i + 3 * captureRectangle.X;
                        Byte* captureStop = captureStart + 3 * captureRectangle.Width;
                        Byte* capturePointer = (Byte*)colorCaptureData.Scan0;
                        int capturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;

                        while (i < firstLineAfterCapture) {
                            while (i < captureStart) {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            while (i < captureStop) {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;

                                *colorCapturePointer++ = b;
                                *colorCapturePointer++ = g;
                                *colorCapturePointer++ = r;

                                y = (Byte)((77 * r + 150 * g + 29 * b) >> 8);
                                ++histogram[y];
                                *monoCapturePointer++ = y;
                            }
                            while (i < endOfLine) {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            endOfLine += 3 * fi.Width;
                            captureStart += 3 * fi.Width;
                            captureStop += 3 * fi.Width;
                            o += padding;
                            capturePointer += capturePadding;
                            monoCapturePointer += monoCapturePadding;
                            colorCapturePointer += colorCapturePadding;
                        }

                        // copy the remainder of the captured image into the passthru buffer
                        while (i < lastInputPixel) {
                            while (i < endOfLine) {
                                r = *i++;
                                g = *i++;
                                b = *i++;
                                *o++ = b;
                                *o++ = g;
                                *o++ = r;
                            }
                            o += padding;
                            endOfLine += 3 * fi.Width;
                        }
                    }
                    break;
            }

            // release all of the bitmaps created
            if (monoData != null)
                mono.UnlockBits(monoData);
            if (colorData != null)
                color.UnlockBits(colorData);
            if (monoCaptureData != null)
                monoCapture.UnlockBits(monoCaptureData);
            if (colorCaptureData != null)
                colorCapture.UnlockBits(colorCaptureData);

            // find the blobs
            //Blob[] blobs = BlobFinder.FindBlobs(monoCapture, _threshold.Value);

            // update the passthru bitmap
            if (isColor)
                _passthruBitmap.Value = color;
            else
                _passthruBitmap.Value = mono;

            // update _captureBitmap for the preview window, etc...
            if (isColor)
                _captureBitmap.Value = colorCapture;
            else
                _captureBitmap.Value = monoCapture;

            #endregion bitMassage
            outParticlePacket.Frame = captureFrame;
            outParticlePacket.PassthruBitmap = _passthruBitmap;
            outParticlePacket.CaptureBitmap = _captureBitmap;
            outParticlePacket.Threshold = _threshold;
            renderedTracksReady(this, outParticlePacket);
        }
    
    



       

        protected override void ThreadProc() {
            // initialize the capture region variable
            StateStore s = StateStore.GetStore();
            Size maxCaptureSize = ((GoodVariable<Size>)s["MaximumImageDimensions"]).Value;
            _captureRegion.Value = new Rectangle(
                maxCaptureSize.Width / 2 - 100,
                maxCaptureSize.Height / 2 - 100,
                200,
                200);

            while (KeepGoing(100)) {
                Frame f;
                _frameQueue.Wait(100);
                while (_frameQueue.Count > 0) {
                    f = _frameQueue.Dequeue();

                    FrameInfo fi = f._objects["FrameInfo"] as FrameInfo;
                    Trace.Assert(fi != null, "Invalid FrameInfo retreived by RawFrameProcessor");

                    bool isColor = false;
                    if ((fi.Format == DriverFunctions.PdtImageFormat.fmtRgb24) ||
                        (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw8) ||
                        (fi.Format == DriverFunctions.PdtImageFormat.fmtRaw16) ||
                        (fi.Format == DriverFunctions.PdtImageFormat.fmtRgb48))
                        isColor = true;

                    // create a bitmap from the captured data buffer for display in the passthru window
                    // generate a histogram of values
                    // generate a monochrome bitmap if the capture mode is color
                    // create a Frame structure and put all of that into it

                    // allocate a new Frame structure to hold the capture region
                    Frame captureFrame = new Frame();

                    Bitmap mono = null, color = null;
                    BitmapData monoData = null, colorData = null;
                    if (isColor) {
                        color = new Bitmap(
                            (int)fi.Width,
                            (int)fi.Height,
                            System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                        colorData = color.LockBits(
                            new Rectangle(0, 0, color.Width, color.Height),
                            ImageLockMode.ReadWrite,
                            PixelFormat.Format24bppRgb);
                    } else {
                        // allocate a monochrome bitmap the size of the captured buffer
                        mono = new Bitmap(
                                (int)fi.Width,
                                (int)fi.Height,
                                System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                        MonochromeBitmapFunctions.SetMonochromePalette(mono);
                        monoData = mono.LockBits(
                            new Rectangle(0, 0, mono.Width, mono.Height),
                            ImageLockMode.ReadWrite,
                            PixelFormat.Format8bppIndexed);
                    }

                    Bitmap monoCapture = null;
                    Bitmap colorCapture = null;
                    BitmapData monoCaptureData = null, colorCaptureData = null;

                    // allocate a monochrome bitmap for the capture region

                    Rectangle captureRectangle;
                    captureRectangle = _captureRegion.Value;

                    monoCapture = new Bitmap(
                        captureRectangle.Width,
                        captureRectangle.Height,
                        System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                    MonochromeBitmapFunctions.SetMonochromePalette(monoCapture);
                    captureFrame._objects.Add("Bitmap 8BppMono", monoCapture);
                    monoCaptureData = monoCapture.LockBits(
                        new Rectangle(0, 0, monoCapture.Width, monoCapture.Height),
                        ImageLockMode.ReadWrite,
                        PixelFormat.Format8bppIndexed);

                    // allocate a color bitmap for the capture rectangle if in a color capture mode
                    if (isColor) {
                        colorCapture = new Bitmap(
                            captureRectangle.Width,
                            captureRectangle.Height,
                            System.Drawing.Imaging.PixelFormat.Format24bppRgb);
                        captureFrame._objects.Add("Capture 24BppRgb", colorCapture);
                        colorCaptureData = colorCapture.LockBits(
                            new Rectangle(0, 0, colorCapture.Width, colorCapture.Height),
                            ImageLockMode.ReadWrite,
                            PixelFormat.Format24bppRgb);

                    }

                    // allocate an array to hold the brightness histogram
                    // histogram is only of capture region
                    int[] histogram = new int[256];

                    switch (fi.Format) {

                        case DriverFunctions.PdtImageFormat.fmtMono8:
                            Debug.Assert(fi.Owner.PixelSize == 1, "Unexpected pixel size");
                            unsafe {
                                Byte* i = (Byte*)fi.Buffer;
                                Byte* o = (Byte*)monoData.Scan0;
                                Byte* firstLineOfCapture =
                                    i +                                                         // beginning of buffer
                                    captureRectangle.Y * fi.Width;                              // down Y
                                Byte* firstLineAfterCapture =
                                    firstLineOfCapture +                                       // start of capture area
                                    captureRectangle.Height * fi.Width;                        // down height
                                Byte* endOfLine = i + monoData.Width;
                                Byte* lastInputPixel = i + fi.Width * fi.Height;
                                int padding = monoData.Stride - monoData.Width;

                                // copy the region up to the beginning of the capture rectangle
                                while (i < firstLineOfCapture) {
                                    while (i < endOfLine) {
                                        *o++ = *i++;
                                    }
                                    o += padding;
                                    endOfLine += fi.Width;
                                }

                                // copy the region from the top to the bottom of the capture rectangle to 
                                // both the passthru and the capture bitmaps
                                Byte* captureStart = i + captureRectangle.X;
                                Byte* captureStop = captureStart + captureRectangle.Width;
                                Byte* capturePointer = (Byte*)monoCaptureData.Scan0;
                                int capturePadding = monoCaptureData.Stride - monoCaptureData.Width;

                                while (i < firstLineAfterCapture) {
                                    while (i < captureStart) {
                                        *o++ = *i++;
                                    }
                                    while (i < captureStop) {
                                        ++histogram[*i];
                                        *capturePointer++ = *i;
                                        *o++ = *i++;
                                    }
                                    while (i < endOfLine) {
                                        *o++ = *i++;
                                    }
                                    endOfLine += fi.Width;
                                    captureStart += fi.Width;
                                    captureStop += fi.Width;
                                    o += padding;
                                    capturePointer += capturePadding;
                                }

                                // copy the remainder of the captured image into the passthru buffer
                                while (i < lastInputPixel) {
                                    while (i < endOfLine) {
                                        *o++ = *i++;
                                    }
                                    o += padding;
                                    endOfLine += fi.Width;
                                }
                            }
                            break;

                        case DriverFunctions.PdtImageFormat.fmtRgb24:

                            Debug.Assert(fi.Owner.PixelSize == 3, "Unexpected pixel size");
                            unsafe {
                                Byte* i = (Byte*)fi.Buffer;
                                Byte* o = (Byte*)colorData.Scan0;
                                Byte* firstLineOfCapture =
                                    i +                                                         // beginning of buffer
                                    3 * captureRectangle.Y * fi.Width;                          // down Y
                                Byte* firstLineAfterCapture =
                                    firstLineOfCapture +                                        // start of capture area
                                    3 * captureRectangle.Height * fi.Width;                     // down height
                                Byte* endOfLine = i + 3 * colorData.Width;
                                Byte* lastInputPixel = i + 3 * fi.Width * fi.Height;
                                int padding = colorData.Stride - 3 * colorData.Width;
                                Byte* monoCapturePointer = (Byte*)monoCaptureData.Scan0;
                                int monoCapturePadding = monoCaptureData.Stride - monoCaptureData.Width;
                                Byte* colorCapturePointer = (Byte*)colorCaptureData.Scan0;
                                int colorCapturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;
                                Byte r, g, b, y;

                                // copy the region up to the beginning of the capture rectangle
                                // change the order for the silly Windows BGR ordering
                                while (i < firstLineOfCapture) {
                                    while (i < endOfLine) {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    o += padding;
                                    endOfLine += 3 * fi.Width;
                                }

                                // copy the region from the top to the bottom of the capture rectangle to 
                                // both the passthru and the capture bitmaps
                                Byte* captureStart = i + 3 * captureRectangle.X;
                                Byte* captureStop = captureStart + 3 * captureRectangle.Width;
                                Byte* capturePointer = (Byte*)colorCaptureData.Scan0;
                                int capturePadding = colorCaptureData.Stride - 3 * colorCaptureData.Width;

                                while (i < firstLineAfterCapture) {
                                    while (i < captureStart) {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    while (i < captureStop) {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;

                                        *colorCapturePointer++ = b;
                                        *colorCapturePointer++ = g;
                                        *colorCapturePointer++ = r;

                                        y = (Byte)((77 * r + 150 * g + 29 * b) >> 8);
                                        ++histogram[y];
                                        *monoCapturePointer++ = y;
                                    }
                                    while (i < endOfLine) {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    endOfLine += 3 * fi.Width;
                                    captureStart += 3 * fi.Width;
                                    captureStop += 3 * fi.Width;
                                    o += padding;
                                    capturePointer += capturePadding;
                                    monoCapturePointer += monoCapturePadding;
                                    colorCapturePointer += colorCapturePadding;
                                }

                                // copy the remainder of the captured image into the passthru buffer
                                while (i < lastInputPixel) {
                                    while (i < endOfLine) {
                                        r = *i++;
                                        g = *i++;
                                        b = *i++;
                                        *o++ = b;
                                        *o++ = g;
                                        *o++ = r;
                                    }
                                    o += padding;
                                    endOfLine += 3 * fi.Width;
                                }
                            }
                            break;
                    }

                    // release all of the bitmaps created
                    if (monoData != null)
                        mono.UnlockBits(monoData);
                    if (colorData != null)
                        color.UnlockBits(colorData);
                    if (monoCaptureData != null)
                        monoCapture.UnlockBits(monoCaptureData);
                    if (colorCaptureData != null)
                        colorCapture.UnlockBits(colorCaptureData);

                    // find the blobs
                    //Blob[] blobs = BlobFinder.FindBlobs(monoCapture, _threshold.Value);

                    // update the passthru bitmap
                    if (isColor)
                        _passthruBitmap.Value = color;
                    else
                        _passthruBitmap.Value = mono;

                    // update _captureBitmap for the preview window, etc...
                    if (isColor)
                        _captureBitmap.Value = colorCapture;
                    else
                        _captureBitmap.Value = monoCapture;
                }

            }
        }
    }
}