using System;
using System.Collections.Generic;
using System.Text;

namespace BrownianMotion
{

    public class GenericEventArgs : EventArgs
    {
        Frame frame;

        public GenericEventArgs(Frame f)
        {
            frame = f;
        }

        public Frame Frame
        {
            get { return frame; }
            set { frame = value; }
        }
    }
    public delegate void GenericEventHandler(object sender, GenericEventArgs args);
}
