using System;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using GoodStuff;
using CameraDriver;
/// <summary>
/// Summary description for FileReader
/// </summary>
namespace BrownianMotion
{
    public class FileReader : WorkerThread
    {
        
        GoodProperty<string> inputDirectory;
        GoodVariable<EventHandler> readNextFrame;
        GoodProperty<uint> framesToRead;
        string currentMoviePath;
        string currentMovieName;
        GoodProperty<string> movieFrameElement;
        FileStream frameInfoFileStream;
        StreamReader frameInfoStreamReader;
        ThreadSafeQueue<SampleEventArgs> frameOutQueue;
        ThreadSafeQueue<SampleEventArgs> inFrameQueue;
        bool readFrame;
        public event SampleEventHandler FrameComplete;

        public FileReader()
        {
            
            inputDirectory = new GoodProperty<string>();
            inputDirectory.Name = "MovieOutputDirectory";
            inputDirectory.DisplayName = "Movie Output Directory";

            movieFrameElement = new GoodProperty<string>();
            movieFrameElement.Name = "MovieFrameElement";
            movieFrameElement.Value = "Bitmap 24BppRgb";
        }


        public void Initialize()
        {
            string threadString = "FileReaderThread." + this.ToString();
            CreateThread(threadString, ThreadPriority.Normal);
            StartThread();
        }

        
        void ThreadProc()
        {
            while (KeepGoing(100))
            {
                if (framesToRead.Value > 0)
                {
                    SampleEventArgs s = inFrameQueue.Dequeue();
                    string fn;
                    currentMoviePath = inputDirectory.Value + @"\" + currentMovieName + @"\";

                    if (!System.IO.Directory.Exists(currentMoviePath))
                    {
                        Trace.WriteLine("FileReader: given currentMoviePath does not exist");
                    }
                    else
                    {
                        string fullPath = currentMoviePath + @"\" + currentMovieName + @" frames" + @".txt";
                        FileStream frameInfoFileStream = new FileStream(fullPath, FileMode.Create);
                        StreamReader frameInfoStreamReader = new StreamReader(frameInfoFileStream);
                        readFrame = true;
                        Bitmap b = (Bitmap)Bitmap.FromFile(fullPath);
                        s.Sample.Add(movieFrameElement.Value, b);
                        if (FrameComplete != null)
                        {
                            FrameComplete(this, s);
                        }
                        lock (framesToRead)
                            --(framesToRead.Value);
                    }
                }
            }
        }


        public void ReadFrame(SampleEventArgs sArgs)
        {
            lock (framesToRead)
            {
                ++(framesToRead.Value);
                inFrameQueue.Enqueue(sArgs);
            }
        }
    }
}
