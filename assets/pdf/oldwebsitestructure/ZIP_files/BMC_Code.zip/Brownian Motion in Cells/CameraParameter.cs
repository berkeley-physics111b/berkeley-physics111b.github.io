using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Xml.Serialization;
using System.Reflection;
using GoodStuff;

namespace CameraDriver
{
    public class CameraParameterDescriptor
    {
        #region Instance Variables
        UInt32 _key;
        [XmlElement("Key")]
        public UInt32 Key
        {
            get { return _key; }
            set { _key = value; }
        }
        String _name;
        [XmlElement("Name")]
        public String Name
        {
            get { return _name; }
            set { _name = value; }
        }
        List<ProsilicaEnumeratedParameterValue> _enumeratedValueList;

        [XmlElement("EnumeratedValues")]
        public ProsilicaEnumeratedParameterValue[] ParameterList
        {
            get
            {
                return _enumeratedValueList.ToArray();
            }
            set
            {
                if (value == null) return;
                ProsilicaEnumeratedParameterValue[] parameters = (ProsilicaEnumeratedParameterValue[])value;
                _enumeratedValueList.Clear();
                foreach (ProsilicaEnumeratedParameterValue v in parameters)
                    _enumeratedValueList.Add(v);
            }
        }
        #endregion
        public CameraParameterDescriptor()
        {
            _enumeratedValueList = new List<ProsilicaEnumeratedParameterValue>();
        }
    }
    public class CameraParameter : GoodNumericVariable<UInt32>
    {
        #region Instance Variables
        Camera _owner;
        public Camera Owner { get { return _owner; } set { _owner = value; }}

        UInt32 _key;
        public PdtParamKey Key{ get { return (PdtParamKey)_key; }}

        #endregion

        #region Parameter Value and Constraints

        UInt32 _min;
        public UInt32 Min { get { return _min; } }

        UInt32 _max;
        public UInt32 Max { get { return _max; } }
        UInt32 _default;

        public UInt32 Default { get { return _default; } }

        bool _supported;
        public bool Supported { get { return _supported; } }
        UInt32 _valueSupport;

        public UInt32 ValueSupport { get { return _valueSupport; } }

        #endregion

        public CameraParameter()
        {
            _syncRoot = new Object();
        }

        public CameraParameter(Camera owner, PdtParamKey key, string name)
        {
            _owner = owner;
            _key = (UInt32)key;
            _name = name;
        }

        public void Update()
        {
            _supported = DriverFunctions.PdIsParamSupported(_owner.CameraHandle, _key) == DriverFunctions.PdtErr.errSuccess;

            if (_supported)
            {
                DriverFunctions.PdGetParamRange(_owner.CameraHandle, _key, out _min, out _max, out _default);
                DriverFunctions.PdGetParamValueSupport(_owner.CameraHandle, _key, out _valueSupport);
                DriverFunctions.PdGetParam(_owner.CameraHandle, _key, out _value);
            }
        }

        #region IGoodVariable<UInt32> Members

        public override UInt32 Value
        {
            get 
            {
                return _value;
            }
            set 
            {
                lock (_syncRoot)
                {
                    _value = (UInt32) value;
                    SetValue(value);
                }
            }
        }

        public Decimal SetValue(Decimal v)
        {
            _value = (UInt32) v;
            DriverFunctions.PdSetParam(_owner.CameraHandle, _key, _value);
            RaiseValueChanged();
            return _value;
        }

        #endregion
    } // end of class CameraParameter

    public class ProsilicaEnumeratedParameterValue
    {
        UInt32 _value;
        [XmlElement("Value")]
        public UInt32 Value
        {
            get { return _value; }
            set { _value = value; }
        }
        String _name;
        [XmlElement("Name")]
        public String Name
        {
            get { return _name; }
            set { _name = value; }
        }
        String _description;
        [XmlElement("Description")]
        public String Description
        {
            get { return _description; }
            set { _description = value; }
        }
        ProsilicaEnumeratedParameterValue()
        {
        }
    }


    [XmlRoot("CameraParameterDescriptorList")]
    public class CameraParameterDescriptorList
    {
        List<CameraParameterDescriptor> _parameterList;

        [XmlElement("ParameterDescriptor")]
        public CameraParameterDescriptor[] ParameterList
        {
            get 
            {
                CameraParameterDescriptor[] parameters = new CameraParameterDescriptor[_parameterList.Count];
                _parameterList.CopyTo(parameters);
                return parameters; 
            }
            set 
            {
                if (value == null) return;
                CameraParameterDescriptor[] parameters = (CameraParameterDescriptor[])value;
                _parameterList.Clear();
                foreach (CameraParameterDescriptor d in parameters)
                    _parameterList.Add(d);
            }
        }

        public CameraParameterDescriptorList()
        {
            _parameterList = new List<CameraParameterDescriptor>();
        }

        public void Add(CameraParameterDescriptor c)
        {
            _parameterList.Add(c);
        }

        static CameraParameterDescriptorList _instance;
        static public List<CameraParameterDescriptor> GetCameraParameterDescriptorList()
        {

            if (_instance == null)
            {
                XmlSerializer s = new XmlSerializer(typeof(CameraParameterDescriptorList));
                FileStream fs = new FileStream("CameraParameters.xml", FileMode.Open);
                _instance = (CameraParameterDescriptorList)s.Deserialize(fs);
                fs.Close();
            }
            return _instance._parameterList;
        }
        static public CameraParameterDescriptorList ReadParamatersFromEmbeddedResource()
        {
            Assembly a = Assembly.GetExecutingAssembly();
            Stream fs = a.GetManifestResourceStream(@"CameraParameters.xml");
            XmlSerializer s = new XmlSerializer(typeof(CameraParameterDescriptorList));
            CameraParameterDescriptorList cpdl = (CameraParameterDescriptorList)s.Deserialize(fs);

            return cpdl;
        }
    }

    public enum PdtParamKey
    {
        paramExposure = 0,
        paramAutoExposureMode = 1,
        paramOffset = 2,
        paramGain = 3,
        paramExtTrigMode = 4,
        paramExtTrigPol = 5,
        paramTestImage = 6,
        paramShutterMode = 7,
        paramGamma = 8,
        paramExtSyncMode = 9,
        paramTriggerDelay = 10,
        paramMultislopeMode = 11,
        paramMultislopeExp2 = 12,
        paramMultislopeExp3 = 13,
        paramMultislopeExp4 = 14,
        paramReferenceLevel = 15,
        paramOffsetMode = 16,
        paramReserved1 = 17,
        paramWhitebalanceMode = 18,
        paramReserved2 = 19,
        paramRedGain = 20,
        paramBlueGain = 21,
        paramFrameRateEnable = 22,
        paramFrameRate = 23,
        paramGpio1Mode = 24,
        paramGpio2Mode = 25,
        paramGpio3Mode = 26,
        paramGpio4Mode = 27,
        paramGpioLevels = 28,
        paramReserved4 = 29,
        __param_count = 30,
        __param_force_32 = -1

    }

}
