using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.IO;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using GoodStuff;



namespace BrownianMotion
{
    public class FileReader : WorkerThread, IInitializable
    {
        
        
        public event SampleEventHandler ReportStatus;
        public event SampleEventHandler BitmapsReady;

        ThreadSafeQueue<SampleEventArgs> _bufferQueue;
        string currentMoviePath;
        //string currentMovieName;
        GoodProperty<string> movieFrameElement;
        FileStream frameInfoFileStream;
        StreamReader frameInfoStreamReader;
        ThreadSafeQueue<SampleEventArgs> inFrameQueue;

        int NumberofFramesStillProcessing; //the number of frames that we've sent out that haven't come back in yet. 
        int MaxNumberofFramesOut;
        //This number should be high for smooth processing and low for good response. 

        int FrameNumber;

        GoodProperty<string> _inputDirectory;
        public GoodProperty<string> InputDirectory
        {
            get { return _inputDirectory; }
            set{_inputDirectory = value;}
        }
        GoodProperty<string> _currentMovieName;
        public GoodProperty<string> CurrentMovieName
        {
            get { return _currentMovieName; }
            set { _currentMovieName = value; }
        }
        public void UIDirectoryChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                _inputDirectory.Value = (string)sArgs.Sample["Value"];
        }
        public void UIMovieNameChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                _currentMovieName.Value = (string)sArgs.Sample["Value"];
        }
        public void Quit(object sender, SampleEventArgs sArgs)
        {
            StopThread();
        }
        public void ReportStatusLocal(string messageout)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("Message", messageout);
            if (ReportStatus != null)
                ReportStatus(this, s);
        }


        public FileReader()
        {
            FrameNumber = 0;
            inFrameQueue = new ThreadSafeQueue<SampleEventArgs>(600);

            _inputDirectory = new GoodProperty<string>();
            _inputDirectory.Name = "MovieInputDirectory";
            _inputDirectory.DisplayName = "Movie Input Directory";

            _currentMovieName = new GoodProperty<string>();
            _currentMovieName.Value = "Movie 1";

            movieFrameElement = new GoodProperty<string>();
            movieFrameElement.Name = "MovieFrameElement";
            movieFrameElement.Value = "CaptureBitmap";
            _inputDirectory.Value = "\\\\atlas2\\redirect$\\16461851\\My Documents\\BIO Lab Work\\Movies";

            MaxNumberofFramesOut = 5;
            NumberofFramesStillProcessing = 0;
            _bufferQueue = new ThreadSafeQueue<SampleEventArgs>(10);
        }
        public void Initialize()
        {
            string threadString = "FileReaderThread." + this.ToString();
            CreateThread(threadString, ThreadPriority.Normal);
            StartThread();
            //openFileDialog = new System.Windows.Forms.OpenFileDialog();
            //openFileDialog.ShowDialog();
            //LoadFrames();
        }
        override protected void ThreadProc()
        {
            int FrameNumber = 1;
            while (KeepGoing())
            {
                _bufferQueue.Wait(250);
                while (_bufferQueue.Count > 0)
                {
                    if (BitmapsReady != null)
                        BitmapsReady(this, _bufferQueue.Dequeue());
                    else
                        _bufferQueue.Dequeue();
                }
            }
        }
        public void TriggerShot(object sender, SampleEventArgs sArgs)
        {
            if (NumberofFramesStillProcessing >= MaxNumberofFramesOut)
                return;
            else if(inFrameQueue.Count>0)
            {
                NumberofFramesStillProcessing++; 
                _bufferQueue.Enqueue(ReadFrame());
            }
            else
                ReportStatusLocal("Read Bitmap Queue is empty, please load more Bitmaps");

        }
           
        public void LoadFrames(object sender, SampleEventArgs sArgs)
        {
            currentMoviePath = _inputDirectory.Value + @"\" + _currentMovieName.Value + @"\";
            string fullPath = currentMoviePath + @"\" + _currentMovieName.Value + @" frames" + @".txt";
            //fullPath = "\\\\atlas2\\redirect$\\16461851\\My Documents\\BIO Lab Work\\Movies\\Movie 1\\Movie 1 frames.txt";
            //FileStream frameInfoFileStream = new FileStream(fullPath);
            if (File.Exists(fullPath))
            {
                StreamReader frameInfoStreamReader = new StreamReader(fullPath);
                while (!frameInfoStreamReader.EndOfStream)
                {
                    SampleEventArgs newframe = new SampleEventArgs();
                    string filename = currentMoviePath + frameInfoStreamReader.ReadLine();
                    DateTime DT = DateTime.Parse(frameInfoStreamReader.ReadLine());
                    int test = int.Parse(frameInfoStreamReader.ReadLine());
                    DT = DT.AddMilliseconds(test);
                    Bitmap B = new Bitmap(filename);
                    newframe.Sample.Add("Time", DT);
                    newframe.Sample.Add(movieFrameElement.Value, B);

                    inFrameQueue.Enqueue(newframe);
                }
                ReportStatusLocal("Loaded Frames from " + currentMoviePath);
            }
            else
                ReportStatusLocal("File Not Found.");
        }
        public Byte[,] ReduceFrame(Bitmap B)
        {
            int height = B.Height; //accessing bitmap's variables is always superslow;
            int width = B.Width;

            Byte[,] outArray = new byte[width, height];
            
            if (B.PixelFormat == PixelFormat.Format24bppRgb)
            {

                BitmapData bd = B.LockBits(
                        new Rectangle(0, 0, B.Width, B.Height),
                        ImageLockMode.ReadWrite,
                        PixelFormat.Format24bppRgb);
                unsafe
                {
                    Byte* pixelpointer = (Byte*)bd.Scan0;
                    int padding = bd.Stride - 3 * bd.Width;
                    Byte r, g, b;
                    byte gray;
                    for (int y = 0; y < height; y++)
                    {
                        for (int x = 0; x < width; x++)
                        {
                            r = *pixelpointer++;
                            g = *pixelpointer++;
                            b = *pixelpointer++;
                            gray = (Byte)((77 * r + 150 * g + 29 * b) >> 8);
                            outArray[x, y] = gray;
                        }
                        pixelpointer += padding;
                    }
                }
                B.UnlockBits(bd);
            }
            else if(B.PixelFormat == PixelFormat.Format8bppIndexed)
            {
                BitmapData bd = B.LockBits(
                        new Rectangle(0, 0, B.Width, B.Height),
                        ImageLockMode.ReadWrite,
                        PixelFormat.Format8bppIndexed);
                unsafe
                {
                    Byte* pixelpointer = (Byte*)bd.Scan0;
                    int padding = bd.Stride - bd.Width;
                    byte gray;
                    for (int y = 0; y < height; y++)
                    {
                        for (int x = 0; x < width; x++)
                        {
                            gray = *pixelpointer++; 
                            outArray[x, y] = gray;
                        }
                        pixelpointer += padding;
                    }
                }
                B.UnlockBits(bd);
            }
            return outArray;
        }
        public SampleEventArgs ReadFrame()
        {
            if (inFrameQueue.Count < 1)
            {
                ReportStatusLocal("Read Bitmap Queue is empty, please load more Bitmaps");
                return new SampleEventArgs();
            }
            else
            {
                DateTime start = DateTime.Now;
                SampleEventArgs s = inFrameQueue.Dequeue();
                FrameNumber++;
                DateTime Time = (DateTime)s.Sample["Time"];
                //            string filename = (string)s.Sample[movieFrameElement.Value];
                //Bitmap B = new Bitmap(filename);
                Bitmap B = (Bitmap)s.Sample[movieFrameElement.Value];
                
                byte[,] monoArray = ReduceFrame(B);
                

                s.Sample.Add("FrameNumber", FrameNumber);
                s.Sample.Add("CaptureRegionArray", monoArray);
                s.Sample.Add("SourceName", "FileReader");
                DateTime end = DateTime.Now;
                TimeSpan span = end - start;
                return s;
             }
        }
        public void FrameReturned(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("SourceName") && sArgs.Sample["SourceName"] == "FileReader")
                NumberofFramesStillProcessing--;
        }




                

                        

    }
}
