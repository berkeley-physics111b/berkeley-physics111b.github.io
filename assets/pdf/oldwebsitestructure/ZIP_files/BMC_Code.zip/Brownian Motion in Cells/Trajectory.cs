using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Text;
using CameraDriver;
namespace BrownianMotion
{
  public class TrajectoryNode  {
    public ParticleInfo particleInfo;
    public TrajectoryNode nextNode;
    public TrajectoryNode previousNode;
    
      public TrajectoryNode(ParticleInfo pInfo)
      {
          particleInfo = pInfo;
      }
      public TrajectoryNode(ParticleInfo pInfo, TrajectoryNode nNode, TrajectoryNode pNode)
      {
          particleInfo = pInfo;
          nextNode = nNode;
          previousNode = pNode;
      }
      public ParticleInfo ParticleInfo{
        get{return particleInfo;}
        set{particleInfo = value;}
    }


    public TrajectoryNode NextNode{
       get {return nextNode;}
       set {nextNode = value;}
        }

    public TrajectoryNode PreviousNode {
        get {return previousNode;}
        set {previousNode = value;}
    }
  }




public class TrajectoryEnumerator : IEnumerator {
    private Trajectory trajectory;
    private int validModificationCount;
    public TrajectoryNode currentNode;

    public TrajectoryEnumerator (Trajectory trajectory) {
        this.trajectory = trajectory;
        validModificationCount = trajectory.modifications;
        currentNode = trajectory.headerNode;
    }

    public object Current{
        get {return currentNode;}
        set {currentNode = (TrajectoryNode) value;}
    }

    public void Reset() {
        currentNode = trajectory.headerNode;
    }

    public bool MoveNext() {
           bool moveSuccessful = false;

    if (validModificationCount != trajectory.modifications)
      throw new SystemException(
          "A concurrent modification occured to the Trajectory" + 
          "while accessing it through it's enumerator.");

    currentNode = currentNode.NextNode;

    if (currentNode != trajectory.headerNode)
      moveSuccessful = true;

    return moveSuccessful;
    }
}


    // a trajectory is a linked list of particle event info. 

   public class Trajectory: IList/*, ICloneable */{
    public int validModificationCount;
    public TrajectoryNode headerNode;
    public int modifications;
       public int count;
    public TrajectoryNode FindNodeAt(int frameNumber) {
     TrajectoryNode node = headerNode;
    
        if (frameNumber < (count / 2))
        {
      for (int i = 0; i <= frameNumber; i++)
        node = node.NextNode;
        }
    else
        {
      for (int i = count; i > frameNumber; i--)
        node = node.PreviousNode;
        }
        return node;
    }
   
   public void Remove(TrajectoryNode node) {
       TrajectoryNode value = headerNode;
       if(node != headerNode) {
            node.PreviousNode.NextNode = value.NextNode;
            value.NextNode.PreviousNode = value.PreviousNode;
            count--;
            modifications++;
        }
    }

//       public void Add(TrajectoryNode node)
    public int Add(object node)
   {
       int returnInt = count;
       modifications++;
        headerNode.NextNode = (TrajectoryNode) node;
           ((TrajectoryNode)node).PreviousNode = headerNode;
           headerNode = (TrajectoryNode) node;
           count++;
           return count;
    }


    public Trajectory Clone()
{
  Trajectory trajectoryClone = new Trajectory();

  for (TrajectoryNode node = headerNode.NextNode; node != headerNode; 
          node = node.NextNode)
    trajectoryClone.Add(node);

  return trajectoryClone;
}
  
public Trajectory Clone(bool attemptDeepCopy)
{
  Trajectory trajectoryClone;

  if (attemptDeepCopy)
  {
    trajectoryClone = new Trajectory();

    object currentObject;

    for (TrajectoryNode node = headerNode.NextNode; node != headerNode; 
           node = node.NextNode)
    {
      currentObject = node;

      if (currentObject == null)
        trajectoryClone.Add(null);
      else if (currentObject is ICloneable)
        trajectoryClone.Add(((ICloneable)currentObject).Clone());
      else
        throw new SystemException("The object of type [" + 
                     currentObject.GetType() + 
                     "] in the list is not an ICloneable, cannot attempt " + 
                     "a deep copy.");
    } 
  }
  else
    trajectoryClone = (Trajectory)this.Clone();

  return trajectoryClone;
}
     /*  public Trajectory Clone()
       {
           Trajectory trajectoryClone;

               trajectoryClone = new Trajectory();

               object currentObject;

               for (TrajectoryNode node = headerNode.NextNode; node != headerNode;
                      node = node.NextNode)
               {
                   currentObject = node.CurrentNode;

                   if (currentObject == null)
                       trajectoryClone.Add(null);
                   else if (currentObject is ICloneable)
                       trajectoryClone.Add(((ICloneable)currentObject).Clone());
                   else
                       throw new SystemException("The object of type [" +
                                    currentObject.GetType() +
                                    "] in the list is not an ICloneable, cannot attempt " +
                                    "a deep copy.");
               }       
           return trajectoryClone;
       }*/

    public virtual void InsertAll(int index, ICollection collection)
{
  if (collection != null)
  {
    if (0 < collection.Count)
    {
      modifications++;

      TrajectoryNode startingNode = (index == count ? 
                  headerNode : FindNodeAt(index));
     TrajectoryNode previousNode = startingNode.PreviousNode;

      foreach (object obj in collection)
      {
        TrajectoryNode node  = new TrajectoryNode((ParticleInfo) obj, 
                  startingNode, previousNode);
        previousNode.NextNode = node;
        previousNode          = node;
      }

      startingNode.PreviousNode = previousNode;

      count += collection.Count;            
    }
    else
      throw new ArgumentOutOfRangeException("index", 
                   index, "less than zero");
  }
  else
    throw new ArgumentNullException("collection");
        }

        #region IList Members


        public void Clear()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public bool Contains(object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public int IndexOf(object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Insert(int index, object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public bool IsFixedSize
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public bool IsReadOnly
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public void Remove(object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void RemoveAt(int index)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public object this[int index]
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        #endregion

        #region ICollection Members

        public void CopyTo(Array array, int index)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public int Count
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public bool IsSynchronized
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        public object SyncRoot
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        #endregion

        #region IEnumerable Members

        public IEnumerator GetEnumerator()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion

        #region IList Members

        int IList.Add(object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        void IList.Clear()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        bool IList.Contains(object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        int IList.IndexOf(object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        void IList.Insert(int index, object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        bool IList.IsFixedSize
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        bool IList.IsReadOnly
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        void IList.Remove(object value)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        void IList.RemoveAt(int index)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        object IList.this[int index]
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
            set
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }

        #endregion

        #region ICollection Members

        void ICollection.CopyTo(Array array, int index)
        {
            throw new Exception("The method or operation is not implemented.");
        }

        int ICollection.Count
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        bool ICollection.IsSynchronized
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        object ICollection.SyncRoot
        {
            get { throw new Exception("The method or operation is not implemented."); }
        }

        #endregion

        #region IEnumerable Members

        IEnumerator IEnumerable.GetEnumerator()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        #endregion
    }

}

