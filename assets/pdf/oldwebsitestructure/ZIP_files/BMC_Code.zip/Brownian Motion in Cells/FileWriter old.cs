using System;
using System.Diagnostics;
using System.Threading;
using System.IO;
using System.Drawing;
using GoodStuff;
using CameraDriver;
/// <summary>
/// Summary description for Class1
/// </summary>
namespace BrownianMotion {
    public class FileWriter: WorkerThread
    {
        GoodProperty<uint> _framesToCapture;
        GoodVariable<SampleEventHandler> _start;
        GoodVariable<SampleEventHandler> _stop;
        GoodProperty<string> _outputDirectory;
        GoodProperty<string> _movieName;
        GoodProperty<uint> _movieNumber;
        GoodProperty<bool> _autoincrementName;
        GoodProperty<string> _movieFrameElement;
        GoodProperty<uint> _framesCaptured;
        ManualResetEvent _capturing;

        ThreadSafeQueue<SampleEventArgs> _frameQueue;

        FileStream _frameInfoFileStream;
        StreamWriter _frameInfoStreamWriter;

        string _currentMoviePath;
        string _currentMovieName;

        public void Initialize()
        {
            string threadString = "FileWriterThread." + this.ToString();
            CreateThread(threadString, ThreadPriority.Normal);
            StartThread();
        }

        public void init(object sender, SampleEventArgs gArgs)
        {
            Initialize();
        }

        public GoodProperty<string> MovieName
        {
            get
            {
                return _movieName;
            }
            set
            {
                _movieName = value;
            }
        }

        public GoodProperty<uint> FramesCaptured
        {
            get
            {
                return _framesCaptured;
            }
            set
            {
                _framesCaptured = value;
            }
        }

        public event SampleEventHandler Start
        {
            add { _start.Value += value; }
            remove { _start.Value -= value; }
        }

        public event SampleEventHandler Stop
        {
            add { _stop.Value += value; }
            remove { _stop.Value -= value; }
        }


        public FileWriter()
        {
            _frameQueue = new ThreadSafeQueue<SampleEventArgs>(300);
            _capturing = new ManualResetEvent(true);
 
            _movieFrameElement = new GoodProperty<string>();
            _movieFrameElement.Value = "Bitmap 8BppMono";

            _framesToCapture = new GoodProperty<UInt32>();
            _framesToCapture.Name = "FramesToCapture";
            _framesToCapture.DisplayName = "Number of Frames";
            _framesToCapture.Value = 300;

            _start = new GoodVariable<SampleEventHandler>();
            _start.Name = "startCapture";
            _start.DisplayName = "Start Capturing";
            _start.Value = new SampleEventHandler(StartCapture);

            _stop = new GoodVariable<SampleEventHandler>();
            _stop.Name = "stopCapture";
            _stop.DisplayName = "stop Capturing";
            _stop.Value = new SampleEventHandler(StopCapture);

            _outputDirectory = new GoodProperty<string>();
            _outputDirectory.Name = "MovieOutputDirectory";
            _outputDirectory.DisplayName = "Movie Output Directory";
            _outputDirectory.Value = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\BIO Lab Work\Movies";

            _movieName = new GoodProperty<string>();
            _movieName.Name = "MovieName";
            _movieName.DisplayName = "Movie Name";
            _movieName.Value = "Movie";

            _movieNumber = new GoodProperty<uint>();
            _movieNumber.Name = "MovieNumber";
            _movieNumber.DisplayName = "Movie Number";
            _movieNumber.Value = 0;

            _autoincrementName = new GoodProperty<bool>();
            _autoincrementName.Name = "AutoincrementMovieName";
            _autoincrementName.DisplayName = "Automatically Increment Movie Name";
            _autoincrementName.Value = true;

            _movieFrameElement = new GoodProperty<string>();
            _movieFrameElement.Name = "MovieFrameElement";
            _movieFrameElement.Value = "Bitmap 24BppRgb";

            _framesCaptured = new GoodProperty<uint>();
            _framesCaptured.Name = "FramesCaptured";
            _framesCaptured.DisplayName = "Frames Captured";
            _framesCaptured.Value = _framesToCapture.Value;
        }

        protected void ThreadProc()
        {
            while (KeepGoing(100))                                           // loop until quit signal
            {
                _frameQueue.Wait(100);                                       // wait for a frame to be queued

                while (_frameQueue.Count > 0)                                // loop until all queued frames processed
                {
                    SampleEventArgs s = _frameQueue.Dequeue();                         // get the next frame

                    if (_framesCaptured.Value == 0)                                // starting a new movie
                        StartMovieCapture(s);                                 // write movie info and open frame info stream

                    if (_framesCaptured.Value < _framesToCapture.Value)            // movie capture in progress
                        WriteFrame(s);                                       // write out a .bmp file

                    if ((_framesCaptured.Value >= _framesToCapture.Value) &&       // movie capture ending
                        (_frameInfoStreamWriter != null))
                        EndMovieCapture();                                   // close all the open streams

                    if (FrameComplete != null)
                        FrameComplete(this, s);  // pass frame on to next object for processing
                    else
                        s = null;                                            // dispose of the frame
                }                                                            // end of while(_frames.Count > 0)
            }                                                                // end of while(KeepGoing())

            EndMovieCapture();                                               // make sure file streams are close before quitting
        }

        private void StartMovieCapture(SampleEventArgs s)
        {
            // let everybody know a movie is in progress
            _capturing.Reset();

            if (s.Sample.ContainsKey("MovieOutputDirectory"))
            {
                object outputDirectoryGet;
                s.Sample.TryGetValue("MovieOutputDirectory", out outputDirectoryGet);
                _outputDirectory = (GoodProperty<string>) outputDirectoryGet;
            }
            else
            {
                _outputDirectory = new GoodProperty<string>();
                _outputDirectory.Name = "MovieOutputDirectory";
                _outputDirectory.DisplayName = "Movie Output Directory";
                _outputDirectory.Value = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\BIO Lab Work\Movies";
            }
            if (s.Sample.ContainsKey("MovieFrameElement"))
            {
                object movieFrameGet;
                s.Sample.TryGetValue("MovieFrameElement", out movieFrameGet);
                _movieFrameElement  = (GoodProperty<string>)movieFrameGet;
            }
            else
            {
                _movieFrameElement.Value = "Bitmap 8BppMono";
            }

            if (s.Sample.ContainsKey("framesToCapture"))
            {
                object framesToCGet;
                s.Sample.TryGetValue("framesToCapture", out framesToCGet);
                _framesToCapture = (GoodProperty<uint>)framesToCGet;
            }
            else
            {
                _framesToCapture = new GoodProperty<UInt32>();
                _framesToCapture.Name = "framesToCapture";
                _framesToCapture.DisplayName = "Number of Frames";
                _framesToCapture.Value = 300;
            }

            if (s.Sample.ContainsKey("movieName"))
            {
                object movieNameGet;
                s.Sample.TryGetValue("movieName", out movieNameGet);
                _movieName = (GoodProperty<string>)movieNameGet;
            }
            else
            {
                _movieName = new GoodProperty<string>();
                _movieName.Name = "MovieName";
                _movieName.DisplayName = "Movie Name";
                _movieName.Value = "Movie";
            }

            if (s.Sample.ContainsKey("movieNumber"))
            {
                object movieNumberGet;
                s.Sample.TryGetValue("movieNumber", out movieNumberGet);
                _movieNumber = (GoodProperty<uint>) movieNumberGet;
            }
            else
            {
                _movieNumber = new GoodProperty<uint>();
                _movieNumber.Name = "movieNumber";
                _movieNumber.DisplayName = "Movie Number";
                _movieNumber.Value = 0;
            }
            if (s.Sample.ContainsKey("Auto Increment Name"))
            {
                object autoIncrementGet;
                s.Sample.TryGetValue("autoIncrementMovieName", out autoIncrementGet);
                _autoincrementName = (GoodProperty<bool>)autoIncrementGet;
            }
            else
            {
                _autoincrementName = new GoodProperty<bool>();
                _autoincrementName.Name = "autoIncrementMovieName";
                _autoincrementName.DisplayName = "Automatically Increment Movie Name";
                _autoincrementName.Value = true;
            }
            if (s.Sample.ContainsKey("movieFrameElement"))
            {
                object movieFrameGet;
                s.Sample.TryGetValue("movieFrameElement", out movieFrameGet);
                _movieFrameElement = (GoodProperty<string>)movieFrameGet;
            }
            else
            {
                _movieFrameElement = new GoodProperty<string>();
                _movieFrameElement.Name = "movieFrameElement";
                _movieFrameElement.Value = "Bitmap 24BppRgb";
            }
            if (s.Sample.ContainsKey("FramesCaptured"))
            {
                object framesCapturedGet;
                s.Sample.TryGetValue("FramesCaptured", out framesCapturedGet);
                _framesCaptured = (GoodProperty<uint>)framesCapturedGet;
            }
            else
            {
                _framesCaptured = new GoodProperty<uint>();
                _framesCaptured.Name = "FramesCaptured";
                _framesCaptured.DisplayName = "Frames Captured";
                _framesCaptured.Value = _framesToCapture.Value;
            }
                // write out the movie parameters
            string fn;
            fn = _currentMoviePath + @"\" + _currentMovieName + @" info" + @".txt";
            FileStream fs = new FileStream(fn, FileMode.Create);
            StreamWriter sw = new StreamWriter(fs);
            sw.WriteLine(
                "Capture Started at: " + DateTime.Now.ToString()); /*+
                " Sample Period: " +
                    (StateStore.Store["Sample Period"] as GoodNumericVariable<int>).ToString() +
                    "ms"+
                " Dimensions: " +
                    (StateStore.Store["CaptureRegion"] as GoodVariable<Rectangle>).ToString());*/
            sw.Close();
            fs.Close();

            // open the frame info stream
            fn = _currentMoviePath + @"\" + _currentMovieName + @" frames" + @".txt";
            _frameInfoFileStream = new FileStream(fn, FileMode.Create);
            _frameInfoStreamWriter = new StreamWriter(_frameInfoFileStream);
        }

        private void WriteFrame(SampleEventArgs s)
        {
            Debug.Assert(s.Sample.ContainsKey(_movieFrameElement.Value), "Frame does not contain movie element");
            string time= " ";
            if (s.Sample.ContainsKey("Time"))
                time = ((DateTime)s.Sample["Time"]).ToShortTimeString();
            
            Bitmap b;
            b = (Bitmap)s.Sample["movieFrameElement"];
            //_movieFrameElement.Value
            string frameName = _currentMovieName + @" Frame " + (_framesCaptured.Value).ToString() + @".bmp";
            string fullPath = _currentMoviePath + frameName;                                                   // frame name
            b.Save(fullPath);
            _frameInfoStreamWriter.WriteLine(frameName + " " + time);

            lock (_framesToCapture)
                ++(_framesCaptured.Value);
        }

        private void EndMovieCapture()
        {
            Trace.WriteLine("Ending Movie Capture " + _currentMovieName);

            if (_frameInfoStreamWriter != null)
            {
                _frameInfoStreamWriter.Close();
                _frameInfoStreamWriter = null;
            }
            if (_frameInfoFileStream != null)
            {
                _frameInfoFileStream.Close();
                _frameInfoFileStream = null;
            }
            if (_autoincrementName.Value)                                // increase the movie number
                ++(_movieNumber.Value);

            _capturing.Set();
        }

        /// <summary>
        /// Event handler causes a movie capture to begin
        /// </summary>
        /// <param name="sender">Object requesting movie capture</param>
        /// <param name="args">Generic EventArgs</param>
        void StartCapture(object sender, SampleEventArgs sArgs)
        {

            object outDGet;
            object movieFrameGet;
            object movieNameGet;
            sArgs.Sample.TryGetValue("MovieOutputDirectory", out outDGet);
            _outputDirectory = (GoodProperty<string>)outDGet;
            sArgs.Sample.TryGetValue("MovieElement", out movieFrameGet);
            _movieFrameElement = (GoodProperty<string>)movieFrameGet;
            sArgs.Sample.TryGetValue("MovieName", out movieNameGet);
            _movieName = (GoodProperty<string>)movieNameGet;
            // stop a capture in progress, if any
            StopCapture(this, sArgs);

            // create the directory, if needed
            _currentMovieName = _movieName.Value;
            if (_autoincrementName.Value)
                _currentMovieName += " " + (_movieNumber.Value).ToString();

            _currentMoviePath = _outputDirectory.Value + @"\" + _currentMovieName + @"\";

            if (!System.IO.Directory.Exists(_currentMoviePath))
                System.IO.Directory.CreateDirectory(_currentMoviePath);

            lock (_framesToCapture)
                _framesCaptured.Value = 0;

            Trace.WriteLine("MovieWriter.StartCaptue: beginning movie: " + _currentMovieName);
        }

        /// <summary>
        /// Event handler causes a movie capture in progress to stop.
        /// Blocks until capture has been stoppen or timed out.
        /// </summary>
        /// <param name="sender">Object requesting stop capture</param>
        /// <param name="args">Generic EventArgs</param>
        void StopCapture(object sender, SampleEventArgs sArgs)
        {
            if (!_capturing.WaitOne(0, false))                                           // test to see if capturing
            {
                Trace.WriteLine("MovieWriter.StopCapture: ending movie " + _currentMovieName.ToString());

                _framesCaptured.Value = _framesToCapture.Value;

                // wait for acknowledgment from ThreadProc
//                int timeout = (int)((GoodTimer)StateStore.Store["SamplePeriod"]).Value;
//                int timeout = (int)((GoodTimer)args.Frame._objects.TryGetValue("SamplePeriod")).Value;
                GoodVariable<UInt32> sPeriod;
                object sPeriodGet;
                GoodTimer sTimer = (GoodTimer)sArgs.Sample["SampleTimer"];
                //int timeout = (int)sTimer;
                //bool b = _capturing.WaitOne(2 * timeout, false);

                //Trace.WriteLineIf(b != false, "StopCapture: wait for movie to end timed out");
            }
        }

        
        public void ProcessFrame(object sender, SampleEventArgs sArgs)
        {
            _frameQueue.Enqueue(sArgs);
        }

        public event SampleEventHandler FrameComplete;

         }
}
