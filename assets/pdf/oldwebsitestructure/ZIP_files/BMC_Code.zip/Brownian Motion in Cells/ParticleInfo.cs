using System;
using System.Drawing;
using CameraDriver;
/// <summary>
/// Summary description for Class1
/// </summary>
namespace BrownianMotion {
    public class ParticleInfo {
        private Point location;
        private Point delta; // delta between frames

        public ParticleInfo()
	{
        location = new Point();
        delta = new Point();
    }
        public Point Location
        {
            get { return location; }
            set { location = (Point)value; }
        }
        public Point Delta
        {
            get { return delta; }
            set { delta = (Point)value; }
        }

        public ParticleInfo(ParticleInfo idol)
        {
            location = idol.location;
            delta = idol.delta;
        }

    }
}
