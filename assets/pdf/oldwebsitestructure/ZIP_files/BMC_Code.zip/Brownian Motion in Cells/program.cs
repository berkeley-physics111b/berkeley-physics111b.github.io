using System;
using System.Collections.Generic;
using System.Text;
using GoodStuff;
using CameraDriver;
namespace BrownianMotion
{
        static class Program
        {
            /// <summary>
            /// The main entry point for the application.
            /// </summary>
            [STAThread]
            static void Main()
            {
                Dictionary<string, object> o = new Dictionary<string, object>();
//                StateStore s = StateStore.GetStore();
//                Application.EnableVisualStyles();
                //            Housekeeper.Startup();
                GoodObjectBuilder.ReadFile("brownianMotion.xml");
                Camera cam = ObjectManager.Get("Camera") as Camera;
                cam.Close();
                //            GoodWindow gw = ObjectManager.Get("Main Window") as GoodWindow;
                //            gw.Run();
            }
        }
    }

