using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using GoodStuff;
using CameraDriver;

namespace BrownianMotion
{
    public partial class FormPassthru : Form
    {
        public FormPassthru()
        {
            InitializeComponent();
            _passthruGraphics = CreateGraphics();
            
        }
        public event SampleEventHandler StateChanged;
        public event MouseEventHandler MoveCenter;
        private Graphics _passthruGraphics;
        private GoodVariable<Rectangle> captureRegion;
        private Rectangle captureRectangle;
        public GoodVariable<Rectangle> CaptureRegion {
            get {
                return captureRegion;
            }
            set {
               captureRegion = value;
            }
        }

        public void init(object sender, SampleEventArgs sArgs)
        {
            captureRegion = new GoodVariable<Rectangle>();
            
            //captureRegion.Value = new Rectangle
            object cSizeVal;
            // a horrid cludge to get things moving
            ClientSize = new Size(659, 493);
            
            object captureRegionGet;
//            e.Frame._objects.TryGetValue("MaximumImageDimensions", out cSizeVal);
  //          ClientSize = (Size)cSizeVal;
            sArgs.Sample.TryGetValue("CaptureRegion", out captureRegionGet);
            captureRegion = (GoodVariable<Rectangle>)captureRegionGet;
            captureRectangle = captureRegion.Value;
        }
        private void FormPassthru_Load(object sender, EventArgs e)
        {
//            ClientSize = ((GoodVariable<Size>)StateStore.Store["MaximumImageDimensions"]).Value;
//            ((GoodVariable<Bitmap>)StateStore.Store["PassthruBitmap"]).ValueChanged += OnBitmapChanged;
//            GoodVariable<Size> ClientSize = new GoodVariable<Size>();
            //init(this, e);
            _passthruGraphics = CreateGraphics();
        }

        private void FormPassthru_MouseClick(object sender, MouseEventArgs e)
        {

            Size max = ClientSize;
            //((GoodVariable<Size>)StateStore.Store["MaximumImageDimensions"]).Value;

            if (!_shiftPressed && !_controlPressed)
            {
                int x = (e.X * max.Width / ClientSize.Width - captureRegion.Value.Width / 2);
                x = Math.Max(0, x);
                x = Math.Min(max.Width - captureRegion.Value.Width, x);
                int y = (e.Y * max.Height / ClientSize.Height - captureRegion.Value.Height / 2);
                y = Math.Max(0, y);
                y = Math.Min(max.Height - captureRegion.Value.Height, y);
                captureRegion.Value = new Rectangle(
                    x,
                    y,
                    captureRegion.Value.Width,
                    captureRegion.Value.Height);
            }
            else if (!_controlPressed)
            {
                int x = (e.X * max.Width / ClientSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (e.Y * max.Height / ClientSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);
                captureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    y);
            }
            else
            {
                int x = (e.X * max.Width / ClientSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (e.Y * max.Height / ClientSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);

                x = Math.Max(x, y);
                y = Math.Max(x, y);
                captureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    y);
            }
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("CaptureRegion", captureRegion);
            StateChanged(this, s);
        }

        private void FormPassthru_ResizeEnd(object sender, EventArgs e)
        {
            _passthruGraphics = CreateGraphics();
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("PassThruGraphics", _passthruGraphics);
            s.Sample.Add("FormPassThruSize", ClientSize);
            s.Sample.Add("PassThruClientRectangle", ClientRectangle);
            StateChanged(this, s);
        }


        // save the state of the shift key
        private void FormPassthru_KeyUpDown(object sender, KeyEventArgs e)
        {
            _shiftPressed = e.Shift;
            _controlPressed = e.Control;
        }

        bool _shiftPressed;
        bool _controlPressed;

        private void FormPassthru_Click(object sender, EventArgs e)
        {

        }
        public static Control MakeControl(GoodVariable<Bitmap> v)
        {
            IGoodControl c = null;
           // if (v is GoodVariable<Rectangle>)
                //c = new GoodRectangleControl();
            if (v is IGoodNumericVariable)
                c = new GoodNumericUpDown();
            //if (v is GoodVariable<string>)
                //c = new GoodTextBox();
            //if (v is GoodVariable<EventHandler>)
                //c = new GoodButton();
            if (v is GoodVariable<Bitmap>)
                c = new GoodPictureBox();

            c.GoodVariableBinding = (IGoodVariable)v;
            c.Initialize();
            return (Control)c;
        }

        public void OnBitmapChanged(object sender, SampleEventArgs sArgs)
        {
            Bitmap b = ((GoodVariable<Bitmap>)sArgs.Sample["PassthruBitmap"]).Value;
            //((GoodVariable<Bitmap>)StateStore.Store["PassthruBitmap"]).Value;
             /*if (goodPictureBox1.Controls.Count == 0)
                goodPictureBox1.GoodVariableBinding = (GoodVariable<Bitmap>)ptB;
              */  //goodPictureBox1.Controls.Add(MakeControl((GoodVariable<Bitmap>)ptB));
            //Graphics a = goodPictureBox1.CreateGraphics();
            
            /*a.DrawImage(
                b,
                goodPictureBox1.ClientRectangle,
                new Rectangle(0, 0, b.Width, b.Height),
                GraphicsUnit.Pixel);
            */
            
            _passthruGraphics.DrawImage(
                b,
                ClientRectangle,
                new Rectangle(0, 0, b.Width, b.Height),
                GraphicsUnit.Pixel);
            //*/
            Rectangle captureRectangle = captureRegion.Value;
            
            Rectangle scaledRectangle = new Rectangle(
                captureRectangle.X * ClientSize.Width / b.Width,
                captureRectangle.Y * ClientSize.Height / b.Height,
                captureRectangle.Width * ClientSize.Width / b.Width,
                captureRectangle.Height * ClientSize.Height / b.Height);
            

            _passthruGraphics.DrawRectangle(Pens.Red, scaledRectangle);
            
        }

    }
}