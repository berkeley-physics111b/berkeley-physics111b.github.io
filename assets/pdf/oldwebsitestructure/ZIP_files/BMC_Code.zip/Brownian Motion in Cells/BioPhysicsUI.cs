using System;
using System.Drawing;
using System.Windows.Forms;
using System.Reflection;
using GoodStuff;
using CameraDriver;

/// <summary>
/// Summary description for Class1
/// </summary>
namespace BrownianMotion {
//    public class BioPhysicsUI : IInitializable {
//        ThreadSafeQueue<Frame> _displayFrames;
//        ThreadSafeQueue<Frame> _renderedFrames;
//        StateStore s;
//        bool updateParticleTracks;
//        bool PerformStatistics;
//        DateTime StartCaptureTime;

//        GoodTimer sampleTimer;
//       // Camera camera;
//        GoodPanel captureControlPanel;
//        GoodPictureBox capturePictureBox;
//        GoodPictureBox PostProcessingPictureBox;
//        GoodVariable<Rectangle> captureRegion;
//        Rectangle captureRectangle;
//        CameraParameter paramGain;
//        GoodRectangleControl captureRegionControl;
//        GoodNumericUpDown samplePeriodUpDown;
//        GoodNumericUpDown paramGainUpDown;
//        GoodNumericUpDown blobFinderUpDown;
//        GoodGroupBox movieControls;
//        GoodGroupBox movieCaptureControls;
//        GoodButton startCaptureButton;
//        GoodButton stopCaptureButton;
//        GoodButton updateTracksButton;
//        GoodButton performStatisticsButton;

//        GoodTextBox movieNameTextBox;
//        GoodTextBox DiffusionCoefficientTextBox;
//        GoodNumericUpDown framesToCaptureUpDown;
//        GoodNumericUpDown framesCapturedUpDown;
//        GoodNumericUpDown blobThresholdUpDown;
//        GoodProgressBar progressBar;
//        public FormCaptureControl formCaptureControl;
//        public FormPassthru formPassthru;
//        GoodTextBox movieOutNameTextBox;
//        GoodTextBox movieInNameTextBox;
//        GoodVariable<string> outputMovieNameVar;
//        GoodVariable<string> inputMovieNameVar;
//        GoodProperty<string> movieNameText;
//        GoodProperty<string> movieElement;
//        GoodProperty<string> movieOutputDirectory;
//        GoodProperty<string> DiffusionCoefficientText;
//        GoodVariable<UInt32> framesToCapture;
//        GoodVariable<UInt32> framesCaptured;
//        GoodVariable<UInt32> blobThreshold;
//        GoodVariable<Bitmap> captureBitmap;
//        GoodNumericVariable<Decimal> samplePeriod;
//        GoodVariable<SampleEventHandler> startCaptureGoodVar;
//        GoodVariable<SampleEventHandler> stopCaptureGoodVar;
//        GoodVariable<SampleEventHandler> startSelf;
//        GoodVariable<SampleEventHandler> stopSelf;
//        GoodVariable<SampleEventHandler> updateTracks;
//        GoodVariable<SampleEventHandler> performStatistics;
///*        private event EventHandler startCapture;
//        private event EventHandler stopCapture;
//        private event EventHandler initAll;
//        private event regionChangedEventHandler regionChanged;*/

//// these events trigger the frameGrabber
//        public event SampleEventHandler startCapture;
//        public event SampleEventHandler stopCapture;
//        public event SampleEventHandler DoStatistics;
//        // this event initializes all of the moduels
//        public event SampleEventHandler initAll;
//        public event SampleEventHandler initCamera;
//// this event notifies any interested modules that the captureRegion has changed
//        public event SampleEventHandler regionChanged;
//        public event SampleEventHandler UIStateChanged;
//        public event SampleEventHandler startSelfEvent;
//        public event SampleEventHandler stopSelfEvent;
//        public event SampleEventHandler updateTracksEvent;
//        public event SampleEventHandler performStatisticsEvent;
       
//        private void startSelfSignalHandler(object sender, EventArgs eventArgs)
//        {
//            StartCaptureTime = DateTime.Now;

//            SampleEventArgs S = new SampleEventArgs();
          
//            startCapture(this, S);
//        }
//        private void stopSelfSignalHandler(object sender, EventArgs eventArgs)
//        {
////            Frame f = new Frame();
//            SampleEventArgs S = new SampleEventArgs();
            
//            S.Sample.Add("ParamGain", paramGain);
//            S.Sample.Add("FramesCaptured", framesCaptured);
//            S.Sample.Add("FramesToCapture", framesToCapture);
//            S.Sample.Add("CaptureBitmap", captureBitmap);
//            S.Sample.Add("SampleTimer", sampleTimer);
//            S.Sample.Add("MovieElement", movieElement);
//            S.Sample.Add("MovieOutputDirectory", movieOutputDirectory);
//            S.Sample.Add("BlobThreshold", blobThreshold);
//            S.Sample.Add("CaptureRegion", captureRegion);
//            //GenericEventArgs eArgs = new GenericEventArgs(f);
//            stopCapture(this, S);
//        }
//        private void updateTracksSignalHandler(object sender, EventArgs eventargs)
//        {
//            updateParticleTracks = !updateParticleTracks;
//            SampleEventArgs s = new SampleEventArgs();
//            s.Sample.Add("UpdateParticleTracks", updateParticleTracks);
//            UIStateChanged(this, s);
//        }
//        private void performLogicSignalHandler(object sender, EventArgs eventargs)
//        {
//            PerformStatistics = true;
//        }
         

         
//        private void displayFrameReady(object sender, SampleEventArgs sArgs)
//        {
//            formPassthru.OnBitmapChanged(sender, sArgs);
//        }


//        public GoodVariable<UInt32> FramesCaptured {
//            get { return framesCaptured; }
//            set {
//                framesCaptured = value;
//                framesCapturedUpDown.GoodVariableBinding = framesCaptured;
//            }
//        }

//        public GoodVariable<UInt32> FramesToCapture {
//            get { return framesToCapture; }
//            set {
//                framesToCapture = value;
//                framesToCaptureUpDown.GoodVariableBinding = framesToCapture;
//            }
//        }
//        public GoodVariable<Bitmap> CaptureBitmap {
//            get { return captureBitmap; }
//            set {
//                captureBitmap = value;
//                capturePictureBox.GoodVariableBinding = captureBitmap;
//            }
//        }

//        public GoodVariable<Rectangle> CaptureRegion {
//            get {return captureRegion;}
//            set {
//                captureRegion = value;
//                captureRegionControl.GoodVariableBinding = captureRegion;
//            }
//        }

//        public GoodNumericVariable<Decimal> SamplePeriod {
//            get {return samplePeriod;}
//            set {
//                samplePeriod = value;
//                samplePeriodUpDown.GoodVariableBinding = samplePeriod;
//            }
//        }

//        public GoodVariable<UInt32> BlobThreshold {
//            get {return blobThreshold;}
//            set {
//                blobThreshold = value;
//                blobThresholdUpDown.GoodVariableBinding = BlobThreshold;
//            }
//        }

//        public CameraParameter ParamGain {
//            get {return paramGain; }
//            set {
//                paramGain = value;
//                paramGainUpDown.GoodVariableBinding = paramGain;
//            }
//        }

//        public event SampleEventHandler RegionChanged {
//            add { regionChanged += value; }
//            remove { regionChanged -= value; }
//        }

///*        public event GoodVariable<EventHandler> StartCapture {
//            add { 
//                GoodVariable<EventHandler> inVar = value;
//                startCapture += inVar.Value;
//                startCaptureButton.GoodVariableBinding = startCapture;}               
//            remove {
//                GoodVariable<EventHandler> inVar = value;
//                startCapture -= inVar.Value;
//                startCaptureButton.GoodVariableBinding = startCapture;
//            }
//        }
//        */
//        /*public event GoodVariable<EventHandler> StopCapture {
//            add {
//                GoodVariable<EventHandler> inVar = value;
//                stopCapture += inVar.Value;
//                stopCaptureButton.GoodVariableBinding = stopCapture;}               
//            remove {
//                GoodVariable<EventHandler> inVar = value;
//                stopCapture -= inVar.Value;
//                stopCaptureButton.GoodVariableBinding = stopCapture;
//            }
//        }
//        */
//        public event SampleEventHandler InitAll {
//            add { initAll += value; }
//            remove { initAll -= value; }
//        }

//        public void renderedTracksReady(object sender, SampleEventArgs sArgs) {

//            if (PerformStatistics)
//            {
//                //double PixelToMeterConversion = 10e-6
//                //gArgs.Frame._objects.Add("PixelToMeterConversion", PixelToMeterConversion);
//                sArgs.Sample.Add("StartTime", StartCaptureTime);
//                sArgs.Sample.Add("EndTime", DateTime.Now);
//                DoStatistics(this, sArgs);
                
//                PerformStatistics = false;
//            }
//        }
//        public void StatisticsReady(object sender, SampleEventArgs sArgs)
//        {
//            double DiffusionCoefficient = (double)sArgs.Sample["DiffusionCoefficient"];

//            /*DiffusionCoefficientText.Value = DiffusionCoefficient.ToString();
//            GoodProperty<string> Blahstring = new GoodProperty<string>();
//            Blahstring.Value = "blah";
//            DiffusionCoefficientTextBox.UpdateTextKey = Blahstring;
//            SampleEventArgs sargs = new SampleEventArgs();
//            sargs.Sample.Add("blah", DiffusionCoefficientText);
//            DiffusionCoefficientTextBox.UpdateText(this, sargs);
//            //DiffusionCoefficientTextBox.Text = DiffusionCoefficientText;
//            //DiffusionCoefficientTextBox.UpdateText(this, new SampleEventArgs());
//             */
//        }



//        public BioPhysicsUI() {

//            //ThreadSafeQueue<Frame> _displayFrames = new ThreadSafeQueue<Frame>(20);
//            //ThreadSafeQueue<Frame> _renderedFrames = new ThreadSafeQueue<Frame>(20);
//            StateStore.GetStore();
//            outputMovieNameVar = new GoodVariable<string>();
//            inputMovieNameVar = new GoodVariable<string>();
//            movieNameText = new GoodProperty<string>();
//            movieElement = new GoodProperty<string>();
//            movieOutputDirectory = new GoodProperty<string>();
//            captureRectangle = new Rectangle(0,0,200,200);
//            startSelfEvent += startSelfSignalHandler;
//            stopSelfEvent += stopSelfSignalHandler;
//            updateTracksEvent += updateTracksSignalHandler;
//            performStatisticsEvent += performLogicSignalHandler;

            

//            // panel for capture control window
//            captureControlPanel = new GoodPanel();
//            captureControlPanel.Margin = new Padding(7);
//            captureControlPanel.Padding = new Padding(5);

//            // blob threshold to be bound to a numericUpDown
//            blobThreshold = new GoodVariable<UInt32>();
//            blobThreshold.Name = "BlobThreshold";
//            blobThreshold.DisplayName = "Threshold";
//            BlobThreshold.Value = 128;

//            // capture preview 
//            capturePictureBox = new GoodPictureBox();
//            capturePictureBox.Size = new Size(250 + capturePictureBox.Margin.Horizontal, 250 + capturePictureBox.Margin.Vertical);
//            capturePictureBox.GoodVariableBinding = captureBitmap;
//            captureControlPanel.Add(capturePictureBox);
//            // capture region will be bound to this control
//            captureRegionControl = new GoodRectangleControl();

//            //PostProcessing Preview
//            PostProcessingPictureBox = new GoodPictureBox();
//            PostProcessingPictureBox.Size = new Size(250 + PostProcessingPictureBox.Margin.Horizontal, 250 + PostProcessingPictureBox.Margin.Vertical);
//            PostProcessingPictureBox.GoodVariableBinding = captureBitmap;
//            captureControlPanel.Add(PostProcessingPictureBox);
            

//            // capture region             
//            captureRegion = new GoodVariable<Rectangle>();
//            captureRegion.Value = captureRectangle;
//            captureRegion.Name = "CaptureRegion";
//            captureRegion.DisplayName = "Capture Region";
//            captureRegionControl.GoodVariableBinding = captureRegion;

         
            
//            // samplePeriod will be bound to this control
//            sampleTimer = new GoodTimer();
//            sampleTimer.Name = "SampleTimer";
//            sampleTimer.DisplayName = "Sample Period (ms)";
//            sampleTimer.Value = 50;
//            samplePeriodUpDown = new GoodNumericUpDown();
//            samplePeriodUpDown.GoodVariableBinding = sampleTimer;
//            // paramGain will be bound to this control
//            paramGainUpDown = new GoodNumericUpDown();
//            paramGainUpDown.GoodVariableBinding = paramGain;
//            // blobThreshold will be attached to this control
//            blobFinderUpDown = new GoodNumericUpDown();
//            blobFinderUpDown.GoodVariableBinding = BlobThreshold;
//            //told you so

//            // FramesToCapture will be bound to this control
//            movieControls = new GoodGroupBox(); 
//            movieControls.Text = "Movie Capture Controls";

//            // attach events to these
//            startSelf = new GoodVariable<SampleEventHandler>();
//            startSelf.Value = startSelfEvent;
//            startCaptureButton = new GoodButton();
//            startCaptureButton.GoodVariableBinding = startSelf;
//            //GoodProperty<string> tempstring1 = new GoodProperty<string>();
//            //tempstring1.Value = "Start!";
//            //startCaptureButton.Text.Set("Start!");

//            stopCaptureButton = new GoodButton();
//            stopSelf = new GoodVariable<SampleEventHandler>();
//            stopSelf.Value = stopSelfEvent;
//            stopCaptureButton.GoodVariableBinding = stopSelf;
//            //stopCaptureButton.Text.Set("Stop!");

//            updateTracksButton = new GoodButton();
//            updateTracks = new GoodVariable<SampleEventHandler>();
//            updateTracks.Value = updateTracksEvent;
//            updateTracksButton.GoodVariableBinding = updateTracks;

//            performStatisticsButton = new GoodButton();
//            performStatistics = new GoodVariable<SampleEventHandler>();
//            performStatistics.Value = performStatisticsEvent;
//            performStatisticsButton.GoodVariableBinding = performStatistics;

//            DiffusionCoefficientTextBox = new GoodTextBox();
//            DiffusionCoefficientText = new GoodProperty<string>();
//            DiffusionCoefficientTextBox.pBind(DiffusionCoefficientText);

//            movieControls.Add(startCaptureButton);
//            movieControls.Add(stopCaptureButton);
//            movieControls.Add(updateTracksButton);
//            movieControls.Add(performStatisticsButton);
//            movieControls.Add(DiffusionCoefficientTextBox);
//            captureControlPanel.Add(movieControls);


//            // null text  box for ProgressBar
//            movieOutNameTextBox = new GoodTextBox();
//            outputMovieNameVar = new GoodProperty<string>();
//            outputMovieNameVar.Value = "Output Movie Name";
//            movieOutNameTextBox.GoodVariableBinding = outputMovieNameVar;

//            movieInNameTextBox = new GoodTextBox();
//            inputMovieNameVar = new GoodProperty<string>();
//            inputMovieNameVar.Value = "Input Movie Name";
//            movieInNameTextBox.GoodVariableBinding = inputMovieNameVar;



//            // for ProgressBar
//            framesToCaptureUpDown = new GoodNumericUpDown();
//            framesCapturedUpDown = new GoodNumericUpDown();
//            // these are the goodvars attached to the above controls
//            framesToCapture = new GoodVariable<UInt32>();
//            framesCaptured = new GoodVariable<UInt32>();
//            framesToCaptureUpDown.GoodVariableBinding = framesToCapture;
//            framesCapturedUpDown.GoodVariableBinding = framesCaptured;
            
//            //the progressbar
//            progressBar = new GoodProgressBar();
//            progressBar.Text = "Movie Capture Progress";
        
//            //the two main forms. CaptureControl and passThru
//            formCaptureControl = new FormCaptureControl();
//            formCaptureControl.StartPosition = FormStartPosition.Manual;
//            formCaptureControl.DesktopLocation = new Point(10, 10);
            
//            formCaptureControl.PostProcessingPictureBox = PostProcessingPictureBox;
//            formCaptureControl.PostProcessinggraphics = PostProcessingPictureBox.CreateGraphics();

//            formCaptureControl.capturePictureBox = capturePictureBox;
//            formCaptureControl.graphics = capturePictureBox.CreateGraphics();

//            captureControlPanel.Location = new Point(0, 0);
//            capturePictureBox.GoodVariableBinding = CaptureBitmap;
//            formCaptureControl.ClientSize = captureControlPanel.Size;
//            formPassthru = new FormPassthru();
            
            
//            movieNameTextBox = new GoodTextBox();
//            movieNameText = new GoodProperty<string>();


//        }
//        public Point[][] ConstructParticleTracks(SampleEventArgs s)
//        {
//            Particle[] particles = (Particle[])s.Sample["Particles"];
//            GoodPictureBox captureBox = (GoodPictureBox)s.Sample["CapturePictureBox"];
//            byte[,] rawdata = (byte[,])s.Sample["CaptureRegionArray"];
//            //Graphics activegraphics = (Graphics)s.Sample["CaptureGraphics"];
//            Point[][] particlepaths = new Point[particles.Length][];
//            Particle[] currentpath;
//            float Xconversion = /*captureBox.DisplayRectangle.Width*/ capturePictureBox.Size.Height / (float)rawdata.GetLength(1);
//            float Yconversion = /*captureBox.DisplayRectangle.Height*/capturePictureBox.Size.Width / (float)rawdata.GetLength(0);

//            for (int i = 0; i < particles.Length; i++)
//            {
//                currentpath = particles[i].ToArray();
//                particlepaths[i] = new Point[currentpath.Length];
//                if (currentpath.Length > 1)
//                {
//                    for (int j = 0; j < currentpath.Length; j++)
//                    {
//                        particlepaths[i][j] = new Point((int)(currentpath[j].y * Yconversion), (int)(currentpath[j].x *Xconversion));
//                    }
//                    //activegraphics.DrawLines(System.Drawing.Pens.White, particlepaths[i]);
//                }
//            }
//            return particlepaths;
//        }

//        public void UIUpdate(object sender, SampleEventArgs sArgs)
//        {
//            //FrameGrabber fGrabber= new FrameGrabber();
//            Type senderType = sender.GetType();
            
////            Type FrameGrabberType = fGrabber.GetType();
//            //if (senderType.Equals(fGrabber))
//            if (senderType.Name == "FrameGrabber")
//            {
//                if (sArgs.Sample.ContainsKey("SampleTimer"))
//                {
//                    object sampleTimerGet;
//                    sArgs.Sample.TryGetValue("SampleTimer", out sampleTimerGet);
//                    sampleTimer = (GoodTimer)sampleTimerGet;
//                }
//                if (sArgs.Sample.ContainsKey("MaximumImageDimensions"))
//                    formPassthru.ClientSize = ((GoodVariable<Size>)sArgs.Sample["MaximumImageDimensions"]).Value;
//            }
           
//        }
  
//        public void Initialize() {
            

//            GoodVariableBase [] pBarVars = new GoodVariableBase[3];
//            movieNameTextBox.GoodVariableBinding = movieNameText;
            
//            pBarVars[0] = framesCaptured;
//            pBarVars[1] = movieNameText;
//            pBarVars[2] = framesToCapture;
            
//            progressBar.BindTo(pBarVars);
//            progressBar.Initialize();
//            progressBar.Control.Size = new Size(movieControls.Width - movieControls.Margin.Horizontal, 40);
//            movieControls.Add(progressBar);

//            formPassthru.StateChanged += UIStateChanged;

//            formCaptureControl.Controls.Add(captureControlPanel);

////            captureControlPanel.Add(capturePictureBox);
//            captureControlPanel.Add(samplePeriodUpDown);
//            captureControlPanel.Add(paramGainUpDown);

////            GoodVariable<string> movieOutputDirectory = (GoodVariable<string>)StateStore.Store["MovieOutputDirectory"];
//            movieOutputDirectory.Value = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + @"\BIO Lab Work\Movies";
// //           GoodVariable<string> movieElement = (GoodVariable<string>)StateStore.Store["MovieFrameElement"];            
//            movieElement.Value = "Bitmap 8BppMono";
            
//            SampleEventArgs sArgs = new SampleEventArgs();
//            Graphics passthrugraphics = formPassthru.CreateGraphics();
//            GoodPictureBox CapturePictureBox = capturePictureBox;
//            Graphics CaptureGraphics = formCaptureControl.graphics;
//            sArgs.Sample.Add("PassThruFormGraphics", passthrugraphics);
//            sArgs.Sample.Add("PassThruFormSize", formPassthru.ClientSize);
//            sArgs.Sample.Add("PassThruClientRectangle", formPassthru.ClientRectangle);
//            sArgs.Sample.Add("CaptureGraphics", CaptureGraphics); 
//            sArgs.Sample.Add("CapturePictureBox", capturePictureBox);
//            sArgs.Sample.Add("PostProcessingPictureBox", PostProcessingPictureBox);
//            sArgs.Sample.Add("ParamGain", paramGain);
//            sArgs.Sample.Add("FramesCaptured", framesCaptured);
//            sArgs.Sample.Add("FramesT4oCapture", framesToCapture);
//            sArgs.Sample.Add("CaptureBitmap", captureBitmap);
//            sArgs.Sample.Add("SampleTimer", sampleTimer);
//            sArgs.Sample.Add("MovieElement", movieElement);
//            sArgs.Sample.Add("MovieOutputDirectory", movieOutputDirectory);
//            sArgs.Sample.Add("BlobThreshold", blobThreshold);
//            sArgs.Sample.Add("CaptureRegion", captureRegion);
//            //f._objects.Add("Camera", camera);
            
//         //   initAll(this, sArgs);
//            formCaptureControl.Show();
//            formPassthru.Show(formCaptureControl);
//            formPassthru.init(this, sArgs);
//            InitializeFromUI();
//          //  Application.Run(formPassthru);  
//        }
//        public void InitializeFromUI()
//        {
//            SampleEventArgs sArgs = new SampleEventArgs();
//            //Graphics passthrugraphics = formPassthru.CreateGraphics();
//            GoodPictureBox CapturePictureBox = capturePictureBox;
//            Graphics CaptureGraphics = formCaptureControl.graphics;
//            //sArgs.Sample.Add("PassThruFormGraphics", passthrugraphics);
//            sArgs.Sample.Add("PassThruFormSize", formPassthru.ClientSize);
//            sArgs.Sample.Add("PassThruClientRectangle", formPassthru.ClientRectangle);
//            sArgs.Sample.Add("CaptureGraphics", CaptureGraphics);
//            sArgs.Sample.Add("CapturePictureBox", capturePictureBox);
//            sArgs.Sample.Add("PostProcessingPictureBox", PostProcessingPictureBox);
//            UIStateChanged(this, sArgs);
//        }

//        public void Start()
//        {
//            Application.Run(formCaptureControl);
//        }

//    }
}  