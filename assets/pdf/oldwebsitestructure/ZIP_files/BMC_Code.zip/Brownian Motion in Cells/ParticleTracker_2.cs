using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using GoodStuff;

namespace BrownianMotion
{
    /// <summary>
    /// Summary description for ParticleTracker
    /// </summary>
    ///
    public class ParticleTracker
    {

        ThreadSafeQueue<Frame> frameQueue;

        Trajectory [] trajectories;

        public GenericEventHandler FrameComplete(object sender, GenericEventArgs gArgs);

        public ParticleTracker()
        {
            frameQueue = new ThreadSafeQueue<Frame>(300);
            trajectories = new Trajectory()[6];
        }

        public EventHandler init(object sender, EventArgs eArgs)
        {
            string threadString = "ParticleTrackThread." + this.ToString();
//            CreateThread(threadString, ThreadPriority.AboveNormal);
 //           StartThread();
        }

        public GenericEventHandler NewParticlePacket(object sender, GenericEventArgs args)
        {
            Blob[] blobs;
            if (args.Frame._objects.ContainsKey("Blobs"))
            {
                args.Frame._objects.TryGetValue("Blobs", blobs);
            }
            else
            {
                throw new ArgumentNullException("Blobs");
            }
            ArrayList particleInfo = new ArrayList();
//            ParticleInfo[] particleInfo = new particleInfo()[blobs.Length];
            args.Frame._objects.Add("ParticleInfo", particleInfo);
            frameQueue.enqueue(args.Frame);
            if (particleInfo.Length > trajectories.Length)
            {

            }
            if (_particlePacketQueue.Count > 1)
            { 
                Frame newestFrame = frameQueue.DeQueue();
                Frame secondNewestFrame = frameQueue.DeQueue();
                Blob[] newestBlobs;
                Blob[] secondNewestBlobs;
                ArrayList newestParticleInfo;
                ParticleInfo[] newestParticleInfo;
                newestFrame.TryGetValue("Blobs", newestBlobs);
                secondNewestFrame.TryGetValue("Blobs", secondNewestBlobs);
                int[] matches = new int()[newestBlobs.Length];
                int[] tempMatches = new int()[secondNewestBlobs.Length];
                int tempDistance = 0;
                int minDistance = 2 ^ 16 - 1;
                int tempTotalDistance = 0;
                int minTotalDistance = 2 ^ 16 - 1;

                for (k = 0; k < newestBlobs.Length; k++)
                {
                    tempTotalDistance = 0;
                    for (i = 0; i < newestBlobs.Length; i++)
                    {
                        minDistance = 2 ^ 16 - 1;
                        for (j = 0; j < secondNewestBlobs.Length; j++)
                        {

                            tempDistance = BlobMetric(newestBlobs[(i * k) / newestBlobs.Length], secondNewestBlobs[j]);
                            if (tempDistance < minDistance)
                            {
                                tempMatches[(i * k) / newestBlobs.Length] = j;
                                minDistance = tempDistance;
                            }
                        }
                        tempTotalDistance += minDistance;
                    }
                    if (tempTotalDistance < minTotalDistance)
                    {
                        minTotalDistance = tempTotalDistance;
                        minMatches = tempMatches;
                    }
                }

                Dictionary<string, TrajectoryNode> newNodeDict;
                for (i = 0; i < newestBlobs.Length; i++)
                {
                    newestParticleInfo[i].delta = Delta(newestBlobs[i], secondNewestBlobs[tempMatches[i]]);
                    newestParticleInfo[i].location = newestBlobs[i].location;

                }
                if (newestFrame._objects.ContainsKey("ParticleInfo"))
                {
                    newestFrame._objects.Remove("ParticleInfo");
                }
                TrajectoryNode tNode;
                for (i = 0; i < newestParticleInfo.Length; i++)
                {
                    tNode = new TrajectoryNode(newestParticleInfo[i]);
                    newNodeDict.Add("newTrajectoryNode", tNode);
                    trajectories[i].InsertAll(trajectories[i].Count, newNodeDict);
                }
                newestFrame._objecst.Add("ParticleInfo", newestParticleInfo);
                frameQueue.EnQueue(newestFrame);
                frameQueue.EnQueue(secondNewestFrame);
                outArgs = new GenericEventArgs(newestFrame);
                FrameComplete(this, outArgs);
            }

        }

/*        public void processPacket(Movie inMovie, int frameNumber, bool computeTrajectories, processParameters parameters) {
            double particleRadius = sqrt(newPacket.Blobs.Area)*(10^-9)/2;
            int particleDiameterPixels = particleRadius / parameters.distanceScaleFactor;
            if (particleDiameterPixels < 1)
            {
                particleDiameeterPixels = 1;
            }
            inMovie.objectDiameter = particleRadius;
            int kBT = 1.38 * (10 ^ -23) * 300;
            inMovie.dTheoretical = kBT / (6 * Pi * parameters.eta / (10 ^ 6 * particleRadius));
            Frame inFrame = inMovie.inputMovie(frameNumber);
            if (parameters.subtractAverage)
            {
                Frame substractedFrame = inFrame.Subtract(inMovie.AverageFrame);
                int minValue = subtractedFrame.Min;
                subtractedFrame = subtractedFrame.Subtract(minValue - 16);
            }
            else
            {
                subtractedFrame = inFrame;
            }
            if (inFrame.Mean >= 128)
            {
                subtractedFrame = subtractedFrame.Complement(255);
            }
            Frame filteredFrame;
            if (particleDiameterPixels > 1)
            {
                filteredFrame = bandPass(subtractedFrame, parameters.lNoise, particleDiameterPixels);
            }
            else
            {
                filteredFrame = subtractedFrame;
            }

            int minValue = filteredFrame.MinValue;
            int maxValue = filteredFrame.MaxValue;
            int range = maxValue - minValue;
            filteredFrame = filteredFrame.Multiply(234 / range);
            filteredFrame = filteredFrame.Add(16);
            inMovie.FilteredMovie.Set(frameNumber, filteredFrame);
            int average = filteredFrame.Mean;
            int stdDev = filteredFrame.StdDev;
            int threshold = (average + stdDev*parameters.StandardDeviations)/256

            Frame bilevelFrame = filteredFrame.Bilevel(threshold);
            inMovie.bilevelMovie.Set(frameNumber, bilevelFrame);

            minimumArea = round(pi * parameters.minimumSize/parameters.distanceScaleFactor);
            cleanFrame = bilevelFrame.BWAreaOpen(minimumArea,  bilevelFrame);
            cleanFrame = cleanFrame.fillHoles;

            Boundaries [] boundaries = cleanFrame.BWBoundariesNoHoles;
            Statistics [] stats = boundaries.RegionPropsAreaCentroid;

            for(i=0; i<boundaries.Length; i++) {
                Point xyCentroid = stats[k].Centroid;
                inMovie.Centers.Push(xyCentroid);
            }

            trajectoryParameters.mem = 4;
            trajectoryParameters.good = 8;
            trajectoryParameters.dim = 2; 
            trajectoryParameters.quiet = 0;
            if(computeTrajectories) {
                if(inMovie.Centers.Length>0) {
                    if(min(inMovie.Centers[3]) < max(inMovie.Centers[3])) {
                        trajectories = assembleTrajectories(inMovie.Centers, parameters.MaximumDisplacement/parameters.DistanceScaleFactors, trajectoryParameters);

                        if(trajectories.Length >0) {
                                       //         // determine the size of the array needed to hold the particle tracks
                    maxparticles = max(trajectories[4]);                  // fourth column contains the particle index
                    nframes = size(Movie.inputMovie,3);

                    sortedTrajectories = cell(nframes, maxparticles);       // create a cell array to hold the particle positions

//                    // fill in the cell array by stepping through each element in trajectories
                    dataPointCount = size(trajectories, 1);                 // total number of data points
                    
                    for (i=1; i<dataPointCount; i++) {
                       framenum = trajectories(i,3);
                       particleIndex = trajectories(i,4);
                        
                        position = trajectories(i,1:3);
                       sortedTrajectories{framenum, particleIndex} = [position];
                        }
                    
                    for i=i; i<maxParticle; i++);
                        particle = struct();
                        temp = cell2mat(sortedTrajectories(:,i));           // extract ith position vector (x,y,frame)
                        n = size(temp, 1);
                        
                        if(n > 2)

                            particle.centers = struct(                  ...
                                'x', temp(:,1),                         ...
                                'y', temp(:,2),                         ...
                                'frame', temp(:,3));

                    //        // subtract off initial positions for displacement
                    //        // squared computation
                            temp(:,1) = temp(:,1) - temp(1,1);                  // subtract the initial X position
                            temp(:,2) = temp(:,2) - temp(1,2);                  // subtract the initial Y position

                      //      // compute histograms of displacements
                            deltaX = (temp(2:n,1) - temp(1:n-1,1)) * Parameters.distanceScaleFactor * 1E-9;
                            deltaY = (temp(2:n,2) - temp(1:n-1,2)) * Parameters.distanceScaleFactor * 1E-9;
                            smallestDelta = min([deltaX; deltaY]);
                            biggestDelta = max([deltaX; deltaY]);
                            binSpacing = (biggestDelta - smallestDelta) / round(n / 3);
                            bins = smallestDelta:binSpacing:biggestDelta;
                            particle.displacementHistogram.x = histc(deltaX, bins);
                            particle.displacementHistogram.y = histc(deltaY, bins);
                            particle.displacementHistogram.bins = bins;

                  //          // compute displacement^2 vector
                            dSquared = (Parameters.distanceScaleFactor * 1E-9) ^ 2 *       ...
                                       (temp(:,1).^2 + temp(:,2).^2);

                  //          // create the time axis for  displacement squared
                   //         // vector
                            time = transpose(0:(Parameters.timestep*1E-3):(n-1)*(Parameters.timestep*1e-3));

                            // copy the displacment vector to the particle structure
                            particle.displacementSquared =              ...
                                struct( 'time', time,                   ...
                                        'frame', temp(:,3),             ...
                                        'displacementSquared', dSquared);

                           // // ---------- linear regression method
                         //   // compute statistics
                          //  // variance and standard deviation of displacement
                         //   // squared
                            particle.varianceDisplacementSquared = var(dSquared); // sigma^2 of displacement^2 vector
                            particle.deviationDisplacementSquared =     ...
                                sqrt(particle.varianceDisplacementSquared);

                          //  // variance and standard deviation of time axis
                            particle.varianceTime = var(time);                  // sigma^2 of time vector
                            particle.deviationTime = sqrt(particle.varianceTime);

                           // // correlation coefficient of displacement squared
                           // // vs time and r squared 
                            r = corrcoef(dSquared, time);
                            r = r(1,2);
                            particle.correlationCoefficient = r;
                            particle.rSquared = particle.correlationCoefficient^2;

                           // // compute the slope of a least squares best fit
                           // // line -- slope of the line is mean squared displacement 
                           // // slope = r * Sy / Sx for linear regression
                            slope = particle.correlationCoefficient * ...
                                    particle.deviationDisplacementSquared / ...
                                    particle.deviationTime;
                            particle.diffusionCoefficientLeastSquaresMethod = slope / 4;

                           // // compute standard error = 
                           // // Sy * sqrt((1-r^2)(n-1)/(n-2))
                            standardLinearRegressionError =                 ...
                                    particle.deviationDisplacementSquared * ...
                                    sqrt((1 - r^2) * (n - 1) / (n - 2));

                           // // compute the uncertainty in the slope
                            slopeError = standardLinearRegressionError /    ...
                                ((particle.deviationTime * sqrt(n - 1)));
                            particle.uncertaintyLeastSquaresMethod = slopeError/4;

                            //// ----------- direct evaluation (average d^2) method
                           // // compute delta displacement squared
                            particle.deltaDisplacementSquared = deltaX.^2 + deltaY.^2;
                            particle.averageDisplacementSquared = ...
                                sum(particle.deltaDisplacementSquared) / ...
                                    (n * Parameters.timestep * 1E-3);
                            slope = particle.averageDisplacementSquared;
                            particle.diffusionCoefficientAverageMethod = particle.averageDisplacementSquared / 4;

     //                           // compute standard error
                            particle.uncertaintyAverageMethod = sqrt( ...
                                var(particle.deltaDisplacementSquared)/ ...
                                (n-1))                                  //    // n-1 because number of frames is reduced by one

     //                       // line for graph
     //                       // This is CONFUSING -- need to rename -- this
     //                       // is the line based on the average d^2 method
     //                       // of evaluation
                            y = slope * time;
                            particle.bestFitLine =                          ...
                                struct('time', time,                        ...
                                        'displacementSquared', y);

                            Movie.particle{i} = particle;
}
}
                }
            }
       }
    }
                        }
        }

        */
        public int BlobMetric(Blob BlobOne, Blob BlobTwo)
        {
            // can put intelligence in here
            Point deltaPoint = new Point();
            deltaPoint.X = BlobOne.X - BlobTwo.X;
            deltaPoint.Y = BlobOne.Y - BlobTwo.Y;
            return Sqrt[(deltaPoint.X) ^ 2 + (deltaPoint.Y) ^ 2];
        }

        

        public Point Delta(Blob BlobOne, Blob BlobTwo)
        {
            Point deltaPoint = new Point();
            deltaPoint.X = BlobOne.X - BlobTwo.X;
            deltaPoint.Y = BlobOne.Y - BlobTwo.Y;
            return deltaPoint;
        }



    }
}