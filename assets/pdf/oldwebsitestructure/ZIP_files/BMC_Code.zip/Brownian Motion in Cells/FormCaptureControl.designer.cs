using GoodStuff;
using CameraDriver;
using System.Drawing;
namespace BrownianMotion
{
    partial class FormCaptureControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        public Graphics graphics;
        public GoodPictureBox capturePictureBox;
        public Graphics PostProcessinggraphics;
        public GoodPictureBox PostProcessingPictureBox;
        
        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.folderBrowserDialogChooseMovieFolder = new System.Windows.Forms.FolderBrowserDialog();
            this.groupBoxCapturePreview = new GoodStuff.GoodControlGroupBox();
            this.SuspendLayout();
            // 
            // groupBoxCapturePreview
            // 
            //this.groupBoxCapturePreview.GoodVariableBinding = null;
            this.groupBoxCapturePreview.Location = new System.Drawing.Point(353, 336);
            this.groupBoxCapturePreview.Name = "groupBoxCapturePreview";
            this.groupBoxCapturePreview.Size = new System.Drawing.Size(371, 346);
            this.groupBoxCapturePreview.TabIndex = 0;
            this.groupBoxCapturePreview.TabStop = false;
            this.groupBoxCapturePreview.Text = "goodControlGroupBox1";
            // 
            // FormCaptureControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(604, 489);
            this.Controls.Add(this.groupBoxCapturePreview);
            this.Name = "FormCaptureControl";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Video Capture Control";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormCaptureControl_FormClosing);
            this.ResumeLayout(false);

        }
        public void OnBitmapChanged(object sender, SampleEventArgs sArgs)
        {
            //GoodPictureBox capturePictureBox = (GoodPictureBox)gArgs.Frame._objects["CapturePictureBox"];
            //Graphics graphics = capturePictureBox.CreateGraphics();
            Point[][] ParticleTracks = null;
            Bitmap CaptureBitmap = ((Bitmap)sArgs.Sample["Capture 24BppRgb"]);
            Bitmap PostProcessingBitmap = ((Bitmap)sArgs.Sample["PostProcessedBitmap"]);
            Particle[] Particles = (Particle[])sArgs.Sample["Particles"];
            graphics.DrawImage(
                CaptureBitmap,
                capturePictureBox.ClientRectangle,
                new Rectangle(0, 0, CaptureBitmap.Width, CaptureBitmap.Height),
                GraphicsUnit.Pixel);
            PostProcessinggraphics.DrawImage(
                PostProcessingBitmap,
                PostProcessingPictureBox.ClientRectangle,
                new Rectangle(0, 0, PostProcessingBitmap.Width, PostProcessingBitmap.Height),
                GraphicsUnit.Pixel);

            if (sArgs.Sample.ContainsKey("ParticleTracks"))
            {
                ParticleTracks = (Point[][])sArgs.Sample["ParticleTracks"]; //update new tracks
            }

            if (ParticleTracks != null)
            {
                foreach (Point[] P in ParticleTracks)
                {
                    if (P.Length > 1)
                    {
                        graphics.DrawLines(Pens.White, P);
                    }
                }
            }
            int delta = 4;
            foreach (Particle P in Particles)
            {
                PostProcessinggraphics.DrawEllipse(Pens.Red, new Rectangle((int)(P.y*PostProcessingPictureBox.Size.Width/PostProcessingBitmap.Height) - delta, (int)(P.x*PostProcessingPictureBox.Size.Height/PostProcessingBitmap.Width) - delta, delta * 2, delta * 2));
            }
            
        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialogChooseMovieFolder;
        private GoodStuff.GoodControlGroupBox groupBoxCapturePreview;

    }
}

