using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;
using System.Windows;
using GoodStuff;
using CameraDriver;
/// <summary>
/// Summary description for Class1
/// </summary>
namespace BrownianMotion {


    public class TrackRenderer : WorkerThread, IInitializable  {
        ThreadSafeQueue<SampleEventArgs> tracksToRenderQueue;
       
       public event SampleEventHandler renderedTracksReady;
        public event SampleEventHandler TestGraphicsFunction;
        public event SampleEventHandler GetPreProcessingStateVariables;
        public event SampleEventHandler GetPostProcessingStateVariables;
        public event SampleEventHandler PreProcessingImageUpdate;
        public event SampleEventHandler PostProcessingImageUpdate;

        GoodNumericVariable<Byte> _threshold;
        GoodVariable<Rectangle> _captureRegion;
        GoodVariable<Bitmap> _captureBitmap;
        GoodVariable<Bitmap> _passthruBitmap;
        Graphics CaptureGraphics;
        GoodPictureBox capturePictureBox;
        GoodPictureBox PostProcessingPictureBox;
        bool ShowParticleTracks;
        bool SetStartTime;
        bool PersistTracks;
        DateTime StartTime;
        Size FormPassThruSize;
        Rectangle FormPassThruClientRectangle;
        Graphics PreProcessingGraphics ;
        Size PreProcessingClientSize ;
        Rectangle PreProcessingClientRectangle ;
        Padding PreProcessingMargin;
        Graphics PostProcessingGraphics;
        Size PostProcessingClientSize;
        Rectangle PostProcessingClientRectangle;
        Padding PostProcessingMargin;

        

        #region Things that we dont use and should delete 
               
        Graphics FormPassThruGraphics;
        /*public Graphics PassthruGraphics
        {
            get { return _passthruGraphics; }
            set { _passthruGraphics = value; }
        }*/
        Rectangle _passthruArea;
        public Rectangle PassthruArea
        {
            get { return _passthruArea; }
            set { _passthruArea = value; }
        }
        
        public GoodVariable<Rectangle> CaptureRegion {
            get {
                return _captureRegion;
            }
            set {
                _captureRegion = value;
            }
        }

        public GoodVariable<Bitmap> CaptureBitmap {
            get {
                return _captureBitmap;
            }
            set {
                _captureBitmap = value;
            }
        }
        public GoodVariable<Bitmap> PassthruBitmap {
            get {
                return _passthruBitmap;
            }
            set {
                _passthruBitmap = value;
            }
        }
        public GoodNumericVariable<Byte> BlobThreshold {
            get {
                return _threshold;
            }
            set {
                _threshold = value;
            }
        }
        #endregion 
        public TrackRenderer() 
        {
            ShowParticleTracks = true;
            tracksToRenderQueue = new ThreadSafeQueue<SampleEventArgs>(20);
            StartTime = DateTime.Now;
        }
        public void UISetStartTime(object sender, SampleEventArgs sArgs)
        {
            SetStartTime = true; // set up a flag
            //StartTime = DateTime.Now;
        }
        public void UIPersistTracksChanged(object sender, SampleEventArgs sArgs)
        {
            PersistTracks = (bool)sArgs.Sample["Value"];
        }
        public event SampleEventHandler RenderedTracksReady {
            add { RenderedTracksReady += value; }
            remove { RenderedTracksReady -= value; }
        }
        /*public void RegionChangedSignal(object sender, SampleEventArgs sArgs)
        {
            if(sArgs.Sample.ContainsKey("CaptureRegion")
                _captureRegion = (GoodVariable<Rectangle>)sArgs.Sample["CaptureRegion"];
        }*/

        public void renderedTrackingDone(object sender, SampleEventArgs sArgs) {
            renderedTracksReady(this, sArgs);
        }
        public void UpdateTracksSignal(object sender, SampleEventArgs sArgs)
        {
            ShowParticleTracks = !ShowParticleTracks;
        }
        public void PassThruStateChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Graphics"))
                FormPassThruGraphics = sArgs.Sample["Graphics"] as Graphics;
            if (sArgs.Sample.ContainsKey("ClientSize"))
                FormPassThruSize = (Size)sArgs.Sample["ClientSize"];
            if (sArgs.Sample.ContainsKey("ClientRectangle"))
                FormPassThruClientRectangle = (Rectangle)sArgs.Sample["ClientRectangle"];
        }
        
        public void UIStateChanged(object sender, SampleEventArgs sArgs)
        {
            if(sArgs.Sample.ContainsKey("CaptureRegion"))
                CaptureRegion = sArgs.Sample["CaptureRegion"] as GoodVariable<Rectangle>;
            if(sArgs.Sample.ContainsKey("PassThruGraphics"))
                FormPassThruGraphics = sArgs.Sample["PassThruGraphics"] as Graphics;
            if(sArgs.Sample.ContainsKey("FormPassThruSize"))
                FormPassThruSize = (Size)sArgs.Sample["FormPassThruSize"];
            if(sArgs.Sample.ContainsKey("PassThruClientRectangle"))
                FormPassThruClientRectangle = (Rectangle)sArgs.Sample["PassThruClientRectangle"];
            if (sArgs.Sample.ContainsKey("CaptureGraphics"))
                CaptureGraphics = (Graphics)sArgs.Sample["CaptureGraphics"];
            if (sArgs.Sample.ContainsKey("CapturePictureBox"))
                capturePictureBox = (GoodPictureBox)sArgs.Sample["CapturePictureBox"];
            if (sArgs.Sample.ContainsKey("PostProcessingPictureBox"))
                PostProcessingPictureBox = (GoodPictureBox)sArgs.Sample["PostProcessingPictureBox"];
            if (sArgs.Sample.ContainsKey("UpdateParticleTracks"))
                ShowParticleTracks = (bool)sArgs.Sample["UpdateParticleTracks"];
        }
        public void Quit(object sender, SampleEventArgs sArgs)
        {
            StopThread();
        }

        public void init(object sender, SampleEventArgs sArgs)
        {
            Initialize();
        }
        public void IncomingParticleTracks(object sender, SampleEventArgs sArgs)
        {
            if (SetStartTime && sArgs.Sample.ContainsKey("Time"))
            {
                SetStartTime = false;
                StartTime = (DateTime)sArgs.Sample["Time"];
            }
            else if (SetStartTime)
            {
                SetStartTime = false;
                StartTime = DateTime.Now;
            }
            tracksToRenderQueue.Enqueue(sArgs);
        }



        public void Initialize()
        {
            CaptureRegion = new GoodVariable<Rectangle>();
            CaptureRegion.Value = new Rectangle(0, 0, 200, 200);
            
            string threadString = "TrackRenderer." + this.ToString();
            CreateThread(threadString, ThreadPriority.Normal);
            StartThread();

        }

        protected override void ThreadProc()
        {
            SampleEventArgs s;
            while (KeepGoing(100)) {
                
                tracksToRenderQueue.Wait(100);
                while (tracksToRenderQueue.Count > 0) 
                {
                    s = tracksToRenderQueue.Dequeue();
                    RenderGraphics(s);
                    //renderedTracksReady(this, s);
                }
            }
        }
        public Point[][] ConstructParticleTracks(SampleEventArgs s)
        {
       
            Particle[] particles = (Particle[])s.Sample["Particles"];
            Particle[] LostParticles;
            if (PersistTracks && s.Sample.ContainsKey("LostParticles"))
                LostParticles = ((List<Particle>)s.Sample["LostParticles"]).ToArray();
            else
                LostParticles = new Particle[0];
            byte[,] rawdata = (byte[,])s.Sample["CaptureRegionArray"];
            Point[][] particlepaths = new Point[particles.Length + LostParticles.Length][];
            Particle[] currentpath;
            float Xconversion = PreProcessingClientSize.Width / (float)rawdata.GetLength(0);
            float Yconversion = PreProcessingClientSize.Height / (float)rawdata.GetLength(1);

            for (int i = 0; i < particles.Length; i++)
            {
                currentpath = particles[i].ToArray();
                particlepaths[i] = new Point[currentpath.Length];
                if (currentpath.Length > 1)
                {
                    for (int j = 0; j < currentpath.Length; j++)
                    {
                        particlepaths[i][j] = new Point((int)(currentpath[j].x * Xconversion)+PreProcessingClientRectangle.X, (int)(currentpath[j].y * Yconversion)+PreProcessingClientRectangle.Y);
                    }
                    
                }
            }
            for( int i = 0 ; i < LostParticles.Length; i++)
            {
                currentpath = LostParticles[i].ToArray(StartTime);
                particlepaths[i+particles.Length] = new Point[currentpath.Length];
                if (currentpath.Length > 1)
                {
                    for (int j = 0; j < currentpath.Length; j++)
                    {
                        particlepaths[i+particles.Length][j] = new Point((int)(currentpath[j].x * Xconversion) + PreProcessingClientRectangle.X, (int)(currentpath[j].y * Yconversion) + PreProcessingClientRectangle.Y);
                    }
                }
            }
            return particlepaths;
        }
        public void RenderGraphics(SampleEventArgs s)
        {
            RenderPassThruFramework(s);
            RenderControlBitmapsFrameWork(s);
        }
        #region Old, non-framework renderings
        public void RenderControlBitmaps(SampleEventArgs sArgs)
        {
            Bitmap CaptureBitmap = ((Bitmap)sArgs.Sample["CaptureBitmap"]);
            Bitmap PostProcessingBitmap = ((Bitmap)sArgs.Sample["PostProcessedBitmap"]);
            Particle[] Particles = (Particle[])sArgs.Sample["Particles"];
            
            Graphics PostProcessingGraphics = PostProcessingPictureBox.CreateGraphics();

            CaptureGraphics.DrawImage(
                CaptureBitmap,
                capturePictureBox.ClientRectangle,
                new Rectangle(0, 0, CaptureBitmap.Width, CaptureBitmap.Height),
                GraphicsUnit.Pixel);
            PostProcessingGraphics.DrawImage(
                PostProcessingBitmap,
                PostProcessingPictureBox.ClientRectangle,
                new Rectangle(0, 0, PostProcessingBitmap.Width, PostProcessingBitmap.Height),
                GraphicsUnit.Pixel);

            if (ShowParticleTracks)
            {
                Point[][] ParticleTracks = ConstructParticleTracks(sArgs);


                if (ParticleTracks != null)
                {
                    foreach (Point[] P in ParticleTracks)
                    {
                        if (P.Length > 1)
                        {
                            CaptureGraphics.DrawLines(Pens.White, P);
                        }
                    }
                }
            }
            int delta = 4;
            foreach (Particle P in Particles)
            {
                PostProcessingGraphics.DrawEllipse(Pens.Red, new Rectangle((int)(P.y * PostProcessingPictureBox.Size.Width / PostProcessingBitmap.Height) - delta, (int)(P.x * PostProcessingPictureBox.Size.Height / PostProcessingBitmap.Width) - delta, delta * 2, delta * 2));
            }
        }
        public void RenderPassThru(SampleEventArgs sArgs)
        {
            Bitmap b = ((GoodVariable<Bitmap>)sArgs.Sample["PassthruBitmap"]).Value;
            CaptureRegion = (GoodVariable<Rectangle>)sArgs.Sample["CaptureRegion"];
            //Graphics _passthruGraphics = (Graphics)sArgs.Sample["PassThruFormGraphics"];    

            FormPassThruGraphics.DrawImage(
                b,
                FormPassThruClientRectangle,
                new Rectangle(0, 0, b.Width, b.Height),
                GraphicsUnit.Pixel);
            //*/
            Rectangle captureRectangle = CaptureRegion.Value;

            Rectangle scaledRectangle = new Rectangle(
                captureRectangle.X * FormPassThruSize.Width / b.Width,
                captureRectangle.Y * FormPassThruSize.Height / b.Height,
                captureRectangle.Width * FormPassThruSize.Width / b.Width,
                captureRectangle.Height * FormPassThruSize.Height / b.Height);


            FormPassThruGraphics.DrawRectangle(Pens.Red, scaledRectangle);

        }
        #endregion 
        public void RenderPassThruFramework(SampleEventArgs sArgs)
        {
            
            if (sArgs.Sample.ContainsKey("PassthruBitmap"))
            {
                CaptureRegion = (GoodVariable<Rectangle>)sArgs.Sample["CaptureRegion"];
                Bitmap b = ((GoodVariable<Bitmap>)sArgs.Sample["PassthruBitmap"]).Value;


                //Graphics _passthruGraphics = (Graphics)sArgs.Sample["PassThruFormGraphics"];    
                BufferedGraphicsContext currentContext;
                currentContext = BufferedGraphicsManager.Current;

                BufferedGraphics BG = currentContext.Allocate(FormPassThruGraphics,
                FormPassThruClientRectangle);
                
                BG.Graphics.DrawImage(
                    b,
                    FormPassThruClientRectangle,
                    new Rectangle(0, 0, b.Width, b.Height),
                    GraphicsUnit.Pixel);

                Rectangle captureRectangle = CaptureRegion.Value;

                Rectangle scaledRectangle = new Rectangle(
                    captureRectangle.X * FormPassThruSize.Width / b.Width,
                    captureRectangle.Y * FormPassThruSize.Height / b.Height,
                    captureRectangle.Width * FormPassThruSize.Width / b.Width,
                    captureRectangle.Height * FormPassThruSize.Height / b.Height);


                BG.Graphics.DrawRectangle(Pens.Red, scaledRectangle);


                SampleEventArgs sout = new SampleEventArgs();
                sout.Sample.Add("BufferedGraphics", BG);
                TestGraphicsFunction(this, sout);
            }
        }
        public void RenderControlBitmapsFrameWork(SampleEventArgs sArgs)
        {
            //this calls render signals to two GoodPictureBoxes. 
            //One image, the "Capture Image" is the image captured from the camera with particle tracks overlayed on it
            //the second image, the "PostProcessed Image" is post image processing with red circles choosing centers of found particles
            BufferedGraphicsContext currentContext = BufferedGraphicsManager.Current;
            if (PreProcessingGraphics == null)
            {
                if (GetPreProcessingStateVariables != null)
                    GetPreProcessingStateVariables(this, new SampleEventArgs());
            }
            else
            {

                if (sArgs.Sample.ContainsKey("CaptureBitmap"))
                {
                    Bitmap CaptureBitmap = ((Bitmap)sArgs.Sample["CaptureBitmap"]);
                    //Set up a buffered graphics to draw on
                    BufferedGraphics BG = currentContext.Allocate(PreProcessingGraphics,
                    PreProcessingClientRectangle);
                    //draw the bitmap
                    BG.Graphics.DrawImage(
                    CaptureBitmap,
                    PreProcessingClientRectangle,
                    new Rectangle(0, 0, CaptureBitmap.Width, CaptureBitmap.Height),
                    GraphicsUnit.Pixel);
                    //draw particle tacks
                    if (ShowParticleTracks && sArgs.Sample.ContainsKey("Particles"))
                    {
                        Point[][] ParticleTracks = ConstructParticleTracks(sArgs);//compute particle tracks and scale them to the graphics object

                        if (ParticleTracks != null)
                        {
                            foreach (Point[] P in ParticleTracks)
                            {
                                if (P.Length > 1)
                                {
                                    BG.Graphics.DrawLines(Pens.White, P);
                                }
                            }
                        }
                    }

                    SampleEventArgs sout = new SampleEventArgs();
                    sout.Sample.Add("BufferedGraphics", BG);
                    //send out signal to GoodPicturebox
                    PreProcessingImageUpdate(this, sout);
                }
            }
            if (PostProcessingGraphics == null) //do we have information about the thing we're writing to?
            {
                GetPostProcessingStateVariables(this, new SampleEventArgs()); //ask for it
            }
            else
            {
                if (sArgs.Sample.ContainsKey("PostProcessedBitmap"))
                {
                    Bitmap PostProcessingBitmap = ((Bitmap)sArgs.Sample["PostProcessedBitmap"]);
          
                    //the thing that we draw on and send to the picturebox
                    BufferedGraphics BG2 = currentContext.Allocate(PostProcessingGraphics,
                    PostProcessingClientRectangle);
                    //draw a bitmap
                    BG2.Graphics.DrawImage(
                    PostProcessingBitmap,
                    PostProcessingClientRectangle,
                    new Rectangle(0, 0, PostProcessingBitmap.Width, PostProcessingBitmap.Height),
                    GraphicsUnit.Pixel);
                    //do we have particles? if so then circle them
                    if (sArgs.Sample.ContainsKey("Particles"))
                    {
                        Particle[] Particles = (Particle[])sArgs.Sample["Particles"];
                        int delta = 4;
                        foreach (Particle P in Particles)
                        {
                            Pen p;
                            if (P.Past != null) p = Pens.Red; // Good Particles!
                            else p = Pens.Blue; // Bad Particles (no past)

                            BG2.Graphics.DrawEllipse(p, new Rectangle(PostProcessingClientRectangle.X + (int)(P.x * PostProcessingClientSize.Width / PostProcessingBitmap.Width) - delta, PostProcessingClientRectangle.Y + (int)(P.y * PostProcessingClientSize.Height / PostProcessingBitmap.Height) - delta, delta * 2, delta * 2));
                        }
                    }
                    SampleEventArgs sout2 = new SampleEventArgs();
                    sout2.Sample.Add("BufferedGraphics", BG2);
                    //send out signal to picturebox
                    PostProcessingImageUpdate(this, sout2);
                }
            }

        }
        public void ReceivePreProcessingStateVariables(object sender, SampleEventArgs sArgs)
        {
            PreProcessingGraphics = (Graphics)sArgs.Sample["Graphics"];
            PreProcessingClientSize = (Size)sArgs.Sample["ClientSize"];
            PreProcessingClientRectangle = (Rectangle)sArgs.Sample["ClientRectangle"];
            PreProcessingMargin = (Padding)sArgs.Sample["Margin"];
        }
        public void ReceivePostProcessingStateVariables(object sender, SampleEventArgs sArgs)
        {
            PostProcessingGraphics = (Graphics)sArgs.Sample["Graphics"];
            PostProcessingClientSize = (Size)sArgs.Sample["ClientSize"];
            PostProcessingClientRectangle = (Rectangle)sArgs.Sample["ClientRectangle"];
            PostProcessingMargin = (Padding)sArgs.Sample["Margin"];
        }
    }
}
