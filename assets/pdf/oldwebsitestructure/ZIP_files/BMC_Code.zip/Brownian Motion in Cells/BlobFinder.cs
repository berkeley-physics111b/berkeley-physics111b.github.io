using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.Threading;
using GoodStuff;
using CameraDriver;
using fftwlib;

namespace BrownianMotion
{
    public class Blob
    {
        public List<Point> Points;
        public int Area;
        public int Brightness;
        public double X;
        public double Y;
        public int BlobNumber;
        public Blob()
        {
            Points = new List<Point>();
        }
        public void Merge(Blob B, ref int[,] BlobArray)
        {
            Points.AddRange(B.Points);
            if (BlobArray != null)
            {
                foreach (Point P in B.Points)
                    BlobArray[P.X, P.Y] = BlobNumber; // change BlobArray so they all have the same blobnumber
            }
        }
        public void FindCenter(ref byte[,] ImageMap)
        {
            Brightness = 0;
            Area = Points.Count;
            X = 0;
            Y = 0;


            #region Find Center using Brightest Pixel method
            /*
            Point BrightestPoint = Points[0];
            foreach (Point P in Points) //run through all points in blob
            {
                Brightness += ImageMap[P.X, P.Y]; //Its also nice to add up the total brightness of the blob even though we don't need it for this method. The computer can use this information to better track particles later. 
                //if P is brighter than the Previous BrightestPoint
                if (ImageMap[P.X, P.Y] > ImageMap[BrightestPoint.X, BrightestPoint.Y]) 
                    BrightestPoint = P; // redefine the Brightest Point to be P
            }
            //define blob center to be brightest point
            X = BrightestPoint.X; 
            Y = BrightestPoint.Y;
            */
            #endregion
            
            #region Find Center using Centroid method

            foreach (Point P in Points)
            {
                byte z = ImageMap[P.X, P.Y];
                Brightness += z;
                X += z * P.X;
                Y += z * P.Y;
            }

            X /= Brightness;
            Y /= Brightness;

            #endregion
        }
    }
    public class BlobFinder : WorkerThread, IInitializable
    {
        ThreadSafeQueue<SampleEventArgs> _frameQueue;

        bool DoFindParticles;
        bool EchoDebug;

        public event SampleEventHandler FrameComplete;
        public event SampleEventHandler ReportStatus;
        public double[,] AverageImage;
        public float[,] Annulus;

        double MinParticleArea;
        double MaxParticleArea;
        double DeadRegionAroundParticle;
        double zScoreThreshold;

        public GoodProperty<Double> ZScoreThreshold
        {
            get { GoodProperty<Double> G = new GoodProperty<double>(); G.Value = zScoreThreshold; return G; }
            set { zScoreThreshold = value.Value; }
        }
        public BlobFinder()
        {
            _frameQueue = new ThreadSafeQueue<SampleEventArgs>(100);
            AverageImage = new double[200, 200];
            Annulus = new float[1, 1];
            MinParticleArea = 3;
            MaxParticleArea = 100;
            DeadRegionAroundParticle = 3;
            zScoreThreshold = 3;
            EchoDebug = false;
        }

        public void Initialize()
        {
            string threadString = "BlobFinder." + this.ToString();
            CreateThread(threadString, ThreadPriority.Normal);
            StartThread();
        }
        #region Interface with User Interface
        public void ReportStatusLocal(string messageout)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("Message", messageout);
            if (ReportStatus != null)
                ReportStatus(this, s);
        }

        public void UIMinParticleDiameterChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
            {
                double value = Decimal.ToDouble((decimal)sArgs.Sample["Value"]);
                MinParticleArea = Math.PI*Math.Pow(value, 2)/4;
            }
        }
        public void UIMaxParticleDiameterChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
            {
                double value = Decimal.ToDouble((decimal)sArgs.Sample["Value"]);
                MaxParticleArea = Math.PI * Math.Pow(value, 2) / 4;
            }
        }
        public void UIZScoreThresholdChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
            {
                double value = Decimal.ToDouble((decimal)sArgs.Sample["Value"]);
                zScoreThreshold = Math.Max(value,1);
            }
        }
        public void OnOffSwitch(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                DoFindParticles = (bool)sArgs.Sample["Value"];
        }
        public void Quit(object sender, SampleEventArgs sArgs)
        {
            StopThread();
        }
        #endregion

        //have just received a new frame from somewhere
        public void ProcessFrame(object sender, SampleEventArgs args)
        {
            _frameQueue.Enqueue(args);
        }
                
        #region WorkerThread members

        protected override void ThreadProc()
        {
            while (KeepGoing(100))                                                   // loop until quit signal
            {
                _frameQueue.Wait(100);                                               // wait for a frame to be queued

                while (_frameQueue.Count > 0)                                        // loop until all queued frames processed
                {
                    SampleEventArgs s = _frameQueue.Dequeue();
                    if (DoFindParticles)
                    {
                        if (s.Sample.ContainsKey("CaptureRegionArray"))
                        {
                            Bitmap PostProcessedBitmap = new Bitmap(1, 1); //create a dumb bitmap to write to
                            //Point[] FoundParticles = FindBlobs((Byte[,])s.Sample["CaptureRegionArray"], ref PostProcessedBitmap);
                            Blob[] FoundParticles = FindBlobsFast((Byte[,])s.Sample["CaptureRegionArray"], ref PostProcessedBitmap);
                            s.Sample.Add("FoundParticles", FoundParticles);
                            s.Sample.Add("PostProcessedBitmap", PostProcessedBitmap);
                        }
                        else
                        {
                            ReportStatusLocal("Data Array not found in BlobFinder");
                        }
                            
                    }
                    FrameComplete(this, s);
                }                                                                    // end of while (_frameQueue.Count > 0)
            }                                                                        // end of while (KeepGoing(100))
        }
        #endregion

        public Blob[] FindBlobsFast(byte[,] CaptureImage, ref Bitmap OutBitmap)
        {
            DateTime Start = DateTime.Now;
            int sx = CaptureImage.GetLength(0);
            int sy = CaptureImage.GetLength(1);

            List<Blob> Blobs = new List<Blob>();
            Blobs.Add(null);

            int ActiveBlobNumber = 0;
            int NumberofBrightPixels = 0;
            bool BrightField = false;


            int[,] BlobArray = new int[sx, sy];
            if (AverageImage.GetLength(0) != sx || AverageImage.GetLength(1) != sy) //have we resized recently?
            {
                AverageImage = new double[sx, sy]; // make a new, differently sized Average Image
            }
            int mean = 0;
            //          fftweasy Q = new fftweasy();
            //  Q.ToBitmap(AverageImage).Save("C:\\AverageImage.bmp");
            //            Q.ToBitmap(CaptureImage).Save("C:\\PreProcessing.bmp");
            unsafe
            {
                #region Bright Field vs Dark Field check and change
                for (int x = 0; x < sx; x++) //run through all of the columns
                {
                    for (int y = 0; y < sy; y++) //run through all of the rows for each column
                    {
                        if (CaptureImage[x, y] > 255 / 3)
                            NumberofBrightPixels++;
                    }
                }
                if (NumberofBrightPixels > CaptureImage.Length / 2) //Bright Field!
                {
                    for (int x = 0; x < sx; x++) //run through all of the columns
                    {
                        for (int y = 0; y < sy; y++) //run through all of the rows for each column
                        {
                            CaptureImage[x, y] = (byte)(255 - CaptureImage[x, y]);
                        }
                    }
                }
                #endregion

                for (int x = 0; x < sx; x++) //run through all of the columns
                {
                    for (int y = 0; y < sy; y++) //run through all of the rows for each column
                    {

                        byte OriginalPixel = CaptureImage[x, y]; // save our original image information before we take out the Average
                        CaptureImage[x, y] = (byte)Math.Max(CaptureImage[x, y] - AverageImage[x, y], 0); // subtract Average Image from Newly Captured Image

                        //Average Frame Created Here
                        

                        #region Working Averaging code
                        //A simple Averaging Scheme. AverageImage = OldCaptureImage
                        //AverageImage[x, y] = OriginalPixel;//simple average

                        //Exponential Averaging Scheme. AverageImage = Time Series Low-Pass of all previous images
                        AverageImage[x, y] = AverageImage[x, y] * .95 + .05 * OriginalPixel; // Exponential Averaging
                        #endregion

                        mean += CaptureImage[x, y];
                    }
                }
            }
            //        Q.ToBitmap(CaptureImage).Save("C:\\PostAverageRemoval.bmp");
            #region Find and Connect Blobs
            mean = mean / sx / sy; //normalize mean to image size
            double std = 0;
            unsafe
            {
                foreach (byte b in CaptureImage)
                    std += (b - mean) * (b - mean);
                std = Math.Sqrt(std / sx / sy);
            }

            byte threshold = (byte)(Math.Min(zScoreThreshold * std + mean, 255));


            int Blobnumber = 1;
            bool continuingblob = false;
            unsafe
            {
                for (int x = 0; x < sx; x++)
                {
                    for (int y = 0; y < sy; y++)
                    {
                        if (BlobArray[x, y] == 0 && CaptureImage[x, y] > threshold) // found something!
                        {
                            //we have four cases, left off top off, left on, top off, left off, top on, left on, top on
                            //Top On
                            if (y >= 1 && BlobArray[x, y - 1] != 0)
                            {
                                int top = BlobArray[x, y - 1];
                                //Top On Left On
                                if (x >= 1 && BlobArray[x - 1, y] != 0)
                                {
                                    int left = BlobArray[x - 1, y];
                                    if (top == left) //same blob
                                    {
                                        BlobArray[x, y] = left;
                                        Blobs[left].Points.Add(new Point(x, y));
                                    }
                                    else //intersection of two preexisting blobs
                                    {

                                        Blobs[left].Points.Add(new Point(x, y));
                                        Blobs[left].Merge(Blobs[top], ref BlobArray);
                                        BlobArray[x, y] = left;
                                        Blobs[top] = null;
                                    }
                                }
                                //Top On, Left off
                                else
                                {
                                    Blobs[top].Points.Add(new Point(x, y));
                                    BlobArray[x, y] = top;
                                }
                            }
                            //top off
                            //left on
                            else if (x >= 1 && BlobArray[x - 1, y] != 0)
                            {
                                int left = BlobArray[x - 1, y];
                                Blobs[left].Points.Add(new Point(x, y));
                                BlobArray[x, y] = left;
                            }
                            //top off left off New Blob!!!!!
                            else
                            {
                                ActiveBlobNumber++;
                                Blob newblob = new Blob();
                                newblob.BlobNumber = ActiveBlobNumber;
                                newblob.Points.Add(new Point(x, y));
                                BlobArray[x, y] = ActiveBlobNumber;
                                Blobs.Add(newblob);
                            }

                        }
                    }
                }
            }
            #endregion

            fftweasy fft = new fftweasy();
            if (threshold != 0)
            {
                unsafe
                {
                    for (int x = 0; x < sx; x++)
                    {
                        for (int y = 0; y < sy; y++)
                        {
                            //rescale image to look pretty for output
                            CaptureImage[x, y] = (byte)(Math.Min(CaptureImage[x, y] * 128 / threshold, 255));
                        }
                    }
                }
            }
            OutBitmap = fft.ToBitmap(CaptureImage); //make output bitmap
            //                OutBitmap.Save("C:\\PostThresholding.bmp");

            List<Blob> GoodBlobs = new List<Blob>(Blobs.Count);
            for (int i = 0; i < Blobs.Count; i++)
            {
                if (Blobs[i] != null)
                {
                    Blobs[i].FindCenter(ref CaptureImage);
                    if (Blobs[i].Area >= MinParticleArea && Blobs[i].Area <= MaxParticleArea) //check to make sure that the blob is of the proper size
                        GoodBlobs.Add(Blobs[i]);
                }
            }
            


            TimeSpan S = DateTime.Now - Start;
            if(EchoDebug)
                ReportStatusLocal("BlobFinding took " + S.TotalSeconds.ToString() + " seconds");
            return GoodBlobs.ToArray();

        }

        #region Old FindBlobsFast functions
        private List<Point> FillBlob(ref byte[,] CaptureImage, ref int[,] BlobArray, int startx, int starty, byte threshold)
        {
            List<Point> outlist = new List<Point>();
            outlist.Add(new Point(startx, starty));

            int minx = Math.Max(startx - 1, 0); //out boundary checks
            int miny = Math.Max(starty - 1, 0);
            int maxx = Math.Min(startx + 1, CaptureImage.GetLength(0) - 1);
            int maxy = Math.Min(starty + 1, CaptureImage.GetLength(1) - 1);

            for (int x = minx; x <= maxx; x++)
            {
                for (int y = miny; y <= maxy; y++)
                {
                    if (BlobArray[x, y] == 0 && CaptureImage[x, y] > threshold && (x != startx || y != starty))
                    {
                        BlobArray[x, y] = BlobArray[startx, starty];
                        outlist.AddRange(FillBlob(ref CaptureImage, ref BlobArray, x, y, threshold));
                    }
                }
            }
            return outlist;
        }
        private Particle ClaimParticle(ref byte[,] CaptureImage, ref int[,] BlobArray, int startx, int starty, byte threshold)
        {
            List<Point> pointlist = FillBlob(ref CaptureImage, ref BlobArray, startx, starty, threshold);
            Point[] pointarray = pointlist.ToArray();
            Particle NewParticle = new Particle();

            double x = 0, y = 0, total = 0;

            foreach (Point P in pointarray)
            {
                byte brightness = CaptureImage[P.X, P.Y];
                x += P.X * brightness;
                y += P.Y * brightness;
                total += brightness;
            }
            x = x / total;
            y = y / total;
            NewParticle.x = x;
            NewParticle.y = y;
            NewParticle.brightness = total;
            NewParticle.Area = pointarray.Length;

            return NewParticle;
        }
        public Particle[] FindBlobsFastOld(byte[,] CaptureImage, ref Bitmap OutBitmap)
        {
            int sx = CaptureImage.GetLength(0);
            int sy = CaptureImage.GetLength(1);

            List<Particle> Particles = new List<Particle>();

            int ActiveBlobNumber = 0;



            int[,] BlobArray = new int[sx, sy];
            if (AverageImage.GetLength(0) != sx || AverageImage.GetLength(1) != sy) //have we resized recently?
            {
                AverageImage = new double[sx, sy];
            }
            int mean = 0;
            for (int x = 0; x < sx; x++)
            {
                for (int y = 0; y < sy; y++)
                {
                    byte temp = CaptureImage[x, y];
                    CaptureImage[x, y] = (byte)Math.Max((float)CaptureImage[x, y] - AverageImage[x, y], 0);
                    AverageImage[x, y] = (float)(AverageImage[x, y] * .95 + .05 * temp); // create average frame
                    mean += CaptureImage[x, y];
                }
            }
            mean = mean / sx / sy;
            double std = 0;
            foreach (byte b in CaptureImage)
                std += (b - mean) * (b - mean);
            std = Math.Sqrt(std / sx / sy);

            byte threshold = (byte)(Math.Min(zScoreThreshold * std + mean, 255));


            for (int x = 0; x < sx; x++)
            {
                for (int y = 0; y < sy; y++)
                {
                    if (BlobArray[x, y] == 0 && CaptureImage[x, y] > threshold) // found a new blob
                    {
                        ActiveBlobNumber++;
                        BlobArray[x, y] = ActiveBlobNumber;
                        Particles.Add(ClaimParticle(ref CaptureImage, ref BlobArray, x, y, (byte)(threshold * .66))); //claim a blob and add it to the list
                    }
                }
            }
            fftweasy fft = new fftweasy();
            if (threshold != 0)
            {
                for (int x = 0; x < sx; x++)
                {
                    for (int y = 0; y < sy; y++)
                    {

                        CaptureImage[x, y] = (byte)(Math.Min(CaptureImage[x, y] * 128 / threshold, 255));
                    }
                }
            }
            OutBitmap = fft.ToBitmap(CaptureImage);


            List<Particle> outparticles = new List<Particle>(Particles.Count);
            for (int i = 0; i < Particles.Count; i++)
                if (Particles[i].Area >= MinParticleArea && Particles[i].Area <= MaxParticleArea)
                    outparticles.Add(Particles[i]);



            return outparticles.ToArray();

        }
        #endregion

        #region FFT FindBlob Method
        public Point[] FindBlobs(byte[,] CaptureImage, ref Bitmap OutBitmap)
        {
            fftweasy fft = new fftweasy();           

            int sx = CaptureImage.GetLength(0);
            int sy = CaptureImage.GetLength(1);

            double ParticleDiameter = (Math.Sqrt(MinParticleArea) + Math.Sqrt(MaxParticleArea)) / 2;

            List<Point> BlobCenters = new List<Point>();

            float[,] CaptureImagef = fft.BytetoFloat(CaptureImage);

            long NumberofBrightPixels = 0;
            float threshold = 128;
            bool BrightParticlesonDarkField = true;

            //deal with averaging image
            //fft.ToBitmap(CaptureImagef).Save("c:\\captureimagepre.bmp");
            if (AverageImage.GetLength(0) == sx && AverageImage.GetLength(1) == sy)
            {
                for (int x = 0; x < sx; x++)
                {
                    for (int y = 0; y < sy; y++)
                    {
                        //add a bit of the current image to the average image
                        AverageImage[x, y] = (float)(AverageImage[x, y] * .95 + .05*CaptureImagef[x, y]); // create average frame
                        if (CaptureImagef[x, y] > threshold)
                            NumberofBrightPixels++;

                        CaptureImagef[x, y] -= (float)AverageImage[x, y]; // subtract off average frame
                    }
                }
            }
            else //have we resized recently?
            {
                AverageImage = new double[sx, sy];
            }
            if (Annulus.GetLength(0) != sx || Annulus.GetLength(1) != sy) //same, have we resized recently? if so, recreate annulus
            {
                Annulus = fft.GaussianWithMoat(sx, sy, (float)ParticleDiameter / 2);
            }
            //Invert the image if necessary so as to have bright particles on a dark field
            if (NumberofBrightPixels > (CaptureImagef.Length / 2))
            {
                for(int x = 0 ; x < sx ; x++)
                {
                    for(int y = 0 ; y < sy; y++)
                    {
                        CaptureImagef[x,y] = 256-CaptureImagef[x,y];
                    }
                }
            }
                
            //fft.ToBitmap(AverageImage).Save("c:\\AverageImage.bmp");
            //fft.ToBitmap(CaptureImagef).Save("c:\\captureimagepost.bmp");    
            float[,] ConvolvedImage = fft.ConvolveEasy(CaptureImagef, Annulus); //perform fast convolution of the annulus over the captured image

            
            float mean = 0; float std = 0;
            //find mean and standard deviation
            for (int x = 0; x < sx; x++)
            {
                for (int y = 0; y < sy; y++)
                {
                    ConvolvedImage[x, y] = Math.Max(ConvolvedImage[x, y], 0);
                    std += (ConvolvedImage[x, y] - mean) * (ConvolvedImage[x, y] - mean);
                }
            }

            std = (float)Math.Max(1,Math.Sqrt(std / ConvolvedImage.Length)); // we want a minimum std in case we run into a uniform field

            

            

            Point tempblob;
            //fft.ToBitmap(ConvolvedImage).Save("c:\\convolvedimagepre.bmp");
            OutBitmap = fft.ToBitmap(ConvolvedImage);
            for (int x = 0; x < sx; x++)
            {
                for (int y = 0; y < sy; y++)
                {
                    if ((ConvolvedImage[x, y]) > zScoreThreshold * std)
                    { //found a blob
                        tempblob = FindLocalMax(ConvolvedImage, x, y); //center on the blob
                        //after we've found the center remove everything around so that we don't find the same blob again
                        Kill(ref ConvolvedImage, tempblob.X, tempblob.Y, (int)(ParticleDiameter/2 * DeadRegionAroundParticle)); 
                        BlobCenters.Add(tempblob);
                    }
                }
            }
            //fft.ToBitmap(ConvolvedImage).Save("c:\\convolvedimagepost.bmp");
            
            //fft.ToBitmap(CaptureImagef).Save("c:\\captureimage.bmp");

            return BlobCenters.ToArray();

        }
        public Point FindLocalMax(float[,] inArray, int startx, int starty)
        {
            int sx = inArray.GetLength(0);
            int sy = inArray.GetLength(1);
            int currentx = startx; int currenty = starty;
            int nextx, nexty;
            int highx = currentx, highy = currenty;
            float currenthigh = inArray[currentx, currenty];
            bool foundhighest = false;
            while (!foundhighest)
            {
                //check all neighboring points... make sure that we don't run off past the borders
                for (nextx = Math.Max(0, currentx - 1); nextx <= Math.Min(currentx + 1, sx-1); nextx++)
                {
                    for (nexty = Math.Max(0, currenty - 1); nexty <= Math.Min(currenty + 1, sy-1); nexty++)
                    {
                        if (Math.Abs(inArray[nextx, nexty]) > currenthigh)
                        {
                            currenthigh = Math.Abs(inArray[nextx, nexty]);
                            highx = nextx; highy = nexty;
                        }
                    }
                }
                if (highx == currentx && highy== currenty)
                    foundhighest = true;
                currentx = highx; currenty = highy;
            }
            return new Point(highx, highy);

        }
        public void Kill(ref float[,] inArray, int centerx, int centery, int radius, float value)
        {
            //sets all values in the array to the value centered at the center with a particular radius. 
            int sx = inArray.GetLength(0);
            int sy = inArray.GetLength(1);
            for (int x = Math.Max(0, centerx - radius); x < Math.Min(centerx + radius, sx); x++)
                for (int y = Math.Max(0, centery - radius); y < Math.Min(centery + radius, sy); y++)
                    inArray[x, y] = value;
        }
        public void Kill(ref float[,] inArray, int centerx, int centery, int radius)
        {
            Kill(ref inArray, centerx, centery, radius, 0);
        }
        #endregion


    }
}

