using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;

namespace CameraDriver
{
    public class DriverFunctions
    {
        #region error values

        public enum PdtErr
        {
            errSuccess = 0,		    // No error
            errBadParameter = 1,	// Bad parameter
            errBadHandle = 2,		// Handle is invalid
            errBadSequence = 3,		// Cannot perform function in this state
            errCancelled = 4,		// Frame cancelled by user
            errFrameTooSmall = 5,	// Frame buffer is too small
            errQueueFull = 6,		// Too many frames on queue
            errBandwidth = 7,		// 1394 bandwidth not available
            errResources = 8,		// Windows driver resources not available
            errNotFound = 9,		// Camera with that unique ID not found
            errAlreadyOpen = 10,	// Camera is already open
            errUnplugged = 11,		// Camera was unplugged
            errFault = 12,		    // Unexpected driver fault
            errCameraFault = 13,	// Unexpected camera fault
            errNotSupported = 14,	// Parameter not supported in this mode
            errNotValid = 15,		// Parameter value is not valid
            errTimeout = 16,		// Timeout during wait
            __err_force_32 = -1

        }

        #endregion

        #region camera management: list, open, and close

        // camera information structure returned by PdListCameras
        [StructLayout(LayoutKind.Sequential)]
        public unsafe struct PdtCamListItem
        {
            public UInt32 UniqueId;			        // Unique value for each camera
            public fixed Byte SerialString[32];	    // Camera's serial number
            public UInt16 PartNumber;			    // Camera part number
            public UInt16 PartVersion;		        // Camera part version
            public UInt32 InUse;				    // 1 if already open; 0 otherwise

        };

        [DllImport("pdapiDEBUG.dll")]
        public static extern UInt32 PdListCameras
        (
            ref PdtCamListItem pList,				// IN: Array of PdtCamListItem
            UInt32 ListLength,			            // IN: Length of PdtCamListItem array
            out UInt32 pConnectedNum		        // OUT: Number of connected cameras
                                                    //   (may be more than ListLength!).
                                                    //	 NULL pointer ok.
        );
        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdOpenCamera
        (
            UInt32 UniqueId,			            // IN: UniqueId from PdListCameras()
            out IntPtr pHandle				        // OUT: Camera handle returned here
        );
        [DllImport("pdapiDEBUG.dll")]
        unsafe public static extern PdtErr PdCloseCamera
        (
            IntPtr Handle				            // IN: Camera handle
        );

        #endregion

        #region Imaging setup: mode, format, frame size

        // enumeration for capture mode
        public enum PdtCaptureMode
        {
            modeIdle = 0,		// Camera idle, 1394 bandwidth is free
            modeStreaming = 1,		// Continuous stream of images
            modeShot = 2,		// Image taken on software trigger
            __mode_force_32 = -1

        }

        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdGetCaptureMode
        (
            IntPtr Handle,
            out PdtCaptureMode pMode				// OUT: Current mode returned here
        );
        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdSetCaptureMode
        (
            IntPtr Handle,
            PdtCaptureMode Mode				// IN: New mode
        );
        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdGetFormatSupport
        (
            IntPtr Handle,
            out UInt32 pFormatFlags		// OUT: Supported formats
        );

        // image formats
        public enum PdtImageFormat
        {
            fmtMono8 = 0,
            fmtYuv411 = 1,
            fmtYuv422 = 2,
            fmtYuv444 = 3,
            fmtRgb24 = 4,
            fmtMono16 = 5,
            fmtRgb48 = 6,
            fmtRaw8 = 9,				// Raw bayer pattern from color cameras
            fmtRaw16 = 10,				// Raw bayer pattern from color cameras
            __fmt_force_32 = -1

        }

        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdGetFormat
        (
            IntPtr Handle,
            out PdtImageFormat pFormat				// OUT: Image format
        );

        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdSetFormat
        (
            IntPtr Handle,
            PdtImageFormat Format				// IN: Image format
        );

        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdGetFrameSize
        (
            IntPtr              Handle,
            out UInt32          pFrameSize,			// OUT: Size in bytes (NULL OK)
            out UInt32          pNumberOfPixels,	    // OUT: Number of pixels (NULL OK)
            out UInt32          pPixelSize			// OUT: Size of each pixel (NULL OK)
        );

        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdGetRegionMax
        (
	        IntPtr			    Handle,
	        out UInt32		    pRoiWidth,			// OUT: Maximum width/height
	        out UInt32		    pRoiHeight			//	 (NULL OK for any value)
        );


        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdGetRegion
        (
	        IntPtr  			Handle,
	        out UInt32		    pRoiX,				// OUT: Region of interest
	        out UInt32		    pRoiY,				//   (NULL OK for any value)
	        out UInt32		    pRoiWidth,
	        out UInt32		    pRoiHeight
        );

        #endregion

        #region parameters
        [DllImport("pdapiDEBUG.dll")]
        unsafe public static extern PdtErr PdIsParamSupported
        (
            IntPtr Handle,
            UInt32 ParamKey			// IN: Parameter to query
        );


        [DllImport("pdapiDEBUG.dll")]
        unsafe public static extern PdtErr PdGetParamRange
        (
            IntPtr Handle,
            UInt32 ParamKey,			// IN: Parameter to query
            out UInt32 pMin,				// OUT: Minimum value (NULL OK)
            out UInt32 pMax,				// OUT: Maximum value (NULL OK)
            out UInt32 pDefault			// OUT: Default value (NULL OK)
        );


        [DllImport("pdapiDEBUG.dll")]
        unsafe public static extern PdtErr PdGetParamValueSupport
        (
            IntPtr Handle,
            UInt32 ParamKey,			// IN: Parameter to query
            out UInt32 pSupportFlags		// OUT: Supported values; bits 0-31
            //		inducate support of values
            //		0 to 31.  Value=0 means
            //		these flags are not applicable.
        );

        [DllImport("pdapiDEBUG.dll")]
        unsafe public static extern PdtErr PdGetParam
        (
            IntPtr Handle,
            UInt32 ParamKey,			// IN: Parameter to get
            out UInt32 pValue				// OUT: Parameter value
        );
        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdSetParam
        (
            IntPtr Handle,
            UInt32 ParamKey,			// IN: Parameter to set
            UInt32 Value				// IN: Parameter value
        );

        #endregion

        #region Frames

        [DllImport("pdapiDEBUG.dll")]
        unsafe public static extern PdtErr PdQueueFrame
        (
	        IntPtr			    Handle,
            IntPtr              pFrame,				// IN: frame to queue
	        PdtFrameCallback	Callback			// IN: Callback to run when frame
											        //	 is received.  (NULL OK)
        );

        public delegate void PdtFrameCallback(ref PdtFrame f);

        // Trigger
        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdTrigger
        (
	        IntPtr     			Handle,
	        UInt32      		NumShots			// IN: Number of images to trigger
        );

        [DllImport("pdapiDEBUG.dll")]
        public static extern PdtErr PdAbortFrames
        (
	        IntPtr  			Handle
        );


        [StructLayout(LayoutKind.Sequential)]
        unsafe public struct PdtFrame
        {
            //-----	In -----

            public IntPtr Buffer;				        // Your image buffer
            public UInt32 BufferSize;			        // Size of your image buffer in bytes

            public fixed UInt32 Context[4];			        // For your use (valuable for your (void * marshalled as Int32)
            //   frame-done callback).
            public fixed UInt32 _reserved1[8];

            //-----	Out -----

            public PdtErr Status;				// Status of this frame (PdtErr marshalled as Int32)

            public PdtImageFormat Format;
            public UInt32 BitDepth;
            public UInt32 Width;
            public UInt32 Height;
            public UInt32 Size;				        // Frame size, in bytes

            public UInt32 FrameCount;
            public UInt32 Timestamp;
            public UInt32 Tag;

            public UInt32 BayerPattern;

            public fixed UInt32 _reserved2[30];

        };

        [DllImport("pdapiDEBUG.dll")]
        unsafe public static extern PdtErr PdWaitForFrameDone
        (
	        IntPtr		    Handle,
            IntPtr          pFrame,
	        UInt32		    Timeout				    // IN: wait timeout, in milliseconds
											        //	 (use PDINFINITE for no timeout)
        );

        #endregion
    }
}

