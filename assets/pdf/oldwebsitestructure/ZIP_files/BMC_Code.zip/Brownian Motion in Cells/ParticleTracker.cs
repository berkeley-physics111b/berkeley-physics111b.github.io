using System;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using GoodStuff;
using CameraDriver;

namespace BrownianMotion
{
    /// <summary>
    /// Summary description for ParticleTracker
    /// </summary>
    ///
    public class Particle
    {
        public double x;
        public double y;
        public double brightness;
        public double Area;
        //public ParticleNetwork Network;
        public int NetworkNumber;
        public int FrameNumber;
        public DateTime Time;   
        public Particle Future;
        public Particle Past;
        public Particle()
        {
            x = 0;
            y = 0;
            NetworkNumber = 0;
            FrameNumber = 0;
        }
        public Particle(Blob B)
        {
            x = B.X;
            y = B.Y;
            Area = B.Area;
            brightness = B.Brightness;
        }
        public int PastLength()
        {
            Particle temp = this;
            int length = 1;
            while (temp.Past != null)
            {
                temp = temp.Past;
                length++;
            }
            return length;
        }
        public int PastLength(DateTime OldestTime)
        {
            Particle temp = this;
            int length = 0;
            while(temp!=null && temp.Time>OldestTime)
            {
                length++;
                temp = temp.Past;
            }
            return length;
        }

        public Particle[] ToArray(int length)
        {
            Particle[] outParticles = new Particle[length];
            Particle temp = this;
            for (int i = 0; i < length; i++)
            {
                outParticles[i] = temp;
                temp = temp.Past;
            }
            return outParticles;
        }
        public Particle[] ToArray()
        {
            return ToArray(PastLength());
        }
        public Particle[] ToArray(DateTime OldestTime)
        {
            return ToArray(PastLength(OldestTime));
        }
        public Particle[] ToArray(DateTime NewestTime, DateTime OldestTime)
        {
            Particle temp = this;
            while (temp != null && temp.Time > NewestTime) // while we're still newer than newest time
                temp = temp.Past; // go back in time!
            if (temp == null) //this particle history doesnt exist within the time bounds
                return null;
            else
                return temp.ToArray(temp.PastLength(OldestTime)); 
        }
        
        public double Metric(Particle B)
        {
            //metric for directed movement - tries to predict future location
            bool DirectedMetric = true;
            if (DirectedMetric)
            {
                Particle Old, New;
                if (Time > B.Time)
                {
                    New = this;
                    Old = B;
                }
                else
                {
                    Old = this;
                    New = B;
                }
                double ExpectedX, ExpectedY; // where we are going to center our search
                if (Old.Past != null)
                {
                    double dt = (Old.Time - Old.Past.Time).TotalSeconds;
                    double dxdt = (Old.x - Old.Past.x) / dt; // x velocity
                    double dydt = (Old.y - Old.Past.y) / dt; // y velocity
                    double newdt = (New.Time - Old.Time).TotalSeconds; // new time difference
                    ExpectedX = Old.x + dxdt * newdt;
                    ExpectedY = Old.y + dydt * newdt;
                }
                else // dont have history, can't find velocity, look around center
                {
                    ExpectedX = Old.x;
                    ExpectedY = Old.y;
                }
                if (brightness != 0 && Area != 0 && B.Area != 0 && B.brightness != 0) //make sure that this information exists
                {
                    double complex = (Math.Pow(ExpectedX - New.x, 2) + Math.Pow(ExpectedY - New.y, 2)) * Math.Pow((1 + Math.Abs(brightness - B.brightness) / brightness) * (1 + Math.Abs(Area - B.Area) / Area), 2);
                    return complex;
                }
                else
                {
                    double simple = Math.Pow(ExpectedX - New.x, 2) + Math.Pow(ExpectedY - New.y, 2); //simple distance squared
                    return simple;
                }
            
            }
            else //Brownian Metric - does not predict future location
            {
                if (brightness != 0 && Area != 0 && B.Area != 0 && B.brightness != 0) //make sure that this information exists
                {
                    double complex = (Math.Pow(x - B.x, 2) + Math.Pow(y - B.y, 2)) * Math.Pow((1 + Math.Abs(brightness - B.brightness) / brightness) * (1 + Math.Abs(Area - B.Area) / Area), 2);
                    return complex;
                }
                else
                {
                    double simple = Math.Pow(x - B.x, 2) + Math.Pow(y - B.y, 2); //simple distance squared
                    return simple;
                }
            }
        }
        public void Link(Particle B)
        {
            if (FrameNumber > B.FrameNumber)
            {
                B.Future = this;
                Past = B;
            }
            if (FrameNumber < B.FrameNumber)
            {
                B.Past = this;
                Future = B;
            }
        }
                

    }
    public class ParticleTracker : WorkerThread, IInitializable
    {
        bool DoTrackParticles;
        bool UseNewlyLostParticles;
        bool EchoDebug; 
        SampleEventArgs OldFrame;
        ThreadSafeQueue<SampleEventArgs> _inQueue;

        List<Particle> LostParticles;
        List<Particle> NewlyLostParticles;
        double Reach;
        int LostHistory;

        public event SampleEventHandler FrameComplete;
        public event SampleEventHandler ReturnFrame;
        public event SampleEventHandler ReportStatus;
        //public event SampleEventHandler ReadyForFrame;
        /*
        Particle[] NewParticleNetwork;
        int NewParticleNetworkLength;
        Particle[] OldParticleNetwork;
        int OldParticleNetworkLength;
        */
        public ParticleTracker()
        {
//            NewParticleNetwork = new Particle[15];
  //          OldParticleNetwork = new Particle[15];
            
            _inQueue = new ThreadSafeQueue<SampleEventArgs>(100);

            UseNewlyLostParticles = true ;
            LostHistory = 3; //look back LostHistory number of frames for newly lost particles
            LostParticles = new List<Particle>(100);
            NewlyLostParticles = new List<Particle>(100);
            OldFrame = null;
            Reach = 100;
            EchoDebug = false;
        }

        public void Initialize()
        {        
            string threadString = "ParticleTrackThread." + this.ToString();
            CreateThread(threadString, ThreadPriority.Normal);
            StartThread();
        }
        #region Interfacing with the User Interface
        public void ReportStatusLocal(string messageout)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("Message", messageout);
            if (ReportStatus != null)
                ReportStatus(this, s);
        }
        public void OnOffSwitch(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                DoTrackParticles = (bool)sArgs.Sample["Value"];
        }
        public void Quit(object sender, SampleEventArgs sArgs)
        {
            StopThread();
        }
        public void UITrackingReachChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                Reach = Decimal.ToInt32((Decimal)sArgs.Sample["Value"]);
        }
        public void UISetStartTime(object sender, SampleEventArgs sArgs)
        {
            LostParticles.Clear();
            
        }
        #endregion

        #region WorkerThread members

        protected override void ThreadProc()
        {
            while (KeepGoing(100))                                                   // loop until quit signal
            {
                _inQueue.Wait(100);                                               // wait for a frame to be queued

                while (_inQueue.Count > 0)                                        // loop until all queued frames processed
                {
                    SampleEventArgs newFrame = _inQueue.Dequeue();
                    if (newFrame.Sample.ContainsKey("FoundParticles")) //blob finder is active and spitting out particles
                    {
                        newFrame = PointsToParticles(newFrame);
                        if (DoTrackParticles == true)
                        {
                            newFrame = TrackParticles(newFrame);
                        }
                        OldFrame = newFrame;
                        
                    }
                    OutSignals(newFrame);

                }
            }
        }
        #endregion

        public void NewParticlePacket(object sender, SampleEventArgs sArgs)
        {
            _inQueue.Enqueue(sArgs);
        }

        public SampleEventArgs PointsToParticles(SampleEventArgs s)
        {
            //looks at incoming data, builds Particle[] array from blobs most recently found. 
            //Ends by enqueuing this in the frameStack.
            
            int FrameNumber = (int)s.Sample["FrameNumber"];
            DateTime Time = (DateTime)s.Sample["Time"];

            if (s.Sample["FoundParticles"].GetType().Name == "Point[]")
            {
                Point[] FoundParticlePoints = (Point[])s.Sample["FoundParticles"];

                //List<ParticleNetwork> NetworkList = new List<ParticleNetwork>(100);

                Particle[] Particles = new Particle[FoundParticlePoints.Length];
                for (int i = 0; i < FoundParticlePoints.Length; i++)
                {
                    Particles[i] = new Particle();
                    Particles[i].x = FoundParticlePoints[i].X;
                    Particles[i].y = FoundParticlePoints[i].Y;
                    Particles[i].FrameNumber = FrameNumber;
                    Particles[i].Time = Time;
                }
                s.Sample.Add("Particles", Particles);
            }
            else if (s.Sample["FoundParticles"].GetType().Name == "Particle[]")
            {
                Particle[] Particles = (Particle[])s.Sample["FoundParticles"];
                for (int i = 0; i < Particles.Length; i++)
                {
                    Particles[i].FrameNumber = FrameNumber;
                    Particles[i].Time = Time;
                }
                s.Sample.Add("Particles", Particles);
            }
            else if (s.Sample["FoundParticles"].GetType().Name == "Blob[]")
            {
                Blob[] Blobs = (Blob[])s.Sample["FoundParticles"];
                Particle[] Particles = new Particle[Blobs.Length];
                for (int i = 0; i < Particles.Length; i++)
                {
                    Particles[i] = new Particle(Blobs[i]);
                    Particles[i].FrameNumber = FrameNumber;
                    Particles[i].Time = Time;
                }
                s.Sample.Add("Particles", Particles);
            }
            return s;
        }
        public void OutSignals(SampleEventArgs s)
        {
            if (!s.Sample.ContainsKey("LostParticles"))
                s.Sample.Add("LostParticles", LostParticles);
            if(ReturnFrame!=null)
                ReturnFrame(this, s);
            if(FrameComplete!=null)
                FrameComplete(this, s);
        }

        // guts of the particleTracker. 
        public void ScanLists(Particle Start, ref Particle[] A, ref Particle[] B, double reach)
        {
            for (int i = 0; i < A.Length; i++)
            {
                if (A[i].NetworkNumber == 0 && Start.Metric(A[i]) < reach)
                {
                    A[i].NetworkNumber = Start.NetworkNumber;
                    ScanLists(A[i],ref A,ref B, reach);
                }
            }
            for (int i = 0; i < B.Length; i++)
            {
                if (B[i].NetworkNumber == 0 && Start.Metric(B[i]) < reach)
                {
                    B[i].NetworkNumber = Start.NetworkNumber;
                    ScanLists(B[i],ref A, ref B, reach);
                }
            }
            if (UseNewlyLostParticles)
            {
                for (int i = 0; i < NewlyLostParticles.Count; i++)
                {
                    if (NewlyLostParticles[i].NetworkNumber == 0 && Start.Metric(NewlyLostParticles[i]) < reach)
                    {
                        NewlyLostParticles[i].NetworkNumber = Start.NetworkNumber;
                        ScanLists(NewlyLostParticles[i], ref A, ref B, reach);
                    }
                }
            }

           

        }
        public SampleEventArgs TrackParticles(SampleEventArgs newestFrame)
        {
            Particle[] newestParticles = (Particle[])newestFrame.Sample["Particles"];
            int FrameNumber = (int)newestFrame.Sample["FrameNumber"];

            TimeSpan TSScanLists = TimeSpan.Zero;
            TimeSpan TSCombinatorics = TimeSpan.Zero;
            DateTime TotalStart = DateTime.Now;
            if (newestParticles.Length == 0) //no particles to compare
                return(newestFrame);
            if (OldFrame == null) //don't have an older frame to compare to
                return (newestFrame);


            else
            {
                int onepair = 0, network=0, nopartner = 0, overflow= 0;
                bool FoundUnMarried;

                SampleEventArgs secondNewestFrame = OldFrame;

                Particle[] secondNewestParticles = (Particle[])secondNewestFrame.Sample["Particles"];

                if (secondNewestParticles.Length == 0)
                {
                    return (newestFrame); 
                }

                int NetworkNumber = 0;


                do
                {
                    NetworkNumber++;
                    //find an unmatched particle
                    int i = 0;
                    FoundUnMarried = false;
                    //Look for an unmarried particle in old frame
                    while (!FoundUnMarried && i < secondNewestParticles.Length)
                    {
                        if (secondNewestParticles[i].NetworkNumber == 0) FoundUnMarried = true;
                        else i++;
                    }

                    if (FoundUnMarried) // Did we find an unmarried particle in Frame1?
                    {
                        secondNewestParticles[i].NetworkNumber = NetworkNumber;
                        // look for other particles nearby
                        DateTime Start = DateTime.Now;
                        ScanLists(secondNewestParticles[i], ref newestParticles, ref secondNewestParticles, Reach);
                        TSScanLists += DateTime.Now - Start;
                    }
                    else //still haven't found a particle
                    {
                        //do the same thing for the new list of particles
                        i = 0;

                        while (!FoundUnMarried && i < newestParticles.Length) //run through new frame until we find something or run out of particles
                        {
                            if (newestParticles[i].NetworkNumber == 0) FoundUnMarried = true;
                            else i++;
                        }
                        if (FoundUnMarried)
                        {
                            newestParticles[i].NetworkNumber = NetworkNumber;
                            // look for other particles nearby
                            DateTime Start = DateTime.Now;
                            ScanLists(newestParticles[i], ref newestParticles, ref secondNewestParticles, Reach);
                            TSScanLists += DateTime.Now - Start;
                        }

                    }
                } while (FoundUnMarried); //while we keep finding new particles

                int MaxNetworkNumber = NetworkNumber-1; //-1 because our last trial network didn't find anything unmarried

                for (int i = 1; i <= MaxNetworkNumber; i++)
                {
                    int count = 0;
                    //find all particles in newestparticles that are of the same network
                    foreach (Particle P in newestParticles)
                    {
                        if (P.NetworkNumber == i)
                            count++;
                    }
                    Particle[] NewParticleNetwork = new Particle[count];//make an array for the particles in this particular network
                    count = 0;
                    foreach (Particle P in newestParticles)
                    {
                        if (P.NetworkNumber == i)
                        {
                            NewParticleNetwork[count] = P;
                            count++;
                        }
                    }
                    // do same thing for older particles
                    count = 0;
                    foreach (Particle P in secondNewestParticles)
                    {
                        if (P.NetworkNumber == i)
                            count++;
                    }
                    if (UseNewlyLostParticles)
                    {
                        for (int j = 0; j < NewlyLostParticles.Count; j++)
                        {
                            if (NewlyLostParticles[j] != null && NewlyLostParticles[j].NetworkNumber == i)
                                count++;
                        }
                    }
                                        
                    Particle[] OldParticleNetwork = new Particle[count]; //make an array for the particles in this particular network
                    count = 0;
                    foreach (Particle P in secondNewestParticles)
                    {
                        if (P.NetworkNumber == i)
                        {
                            OldParticleNetwork[count] = P;
                            count++;
                        }
                    }
                    if (UseNewlyLostParticles)
                    {
                        for (int j = 0; j < NewlyLostParticles.Count; j++)
                        {
                            if (NewlyLostParticles[j] != null && NewlyLostParticles[j].NetworkNumber == i)
                            {
                                OldParticleNetwork[count] = NewlyLostParticles[j];
                                NewlyLostParticles.RemoveAt(j); //check to make sure that this doesn't kill things
                                j--; // because we've just shrunk our list at just that point. need to recheck the jth index
                                count++;
                            }
                        }
                    }
                    //find best fit and then link the particles together;
                    DateTime Start = DateTime.Now;
                    if (OldParticleNetwork.Length == 1 && NewParticleNetwork.Length == 1) //a common enough special case, only one particle in each frame
                    {
                        OldParticleNetwork[0].Link(NewParticleNetwork[0]);
                        onepair++;
                    }
                    else if (NewParticleNetwork.Length == 0 || OldParticleNetwork.Length == 0) //one particle matched up to nothing
                    {
                        nopartner++;
                    }
                    else //interesting case
                    {
                        int[] p = ClosestPermutation(OldParticleNetwork, NewParticleNetwork, 2*Reach); //find the best mapping from one frame to the next
                        if (p[0] == -1) // error thrown by ClosestPermutation from excessive computation
                        {
                            overflow++;
                            //do nothing
                        }
                        else
                        {
                            network++;
                            EnactPermutation(OldParticleNetwork, NewParticleNetwork, p); //link past and future nodes to proper particles
                        }
                    }
                    foreach (Particle P in NewParticleNetwork)
                    {
                        if (P.Past == null)
                            NewlyLostParticles.Add(P);
                    }
                    foreach (Particle P in OldParticleNetwork)
                    {
                        if (P.Future == null)
                            NewlyLostParticles.Add(P);
                    }

                    for (int j = 0; j < NewlyLostParticles.Count; j++)
                    {
                        if (FrameNumber - NewlyLostParticles[j].FrameNumber > LostHistory) //too old
                        {
                            if (NewlyLostParticles[j].PastLength() > 10) //worth saving
                                LostParticles.Add(NewlyLostParticles[j]);
                            NewlyLostParticles.RemoveAt(j);//remove from newly lost
                        }
  
                    }

                    TSCombinatorics += DateTime.Now - Start;
                                        
                    //and onto the next network!
                }
                if(EchoDebug)
                    ReportStatusLocal("SinglePair " + onepair.ToString() + ", Network " + network.ToString() + ", noPartner " + nopartner.ToString() + ", overflow " + overflow.ToString());

                //foreach (Particle P in secondNewestParticles)
                //{
                //    if (P.Future == null && P.PastLength() > 10) //we didn't find a future particle for this fella but he has a significant past
                //    {
                //        LostParticles.Add(P); //add him to the list of all non-continuing particles
                //    }
                //}

                foreach (Particle P in newestParticles)
                    P.NetworkNumber = 0; //get ready for the next iteration when newestparticles becomes secondnewestparticles
                foreach (Particle P in NewlyLostParticles)
                    P.NetworkNumber = 0;

                newestFrame.Sample["Particles"] = newestParticles;
                newestFrame.Sample.Add("LostParticles", LostParticles);
                
                TimeSpan TSTotal = (DateTime.Now - TotalStart);
                TimeSpan TSEverythingelse = TSTotal - TSCombinatorics - TSScanLists;
                
                //ReportStatusLocal("Everything " + ((int)(TSTotal.TotalSeconds * 1000)).ToString() + ", Scanning Lists " + ((int)(TSScanLists.TotalSeconds * 1000)).ToString() + ", Combinatorics " + ((int)(TSCombinatorics.TotalSeconds * 1000)).ToString() + ", Everything else " + ((int)(TSEverythingelse.TotalSeconds*1000)).ToString());

                return(newestFrame);
            }

        }

    
        public static int[] Permutation(long index, int order)
        {
            //returns the index-th permutation of order n - used for brute force particle matching
            int[] A = new int[order];
            for (int i = 0; i < order; i++)
                A[i] = i;
            return Permutation(index, A);
        }
        public static int[] Permutation(long index, int[] A)
        {
            //returns the index-th permutation of order n - used for brute force particle matching
            //This is the recursive function that allows one to use an arbitrary starting array A, normally {0,1,2,3...}
            int n = A.Length;
            int[] OUT = new int[n];
            long spacing = factorial(n - 1);
            int SelectedIndex = (int)(index / spacing);
            OUT[0] = A[SelectedIndex];

            if (n > 1) // Need to recurse
            {

                int[] Anew = new int[n - 1];
                // construct array of numbers not yet used, ie copy A while skipping over A[SelectedIndex]
                for (int i = 0; i < SelectedIndex; i++)
                    Anew[i] = A[i];
                for (int i = SelectedIndex + 1; i < n; i++)
                    Anew[i - 1] = A[i];
                Permutation(index - (SelectedIndex) * spacing, Anew).CopyTo(OUT, 1); // Recurse on smaller system, copy elements into latter elements of OUT array.
            }
            return OUT;
        }
        public static long factorial(int i)
        {
            //computes i!
            long o = 1;
            for (; i > 1; i--)
                o *= i;
            return o;
        }
        
        public double ComputeBulkMetric(Particle[] A, Particle[] B, int[] permutation, double maxdistance)
        {
            int n = A.Length;
            double metric = 0;
            for (int i = 0; i < n; i++)
            {
                metric += Math.Min(A[i].Metric(B[permutation[i]]), maxdistance); //add the next match's distance to the total metric. We cap distances at maxdistance.
            }
            return metric;
        }
        public int[] ClosestPermutation(Particle[] FrameOneArray, Particle[] FrameTwoArray, double maxdistance)
        {
            //phantom particle used when the number of particles is not the same in frame one and frame two. 
            //ie, some particles aren't going to get paired up with any real particle, but our computations will be simpler 
            //if we give them fake ones to pretend to match up to
            Particle Ghost = new Particle();
            Ghost.x = 123456;
            Ghost.x = 123456;
            Ghost.FrameNumber = -1;

            //pad arrays
            int F1Length = FrameOneArray.Length;
            int F2Length = FrameTwoArray.Length;
            int N = Math.Max(F1Length, F2Length);

            Particle[] F1 = new Particle[N]; //our working arrays
            Particle[] F2 = new Particle[N];
            FrameOneArray.CopyTo(F1, 0);
            FrameTwoArray.CopyTo(F2, 0);
            //pad with ghosts which are Phantom particles used in the event that we have found an unequal number of particles 
            //in our two frames, ie trying to match up four particles in frame 1 to three particles in frame 2
            for (int i = F1Length; i < N; i++)
                F1[i] = Ghost;
            for (int i = F2Length; i < N; i++)
                F2[i] = Ghost;


            if (N>6) //if our system has way too many possible computations
            {
                int[] x = new int[1];
                x[0] = -1;
                return x; //return {-1} a non-physical result, which is expected on the other side as an error message
                //throw new Exception("Excessive computation required. Particles are too closely gathered and too numerous.");
            }

            int NumPermutations = (int)factorial(N);

            int ClosestPermutation = 0;
            double SmallestMetric = 1e50;//very large number, very easy to beat
            double thisMetric;
            //run through all possible permutations of the network. find the one with the smallest metric
            for (int i = 0; i < NumPermutations; i++)
            {
                thisMetric = ComputeBulkMetric(F1, F2, Permutation(i, N), maxdistance);
                if (thisMetric < SmallestMetric) // found a new best choice?
                {
                    SmallestMetric = thisMetric;
                    ClosestPermutation = i;
                }
            }
            return Permutation(ClosestPermutation, N);
        }
        public void EnactPermutation(Particle[] FrameOneArray, Particle[] FrameTwoArray, int[] permutation)
        {
            //takes a permutation and connects Past and Future nodes of Particles in our ParticleArrays
            for (int i = 0; i < FrameOneArray.Length; i++)
            {
                if (permutation[i] < FrameTwoArray.Length) // connection is valid, not linking to a ghost
                {
                    FrameOneArray[i].Link(FrameTwoArray[permutation[i]]); //connect Past and Future Nodes
                }
            }
        }
    }
}