using System;
using System.Collections.Generic;
using System.Text;
using System.Drawing;
using fftwlib;
using GoodStuff;

namespace BrownianMotion
{
    class SimulatedCamera : WorkerThread, IInitializable
    {
        public event SampleEventHandler UIUpdate;
        public event SampleEventHandler BitmapsReady;
        public event SampleEventHandler ReportStatus;
        public event SampleEventHandler FrameComplete;
        public SampleEventArgs initialArgs;
        public static DateTime StartedCapture;
        GoodVariable<Rectangle> captureRegion;
        GoodVariable<Rectangle> newCaptureRegion;

        int NumberofFramesStillProcessing; //the number of frames that we've sent out that haven't come back in yet. 
        int MaxNumberofFramesOut;
        //This number should be high for smooth processing and low for good response. 


        ThreadSafeQueue<SampleEventArgs> _bufferQueue;
        bool FancyImage;
        float[,] BackGround;
        float[,] PSF; 
        double ParticleDiameter;
        double DiffusionCoefficient;
        DateTime LastTime;
        int framenumber; 
        Particle[] CurrentParticles;

        GoodProperty<double> _diffusionCoefficient;
        int dimensions = 2;
        int _numberOfBuffers;
        public int NumberOfBuffers
        {
            get { return _numberOfBuffers; }
            set { _numberOfBuffers = value; }
        }
        private GoodVariable<Size> _maximumImageDimensions;
        public GoodVariable<Size> MaxImageDimensions
        {
            get { return _maximumImageDimensions; }
            set { _maximumImageDimensions = (GoodVariable<Size>)value; }
        }

        //PassThruForm state
        bool _shiftPressed;
        bool _controlPressed;
        Size FormPassThruSize;
        Rectangle FormPassThruClientRectangle;
        #region Interfacing with the User Interface
        public void ReportStatusLocal(string messageout)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("Message", messageout);
            if (ReportStatus != null)
                ReportStatus(this, s);
        }
        public void PassThruStateChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("ClientSize"))
                FormPassThruSize = (Size)sArgs.Sample["ClientSize"];
            if (sArgs.Sample.ContainsKey("ClientRectangle"))
                FormPassThruClientRectangle = (Rectangle)sArgs.Sample["ClientRectangle"];
        }
        public void PassThruMouseClick(object sender, SampleEventArgs sArgs)
        {
            System.Windows.Forms.MouseEventArgs mArgs;
            if (sArgs.Sample.ContainsKey("MouseArgs"))
                mArgs = (System.Windows.Forms.MouseEventArgs)sArgs.Sample["MouseArgs"];
            else
                return;

            Size max = MaxImageDimensions.Value;
            //((GoodVariable<Size>)StateStore.Store["MaximumImageDimensions"]).Value;

            if (!_shiftPressed && !_controlPressed)
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width);
                x = Math.Max(0, x);
                x = Math.Min(max.Width - captureRegion.Value.Width, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height);
                y = Math.Max(0, y);
                y = Math.Min(max.Height - captureRegion.Value.Height, y);
                newCaptureRegion.Value = new Rectangle(
                    x,
                    y,
                    captureRegion.Value.Width,
                    captureRegion.Value.Height);
            }
            else if (!_controlPressed)
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);
                newCaptureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    y);
            }
            else
            {
                int x = (mArgs.X * max.Width / FormPassThruSize.Width) - captureRegion.Value.X;
                x = Math.Max(10, x);
                int y = (mArgs.Y * max.Height / FormPassThruSize.Height) - captureRegion.Value.Y;
                y = Math.Max(10, y);

                x = Math.Max(x, y);
                x = Math.Min(Math.Min(x, max.Width - captureRegion.Value.X), max.Height - captureRegion.Value.Y);
                //y = Math.Max(x, y);
                newCaptureRegion.Value = new Rectangle(
                    captureRegion.Value.X,
                    captureRegion.Value.Y,
                    x,
                    x);
            }
            ReportStatusLocal("CaptureRegion Changed. size:" + captureRegion.Value.Width.ToString() + " by " + captureRegion.Value.Height.ToString() + " pixels");

        }
        public void PassThruKeyUpDown(object sender, SampleEventArgs sArgs)
        {
            System.Windows.Forms.KeyEventArgs kArgs;
            if (sArgs.Sample.ContainsKey("KeyArgs"))
                kArgs = (System.Windows.Forms.KeyEventArgs)sArgs.Sample["KeyArgs"];
            else
                return;
            _shiftPressed = kArgs.Shift;
            _controlPressed = kArgs.Control;
        }
        #endregion
        public void StartShotMode(object sender, SampleEventArgs sArgs)
        {
            
        }

        public SimulatedCamera()
        {
            FancyImage = false;

            framenumber = 0;
            _maximumImageDimensions = new GoodVariable<Size>();
            _maximumImageDimensions.Value = new Size(659, 493);
            _numberOfBuffers = 5;
            BackGround = new float[_maximumImageDimensions.Value.Width, _maximumImageDimensions.Value.Height];
            ParticleDiameter = 4;
            PSF = CreatePSF(3);
            DiffusionCoefficient = 1;
            InitializeParticles(100, 100);
            MaxNumberofFramesOut = 5;

            captureRegion = new GoodVariable<Rectangle>();
            captureRegion.Value = new Rectangle(0, 0, 200, 200);
            newCaptureRegion = new GoodVariable<Rectangle>();
            newCaptureRegion.Value = captureRegion.Value;
        }
        public void Initialize()
        {
            _bufferQueue = new ThreadSafeQueue<SampleEventArgs>(10);
            StartedCapture = DateTime.Now; //start the clock
            CreateThread("Simulated Camera " + " acquisition thread", System.Threading.ThreadPriority.Normal);
            StartThread();
        }
        override protected void ThreadProc()
        {
            int FrameNumber = 1;
            while (KeepGoing())
            {
                _bufferQueue.Wait(100);
                while (_bufferQueue.Count > 0)
                {
                    
                    if (BitmapsReady != null)
                        BitmapsReady(this, _bufferQueue.Dequeue());
                    else
                        _bufferQueue.Dequeue();
                }
            }
        }


        private void InitializeParticles(int NumParticles, double brightness)
        {
            CurrentParticles = new Particle[NumParticles];
            Random rand = new Random();
            double[] brightnesses = RandomNormal(NumParticles, Math.Sqrt(brightness), brightness);

            for (int i = 0; i < NumParticles; i++)
            {
                CurrentParticles[i] = new Particle();
                CurrentParticles[i].x = rand.NextDouble() * _maximumImageDimensions.Value.Width;
                CurrentParticles[i].y = rand.NextDouble() * _maximumImageDimensions.Value.Height;
                CurrentParticles[i].brightness = brightnesses[i];
            }
        }
        public void Dispose(object sender, SampleEventArgs sArgs)
        {
            this.StopThread();
        }
        public void TriggerShot(object sender, SampleEventArgs sArgs)
        {
            if (captureRegion.Value != newCaptureRegion.Value)
                captureRegion = newCaptureRegion;
            if (NumberofFramesStillProcessing >= MaxNumberofFramesOut)
                return;
            else
            {
                NumberofFramesStillProcessing++;
                _bufferQueue.Enqueue(CreateFrame());
            }
        }
        public void FrameReturned(object sender, SampleEventArgs sArgs)
        {
            if(sArgs.Sample.ContainsKey("SourceName") && sArgs.Sample["SourceName"]=="SimulatedCamera")
                NumberofFramesStillProcessing--;
        }
        public SampleEventArgs CreateFrame()
        {
            unsafe
            {
                DateTime now = DateTime.Now;
                framenumber++;
                TimeSpan ts = (now - LastTime);
                double dt = ts.TotalSeconds;
                LastTime = now;
                double sigma = Math.Sqrt(dt * DiffusionCoefficient * dimensions);
                int n = CurrentParticles.Length;
                double[] dx = RandomNormal(n, sigma);
                double[] dy = RandomNormal(n, sigma, 29837);

                //update particle locations
                for (int i = 0; i < n; i++)
                {
                    //the extra _maximumImageDimensions.Value.Width in the sum is because -1 % 5 = -1 in C# rather than 4 in the rest of the world.... <--- Note the bitterness 
                    //CurrentParticles[i].x = (CurrentParticles[i].x + dx[i] + _maximumImageDimensions.Value.Width) % _maximumImageDimensions.Value.Width; // % modular so that if a particle wanders off the side it just comes back in on the other side. 
                    CurrentParticles[i].x = mod(CurrentParticles[i].x + dx[i] ,_maximumImageDimensions.Value.Width); // % modular so that if a particle wanders off the side it just comes back in on the other side. 
                    CurrentParticles[i].y = mod(CurrentParticles[i].y + dy[i] , _maximumImageDimensions.Value.Height);
                    CurrentParticles[i].Time = now;
                    CurrentParticles[i].FrameNumber = framenumber;
                }

                //Create our Frame
                float[,] ImageArray = new float[_maximumImageDimensions.Value.Width, _maximumImageDimensions.Value.Height];
                foreach (Particle P in CurrentParticles)
                    ImageArray[(int)P.x, (int)P.y] += (float)P.brightness;

                fftweasy fft = new fftweasy();

                if (ImageArray.GetLength(0) != PSF.GetLength(0) || ImageArray.GetLength(1) != PSF.GetLength(1))
                    PSF = CreatePSF(3);
                if (FancyImage)
                {
                    ImageArray = fft.ConvolveEasy(ImageArray, PSF);
                    for (int x = 0; x < _maximumImageDimensions.Value.Width; x++)
                    {
                        for (int y = 0; y < _maximumImageDimensions.Value.Height; y++)
                        {
                            ImageArray[x, y] += BackGround[x, y];
                        }
                    }
                }

                float[,] CaptureArray = new float[captureRegion.Value.Width, captureRegion.Value.Height];
                for (int x = 0; x < captureRegion.Value.Width; x++)
                {
                    for (int y = 0; y < captureRegion.Value.Height; y++)
                    {
                        CaptureArray[x, y] = ImageArray[x + captureRegion.Value.Left, y + captureRegion.Value.Top];
                    }
                }
                byte[,] monoArray = fft.FloattoByte(CaptureArray);

                GoodVariable<Bitmap> PassThruBitmap = new GoodVariable<Bitmap>();
                PassThruBitmap.Value = fft.ToBitmap(ImageArray);
                GoodVariable<Bitmap> CaptureBitmap = new GoodVariable<Bitmap>();
                CaptureBitmap.Value = fft.ToBitmap(CaptureArray);

                SampleEventArgs outArgs = new SampleEventArgs();
                outArgs.Sample.Add("PassthruBitmap", PassThruBitmap);
                outArgs.Sample.Add("CaptureBitmap", CaptureBitmap.Value);
                outArgs.Sample.Add("CaptureRegionArray", monoArray);
                outArgs.Sample.Add("CaptureRegion", captureRegion);
                outArgs.Sample.Add("FrameNumber", framenumber);
                outArgs.Sample.Add("Time", now);
                outArgs.Sample.Add("MaximumImageDimensions", MaxImageDimensions);
                outArgs.Sample.Add("SourceName", "SimulatedCamera");
                return outArgs;
            }
            

        }

        private double[] RandomNormal(int n, double sigma, double mean)
        {
            double[] outarray = RandomNormal(n, sigma);
            for (int i = 0; i < n; i++)
                outarray[i] += mean;
            return outarray;
        }
        private double[] RandomNormal(int n, double sigma)
        {
            //returns an array sized n of normally distributed doubles mean 0, standard deviation sigma
            //http://www.wilmott.com/messageview.cfm?catid=10&threadid=29961
            //search in this thread for double GetOneGaussianByBoxMuller()
            Random r = new Random((int)DateTime.Now.Ticks);
            
            double[] outarray = new double[n];
            double x, y, r2;

            for (int i = 0; i < n; i++)
            {
                do
                {
                    x = r.NextDouble();
                    y = r.NextDouble();
                    r2 = x * x + y * y;
                } while (r2 >= 1);
                outarray[i] = sigma * x * Math.Sqrt(-2 * Math.Log(r2) / r2);
                if (r.NextDouble() > .5)
                    outarray[i] = -outarray[i];

            }
            return (outarray);
        }
        private double[] RandomNormal(int n, double sigma, int seedadditive)
        {
            //returns an array sized n of normally distributed doubles mean 0, standard deviation sigma
            //http://www.wilmott.com/messageview.cfm?catid=10&threadid=29961
            //search in this thread for double GetOneGaussianByBoxMuller()
            Random r = new Random((int)DateTime.Now.Ticks+seedadditive);

            double[] outarray = new double[n];
            double x, y, r2;

            for (int i = 0; i < n; i++)
            {
                do
                {
                    x = r.NextDouble();
                    y = r.NextDouble();
                    r2 = x * x + y * y;
                } while (r2 >= 1);
                outarray[i] = sigma*x * Math.Sqrt(-2 * Math.Log(r2) / r2);
                if (r.NextDouble() > .5)
                    outarray[i] = -outarray[i];

            }
            return (outarray);
        }


        private float[,] CreatePSF(float defocus)
        {
            
            // Create Point Spread Function - a delta function in our original data gets mapped to a smudge plus a diffraction ring
            fftweasy fft = new fftweasy();
            //Blobby object
            float[,] Gaussian = fft.Gaussian(_maximumImageDimensions.Value.Width, _maximumImageDimensions.Value.Height, 0, 0, 1, (float)ParticleDiameter);
            //Blobby object's defocus ring
            float[,] Annulus = fft.Annulus(_maximumImageDimensions.Value.Width, _maximumImageDimensions.Value.Height, 0, 0, (float)ParticleDiameter * defocus, 0, (float)ParticleDiameter * (defocus * 1.33f), .13f);
            //Point Spread Function 
            float[,] outarray = Gaussian;
            for (int x = 0; x < _maximumImageDimensions.Value.Width; x++)
            {
                for (int y = 0; y < _maximumImageDimensions.Value.Height; y++)
                {
                    outarray[x, y] += Annulus[x, y];
                }
            }
            return (outarray);
        }
        public double mod(double a, int b)
        {
            //because C# % is lame
            if (a > 0)
                return a % b;
            else
                return (Math.Ceiling((0 - a) / b) * b + a) % b;
        }

    

                
    }
}
