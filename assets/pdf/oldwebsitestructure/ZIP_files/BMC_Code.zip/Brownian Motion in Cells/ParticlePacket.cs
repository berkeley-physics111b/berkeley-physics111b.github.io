using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using GoodStuff;
using CameraDriver;
namespace BrownianMotion
{
    public class ParticlePacket
    {
        public ParticleInfo[] particleInfo;
        public Blob[] blobs;
        public Rectangle captureRegion;
        GoodNumericVariable<Byte> _threshold;
        GoodVariable<Rectangle> _captureRegion;
        GoodVariable<Bitmap> _captureBitmap;
        GoodVariable<Bitmap> _passthruBitmap;

        public ParticlePacket(ParticlePacket rPacket)
        {
            particleInfo = rPacket.particleInfo;
            blobs = rPacket.blobs;
            _threshold = rPacket.BlobThreshold;
            _captureRegion = rPacket.CaptureRegion;
            _passthruBitmap = rPacket.PassthruBitmap;
        }


        public GoodVariable<Rectangle> CaptureRegion
        {
            get
            {
                return _captureRegion;
            }
            set
            {
                _captureRegion = value;
            }
        }

        public GoodVariable<Bitmap> CaptureBitmap
        {
            get
            {
                return _captureBitmap;
            }
            set
            {
                _captureBitmap = value;
            }
        }
        public GoodVariable<Bitmap> PassthruBitmap
        {
            get
            {
                return _passthruBitmap;
            }
            set
            {
                _passthruBitmap = value;
            }
        }
        public GoodNumericVariable<Byte> BlobThreshold
        {
            get
            {
                return _threshold;
            }
            set
            {
                _threshold = value;
            }
        }

        public ParticlePacket( ParticleInfo[] pInfo, Blob[] b)
        {
            int i;
            particleInfo = new ParticleInfo[pInfo.Length];
            for (i = 0; i < pInfo.Length; i++)
            {
                particleInfo[i] = new ParticleInfo(pInfo[i]);
            }
            blobs = new Blob[b.Length];
            for (i = 0; i < b.Length; i++)
            {
                blobs[i] = new Blob(b[i]);
            }
        }


        public static System.Array ResizeArray(System.Array oldArray, int newSize)
        {
            int oldSize = oldArray.Length;
            System.Type elementType = oldArray.GetType().GetElementType();
            System.Array newArray = System.Array.CreateInstance(elementType, newSize);
            int preserveLength = System.Math.Min(oldSize, newSize);
            if (preserveLength > 0)
                System.Array.Copy(oldArray, newArray, preserveLength);
            return newArray;
        }

        public uint Min(uint intOne, uint intTwo)
        {
            uint returnVal;
            returnVal = intOne;
            if (intTwo < intOne)
            {
                returnVal = intTwo;
            }
            return returnVal;
        }

        public int[] NotEqual(ParticlePacket pPacket)
        {
            int i;
            int[] returnInt = new int[1];
            int returnIntSize = 0;
            for (i = 0; i < Min((uint)this.particleInfo.Length, (uint)pPacket.particleInfo.Length); i++)
            {
                if (this.particleInfo[i] != pPacket.particleInfo[i])
                {
                    returnInt[returnIntSize] = i;
                    returnIntSize++;
                    returnInt = (int[])ResizeArray(returnInt, returnIntSize);
                }
            }
            return returnInt;      
        }

/*        public int [] Positives()
        {
            int i;
            int[] returnInt;
            int returnIntSize = 0;
            for (i = 0; i < this.particleInfo.Length; i++)
            {
                if (this.particleInfo[i] > 0)
                {
                    returnIntSize++;
                    returnInt = (int[])ResizeArray(returnInt, returnIntSize);
                }
            }
            return returnInt;
        }
*/
 /*       public int min()
        {
            int i;
            int minn = 2 ^ 16 - 1;
            for (i = 0; i < particleInfo.Length; i++)
            {
               if(particleInfo[i] <  minn) {
                minn = particleInfo[i];
            }
          }
        }
 
        public int max()
        {
            int i;
            int maxx = 2 ^ 16 - 1;
            for (i = 0; i < particleInfo.Length; i++)
            {
               if(particleInfo[i] >  maxx)
                maxx = particleInfo[i];
            }
        }

        public int min(int[] indices)
        {
            int i;
            int minimum = 2 ^ 16 - 1;
            for (i = 0; i < indices.Length; i++)
            {
                if (particleInfo[indices[i]] < minimum)
                {
                    minimum = particleInfo[indices[i]];
                }
            }
            return minimum;
        }



        public int max(int[] indices)
        {
            int i;
            int maximum = 0;
            for (i = 0; i < indices.Length; i++)
            {
                if (particleInfo[indices[i]] > maximum)
                {
                    maximum = particleInfo[indices[i]];
                }
            }
            return maximum;
        }
*/
       /* public ParticlePacket Divide(int constant)
        {
            int i;
            ParticlePacket returnPacket = new ParticlePacket(this);
            for (i = 0; i < this.particleInfo.Length; i++)
            {
                returnPacket.particleInfo[i].Location.X = (this.particleInfo[i].Location.X)/constant;
                returnPacket.particleInfo[i].Location.Y = (this.particleInfo[i].Location.Y)/constant;
            }
            return returnPacket;
        }*/
/*
        public ParticlePacket Add(ParticlePacket pPacket)
        {
            int i;
            ParticlePacket returnPacket = new ParticlePacket(this);
            for (i = 0; i < min(pPacket.particleInfo.Length, this.particleInfo.Length); i++)
            {
                returnPacket.particleInfo[i] = this.particleInfo[i] + pPacket.particleInfo[i];
            }
        }

        public ParticlePacket Subtract(ParticlePacket pPacket)
        {
            int i;
            ParticlePacket returnPacket = new ParticlePacket(this);
            for (i = 0; i < min(pPacket.particleInfo.Length, this.particleInfo.Length); i++)
            {
                returnPacket.particleInfo[i] = this.particleInfo[i] - pPacket.particleInfo[i];
            }
        }


        */
/*        public ParticlePacket Subtract(int constant)
        {
            int i;
            ParticlePacket returnPacket = new ParticlePacket(this);
            for (i = 0; i < this.particleInfo.Length; i++)
            {
                returnPacket.particleInfo[i] = this.particleInfo[i] - constant;
            }
        }
        */

        public ParticleInfo[] ParticleInfo
        {
            get { return particleInfo; }
            set { particleInfo = value; }
        }
        public Blob[] Blobs
        {
            get { return blobs; }
            set { blobs = value; }
        }



    }

    public class ParticlePacketEventArgs : EventArgs
    {
        ParticlePacket particlePacket;

        public ParticlePacket ParticlePacket
        {
            get { return particlePacket; }
            set { particlePacket = (ParticlePacket)value; }
        }

        public ParticlePacketEventArgs(ParticlePacket pPacket)
        {
            particlePacket = pPacket;
        }
    }
    public delegate void ParticlePacketEventHandler(object sender, ParticlePacketEventArgs args);
}

