using System;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Imaging;

/* This is an FFTW implementation taken from an online source. An Easy Implementation of the fftw has been added which does not 
 * allow for various efficiencies available in fftw but is simpler to perform. Addition to the EASY functions is straightforward
 * and follows a nice pattern
 * FFTW is a particular implementation of the FFT algorithm which is freely available. More information at www.fftw.org
  */

namespace fftwlib
{
	// Various Flags used by FFTW
	#region Enums
	/// <summary>
	/// FFTW planner flags
	/// </summary>
	[Flags]
	public enum fftw_flags : uint
	{
		/// <summary>
		/// Tells FFTW to find an optimized plan by actually computing several FFTs and measuring their execution time. 
		/// Depending on your machine, this can take some time (often a few seconds). Default (0x0). 
		/// </summary>
		Measure=0,
		/// <summary>
		/// Specifies that an out-of-place transform is allowed to overwrite its 
		/// input array with arbitrary data; this can sometimes allow more efficient algorithms to be employed.
		/// </summary>
		DestroyInput=1,
		/// <summary>
		/// Rarely used. Specifies that the algorithm may not impose any unusual alignment requirements on the input/output 
		/// arrays (i.e. no SIMD). This flag is normally not necessary, since the planner automatically detects 
		/// misaligned arrays. The only use for this flag is if you want to use the guru interface to execute a given 
		/// plan on a different array that may not be aligned like the original. 
		/// </summary>
		Unaligned=2,
		/// <summary>
		/// Not used.
		/// </summary>
		ConserveMemory=4,
		/// <summary>
		/// Like Patient, but considers an even wider range of algorithms, including many that we think are 
		/// unlikely to be fast, to produce the most optimal plan but with a substantially increased planning time. 
		/// </summary>
		Exhaustive=8,
		/// <summary>
		/// Specifies that an out-of-place transform must not change its input array. 
		/// </summary>
		/// <remarks>
		/// This is ordinarily the default, 
		/// except for c2r and hc2r (i.e. complex-to-real) transforms for which DestroyInput is the default. 
		/// In the latter cases, passing PreserveInput will attempt to use algorithms that do not destroy the 
		/// input, at the expense of worse performance; for multi-dimensional c2r transforms, however, no 
		/// input-preserving algorithms are implemented and the planner will return null if one is requested.
		/// </remarks>
		PreserveInput=16,
		/// <summary>
		/// Like Measure, but considers a wider range of algorithms and often produces a �more optimal� plan 
		/// (especially for large transforms), but at the expense of several times longer planning time 
		/// (especially for large transforms).
		/// </summary>
		Patient=32,
		/// <summary>
		/// Specifies that, instead of actual measurements of different algorithms, a simple heuristic is 
		/// used to pick a (probably sub-optimal) plan quickly. With this flag, the input/output arrays 
		/// are not overwritten during planning. 
		/// </summary>
		Estimate=64
	}

	/// <summary>
	/// Defines direction of operation
	/// </summary>
	public enum fftw_direction : int
	{
		/// <summary>
		/// Computes a regular DFT
		/// </summary>
		Forward=-1,
		/// <summary>
		/// Computes the inverse DFT
		/// </summary>
		Backward=1
	}

	/// <summary>
	/// Kinds of real-to-real transforms
	/// </summary>
	public enum fftw_kind : uint 
	{
		R2HC=0, 
		HC2R=1, 
		DHT=2,
		REDFT00=3, 
		REDFT01=4,
		REDFT10=5,
		REDFT11=6,
		RODFT00=7,
		RODFT01=8, 
		RODFT10=9, 
		RODFT11=10
	}
	#endregion

	// FFTW Interop Classes
	#region Single Precision
	/// <summary>
	/// Contains the Basic Interface FFTW functions for single-precision (float) operations
	/// </summary>
	public class fftwf
	{
		/// <summary>
		/// Allocates FFTW-optimized unmanaged memory
		/// </summary>
		/// <param name="length">Amount to allocate, in bytes</param>
		/// <returns>Pointer to allocated memory</returns>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_malloc",
			 ExactSpelling = true)]
		public static extern IntPtr malloc(int length);

		/// <summary>
		/// Deallocates memory allocated by FFTW malloc
		/// </summary>
		/// <param name="mem">Pointer to memory to release</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_free",
			 ExactSpelling = true)]
		public static extern void free(IntPtr mem);

		/// <summary>
		/// Deallocates an FFTW plan and all associated resources
		/// </summary>
		/// <param name="plan">Pointer to the plan to release</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_destroy_plan",
			 ExactSpelling = true)]
		public static extern void destroy_plan(IntPtr plan);

		/// <summary>
		/// Clears all memory used by FFTW, resets it to initial state. Does not replace destroy_plan and free
		/// </summary>
		/// <remarks>After calling fftw_cleanup, all existing plans become undefined, and you should not 
		/// attempt to execute them nor to destroy them. You can however create and execute/destroy new plans, 
		/// in which case FFTW starts accumulating wisdom information again. 
		/// fftw_cleanup does not deallocate your plans; you should still call fftw_destroy_plan for this purpose.</remarks>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_cleanup",
			 ExactSpelling = true)]
		public static extern void cleanup();

		/// <summary>
		/// Sets the maximum time that can be used by the planner.
		/// </summary>
		/// <param name="seconds">Maximum time, in seconds.</param>
		/// <remarks>This function instructs FFTW to spend at most seconds seconds (approximately) in the planner. 
		/// If seconds == -1.0 (the default value), then planning time is unbounded. 
		/// Otherwise, FFTW plans with a progressively wider range of algorithms until the the given time limit is 
		/// reached or the given range of algorithms is explored, returning the best available plan. For example, 
		/// specifying fftw_flags.Patient first plans in Estimate mode, then in Measure mode, then finally (time 
		/// permitting) in Patient. If fftw_flags.Exhaustive is specified instead, the planner will further progress to 
		/// Exhaustive mode. 
		/// </remarks>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_set_timelimit",
			 ExactSpelling = true)]
		public static extern void set_timelimit(double seconds);

		/// <summary>
		/// Executes an FFTW plan, provided that the input and output arrays still exist
		/// </summary>
		/// <param name="plan">Pointer to the plan to execute</param>
		/// <remarks>execute (and equivalents) is the only function in FFTW guaranteed to be thread-safe.</remarks>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_execute",
			 ExactSpelling = true)]
		public static extern void execute(IntPtr plan);
		
		/// <summary>
		/// Creates a plan for a 1-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="n">The logical size of the transform</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_1d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_1d(int n, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="nx">The logical size of the transform along the first dimension</param>
		/// <param name="ny">The logical size of the transform along the second dimension</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_2d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_2d(int nx, int ny, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 3-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="nx">The logical size of the transform along the first dimension</param>
		/// <param name="ny">The logical size of the transform along the second dimension</param>
		/// <param name="nz">The logical size of the transform along the third dimension</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_3d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the logical size along each dimension</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft",
			 ExactSpelling = true)]
		public static extern IntPtr dft(int rank, int[] n, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 1-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="n">Number of REAL (input) elements in the transform</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_r2c_1d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c_1d(int n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="nx">Number of REAL (input) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (input) elements in the transform along the second dimension</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_r2c_2d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c_2d(int nx, int ny, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 3-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="nx">Number of REAL (input) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (input) elements in the transform along the second dimension</param>
		/// <param name="nz">Number of REAL (input) elements in the transform along the third dimension</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_r2c_3d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the number of REAL (input) elements along each dimension</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_r2c",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c(int rank, int[] n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 1-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="n">Number of REAL (output) elements in the transform</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_c2r_1d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r_1d(int n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="nx">Number of REAL (output) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (output) elements in the transform along the second dimension</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_c2r_2d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r_2d(int nx, int ny, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 3-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="nx">Number of REAL (output) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (output) elements in the transform along the second dimension</param>
		/// <param name="nz">Number of REAL (output) elements in the transform along the third dimension</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_c2r_3d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the number of REAL (output) elements along each dimension</param>
		/// <param name="input">Pointer to an array of 8-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_dft_c2r",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r(int rank, int[] n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 1-dimensional real-to-real DFT
		/// </summary>
		/// <param name="n">Number of elements in the transform</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="kind">The kind of real-to-real transform to compute</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_r2r_1d",
			 ExactSpelling = true)]
		public static extern IntPtr r2r_1d(int n, IntPtr input, IntPtr output, fftw_kind kind, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional real-to-real DFT
		/// </summary>
		/// <param name="nx">Number of elements in the transform along the first dimension</param>
		/// <param name="ny">Number of elements in the transform along the second dimension</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="kindx">The kind of real-to-real transform to compute along the first dimension</param>
		/// <param name="kindy">The kind of real-to-real transform to compute along the second dimension</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_r2r_2d",
			 ExactSpelling = true)]
		public static extern IntPtr r2r_2d(int nx, int ny, IntPtr input, IntPtr output, 
			fftw_kind kindx, fftw_kind kindy, fftw_flags flags);
		
		/// <summary>
		/// Creates a plan for a 3-dimensional real-to-real DFT
		/// </summary>
		/// <param name="nx">Number of elements in the transform along the first dimension</param>
		/// <param name="ny">Number of elements in the transform along the second dimension</param>
		/// <param name="nz">Number of elements in the transform along the third dimension</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="kindx">The kind of real-to-real transform to compute along the first dimension</param>
		/// <param name="kindy">The kind of real-to-real transform to compute along the second dimension</param>
		/// <param name="kindz">The kind of real-to-real transform to compute along the third dimension</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_r2r_3d",
			 ExactSpelling = true)]
		public static extern IntPtr r2r_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, 
			fftw_kind kindx, fftw_kind kindy, fftw_kind kindz, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional real-to-real DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the number of elements in the transform along each dimension</param>
		/// <param name="input">Pointer to an array of 4-byte real numbers</param>
		/// <param name="output">Pointer to an array of 4-byte real numbers</param>
		/// <param name="kind">An array containing the kind of real-to-real transform to compute along each dimension</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_plan_r2r",
			 ExactSpelling = true)]
		public static extern IntPtr r2r(int rank, int[] n, IntPtr input, IntPtr output, 
			fftw_kind[] kind, fftw_flags flags);

		/// <summary>
		/// Returns (approximately) the number of flops used by a certain plan
		/// </summary>
		/// <param name="plan">The plan to measure</param>
		/// <param name="add">Reference to double to hold number of adds</param>
		/// <param name="mul">Reference to double to hold number of muls</param>
		/// <param name="fma">Reference to double to hold number of fmas (fused multiply-add)</param>
		/// <remarks>Total flops ~= add+mul+2*fma or add+mul+fma if fma is supported</remarks>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_flops",
			 ExactSpelling = true)]
		public static extern void flops(IntPtr plan, ref double add, ref double mul, ref double fma);

		/// <summary>
		/// Outputs a "nerd-readable" version of the specified plan to stdout
		/// </summary>
		/// <param name="plan">The plan to output</param>
		[DllImport("libfftw3f-3.dll",
			 EntryPoint = "fftwf_print_plan",
			 ExactSpelling = true)]
		public static extern void print_plan(IntPtr plan);
	}
	#endregion

	#region Double Precision
	/// <summary>
	/// Contains the Basic Interface FFTW functions for double-precision (double) operations
	/// </summary>
	public class fftw
	{
		/// <summary>
		/// Allocates FFTW-optimized unmanaged memory
		/// </summary>
		/// <param name="length">Amount to allocate, in bytes</param>
		/// <returns>Pointer to allocated memory</returns>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_malloc",
			 ExactSpelling = true)]
		public static extern IntPtr malloc(int length);
        
		/// <summary>
		/// Deallocates memory allocated by FFTW malloc
		/// </summary>
		/// <param name="mem">Pointer to memory to release</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_free",
			 ExactSpelling = true)]
		public static extern void free(IntPtr mem);

		/// <summary>
		/// Deallocates an FFTW plan and all associated resources
		/// </summary>
		/// <param name="plan">Pointer to the plan to release</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_destroy_plan",
			 ExactSpelling = true)]
		public static extern void destroy_plan(IntPtr plan);

		/// <summary>
		/// Clears all memory used by FFTW, resets it to initial state. Does not replace destroy_plan and free
		/// </summary>
		/// <remarks>After calling fftw_cleanup, all existing plans become undefined, and you should not 
		/// attempt to execute them nor to destroy them. You can however create and execute/destroy new plans, 
		/// in which case FFTW starts accumulating wisdom information again. 
		/// fftw_cleanup does not deallocate your plans; you should still call fftw_destroy_plan for this purpose.</remarks>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_cleanup",
			 ExactSpelling = true)]
		public static extern void cleanup();

		/// <summary>
		/// Sets the maximum time that can be used by the planner.
		/// </summary>
		/// <param name="seconds">Maximum time, in seconds.</param>
		/// <remarks>This function instructs FFTW to spend at most seconds seconds (approximately) in the planner. 
		/// If seconds == -1.0 (the default value), then planning time is unbounded. 
		/// Otherwise, FFTW plans with a progressively wider range of algorithms until the the given time limit is 
		/// reached or the given range of algorithms is explored, returning the best available plan. For example, 
		/// specifying fftw_flags.Patient first plans in Estimate mode, then in Measure mode, then finally (time 
		/// permitting) in Patient. If fftw_flags.Exhaustive is specified instead, the planner will further progress to 
		/// Exhaustive mode. 
		/// </remarks>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_set_timelimit",
			 ExactSpelling = true)]
		public static extern void set_timelimit(double seconds);

		/// <summary>
		/// Executes an FFTW plan, provided that the input and output arrays still exist
		/// </summary>
		/// <param name="plan">Pointer to the plan to execute</param>
		/// <remarks>execute (and equivalents) is the only function in FFTW guaranteed to be thread-safe.</remarks>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_execute",
			 ExactSpelling = true)]
		public static extern void execute(IntPtr plan);
		
		/// <summary>
		/// Creates a plan for a 1-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="n">The logical size of the transform</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_1d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_1d(int n, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="nx">The logical size of the transform along the first dimension</param>
		/// <param name="ny">The logical size of the transform along the second dimension</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_2d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_2d(int nx, int ny, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 3-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="nx">The logical size of the transform along the first dimension</param>
		/// <param name="ny">The logical size of the transform along the second dimension</param>
		/// <param name="nz">The logical size of the transform along the third dimension</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_3d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional complex-to-complex DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the logical size along each dimension</param>
		/// <param name="direction">Specifies the direction of the transform</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft",
			 ExactSpelling = true)]
		public static extern IntPtr dft(int rank, int[] n, IntPtr input, IntPtr output, 
			fftw_direction direction, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 1-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="n">Number of REAL (input) elements in the transform</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_r2c_1d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c_1d(int n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="nx">Number of REAL (input) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (input) elements in the transform along the second dimension</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_r2c_2d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c_2d(int nx, int ny, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 3-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="nx">Number of REAL (input) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (input) elements in the transform along the second dimension</param>
		/// <param name="nz">Number of REAL (input) elements in the transform along the third dimension</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_r2c_3d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional real-to-complex DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the number of REAL (input) elements along each dimension</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_r2c",
			 ExactSpelling = true)]
		public static extern IntPtr dft_r2c(int rank, int[] n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 1-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="n">Number of REAL (output) elements in the transform</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_c2r_1d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r_1d(int n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="nx">Number of REAL (output) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (output) elements in the transform along the second dimension</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_c2r_2d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r_2d(int nx, int ny, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 3-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="nx">Number of REAL (output) elements in the transform along the first dimension</param>
		/// <param name="ny">Number of REAL (output) elements in the transform along the second dimension</param>
		/// <param name="nz">Number of REAL (output) elements in the transform along the third dimension</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_c2r_3d",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional complex-to-real DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the number of REAL (output) elements along each dimension</param>
		/// <param name="input">Pointer to an array of 16-byte complex numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_dft_c2r",
			 ExactSpelling = true)]
		public static extern IntPtr dft_c2r(int rank, int[] n, IntPtr input, IntPtr output, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 1-dimensional real-to-real DFT
		/// </summary>
		/// <param name="n">Number of elements in the transform</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="kind">The kind of real-to-real transform to compute</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_r2r_1d",
			 ExactSpelling = true)]
		public static extern IntPtr r2r_1d(int n, IntPtr input, IntPtr output, fftw_kind kind, fftw_flags flags);

		/// <summary>
		/// Creates a plan for a 2-dimensional real-to-real DFT
		/// </summary>
		/// <param name="nx">Number of elements in the transform along the first dimension</param>
		/// <param name="ny">Number of elements in the transform along the second dimension</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="kindx">The kind of real-to-real transform to compute along the first dimension</param>
		/// <param name="kindy">The kind of real-to-real transform to compute along the second dimension</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_r2r_2d",
			 ExactSpelling = true)]
		public static extern IntPtr r2r_2d(int nx, int ny, IntPtr input, IntPtr output, 
			fftw_kind kindx, fftw_kind kindy, fftw_flags flags);
		
		/// <summary>
		/// Creates a plan for a 3-dimensional real-to-real DFT
		/// </summary>
		/// <param name="nx">Number of elements in the transform along the first dimension</param>
		/// <param name="ny">Number of elements in the transform along the second dimension</param>
		/// <param name="nz">Number of elements in the transform along the third dimension</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="kindx">The kind of real-to-real transform to compute along the first dimension</param>
		/// <param name="kindy">The kind of real-to-real transform to compute along the second dimension</param>
		/// <param name="kindz">The kind of real-to-real transform to compute along the third dimension</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_r2r_3d",
			 ExactSpelling = true)]
		public static extern IntPtr r2r_3d(int nx, int ny, int nz, IntPtr input, IntPtr output, 
			fftw_kind kindx, fftw_kind kindy, fftw_kind kindz, fftw_flags flags);

		/// <summary>
		/// Creates a plan for an n-dimensional real-to-real DFT
		/// </summary>
		/// <param name="rank">Number of dimensions</param>
		/// <param name="n">Array containing the number of elements in the transform along each dimension</param>
		/// <param name="input">Pointer to an array of 8-byte real numbers</param>
		/// <param name="output">Pointer to an array of 8-byte real numbers</param>
		/// <param name="kind">An array containing the kind of real-to-real transform to compute along each dimension</param>
		/// <param name="flags">Flags that specify the behavior of the planner</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_plan_r2r",
			 ExactSpelling = true)]
		public static extern IntPtr r2r(int rank, int[] n, IntPtr input, IntPtr output, 
			fftw_kind[] kind, fftw_flags flags);

		/// <summary>
		/// Returns (approximately) the number of flops used by a certain plan
		/// </summary>
		/// <param name="plan">The plan to measure</param>
		/// <param name="add">Reference to double to hold number of adds</param>
		/// <param name="mul">Reference to double to hold number of muls</param>
		/// <param name="fma">Reference to double to hold number of fmas (fused multiply-add)</param>
		/// <remarks>Total flops ~= add+mul+2*fma or add+mul+fma if fma is supported</remarks>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_flops",
			 ExactSpelling = true)]
		public static extern void flops(IntPtr plan, ref double add, ref double mul, ref double fma);

		/// <summary>
		/// Outputs a "nerd-readable" version of the specified plan to stdout
		/// </summary>
		/// <param name="plan">The plan to output</param>
		[DllImport("libfftw3-3.dll",
			 EntryPoint = "fftw_print_plan",
			 ExactSpelling = true)]
		public static extern void print_plan(IntPtr plan);
	}
	#endregion

    //Easy FFTW implementation
    //FFTW for dumb people (includes the author)
    #region Easy
    public class fftweasy
    {
        //the r2c and c2r functions are not functional. DO NOT USE.
        unsafe public double[, ,] fft2easyr2c(double[,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects real values for input and 
            //complex values for output
            //Assumed forward direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);
            double[, ,] output2 = new double[nx, ny, 2]; // our final output array

            IntPtr input2;// pointers to locations in memory that the fft is actually going to work on. Distinct from our input and output variables
            IntPtr output;
            input2 = fftw.malloc(nx * ny * 8); //Allocate some space in memory for the fft to play in
            double* scanningpointer = (double*)input2; //create a new pointer that will scan over our space in memory
            output = fftw.malloc(nx * ny * 8 * 2); //sizex, sizey, double precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    *scanningpointer++ = input[x, y]; //write our incoming data onto the space in memory that our fft is actually going to work on
                }
            }

            IntPtr fftwplan = fftw.dft_r2c_2d(nx, ny, input2, output, fftw_flags.Estimate); //Create a plan that we are about to execute.
            fftw.execute(fftwplan); //perform calculations
            scanningpointer = (double*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        output2[x, y, c] = *scanningpointer++; //write our space in memory to a normal array that we can then send out
                        //scanningpointer += 8;
                    }
                }
            }
               // Release allocated memory
            fftw.free(input2);
            fftw.free(output);
            fftw.destroy_plan(fftwplan);
            return (output2);
        }
        unsafe public float[, ,] fft2easyr2c(float[,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects real values for input and 
            //complex values for output
            //Assumed forward direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);
            float[, ,] output2 = new float[nx, ny, 2]; // our final output array

            IntPtr input2;// pointers to locations in memory that the fft is actually going to work on. Distinct from our input and output variables
            IntPtr output;
            input2 = fftwf.malloc(nx * ny * 4);
            float* scanningpointer = (float*)input2;
            output = fftwf.malloc(nx * ny * 4 * 2); //sizex, sizey, single precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    *scanningpointer++ = input[x, y];
                }
            }

            IntPtr fftwplan = fftwf.dft_r2c_2d(nx, ny, input2, output, fftw_flags.Estimate);
            fftwf.execute(fftwplan);

            scanningpointer = (float*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny/2; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        output2[x, y, c] = *scanningpointer;
                        output2[x, y+ny/2 , c] = *scanningpointer;
                        scanningpointer++;
                    }
                }
            }

            fftwf.free(input2);
            fftwf.free(output);
            fftwf.destroy_plan(fftwplan);
            return (output2);
        }
        unsafe public double[,] fft2easyc2r(double[, ,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects complex values for input and 
            //real values for output
            //Assumed forward direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);
            double[,] output2 = new double[nx, ny];

            IntPtr input2;
            IntPtr output;
            input2 = fftw.malloc(nx * ny * 8 * 2);
            double* scanningpointer = (double*)input2;
            output = fftw.malloc(nx * ny * 8); //sizex, sizey, double precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        *scanningpointer++ = input[x, y, c];
                    }
                }
            }

            //double[,] output = new double[nx, ny];
            // GCHandle hin = GCHandle.Alloc(input, GCHandleType.Pinned);
            //GCHandle hout = GCHandle.Alloc(output, GCHandleType.Pinned);
            IntPtr fftwplan = fftw.dft_c2r_2d(nx, ny, input2, output, fftw_flags.Estimate);
            fftw.execute(fftwplan);
            //fftw.destroy_plan(fftwplan);
            //hout.Free();
            //hin.Free();
            scanningpointer = (double*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    output2[x, y] = (*scanningpointer++) / (nx * ny);
                }
            }

            fftwf.free(input2);
            fftwf.free(output);
            fftwf.destroy_plan(fftwplan);
            return (output2);
        }
        unsafe public float[,] fft2easyc2r(float[, ,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects complex values for input and 
            //real values for output
            //Assumed forward direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);
            float[,] output2 = new float[nx, ny];

            IntPtr input2;
            IntPtr output;
            input2 = fftwf.malloc(nx * ny * 4 * 2);
            float* scanningpointer = (float*)input2;
            output = fftwf.malloc(nx * ny * 4); //sizex, sizey, single precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        *scanningpointer++ = input[x, y, c];
                    }
                }
            }

            //double[,] output = new double[nx, ny];
            // GCHandle hin = GCHandle.Alloc(input, GCHandleType.Pinned);
            //GCHandle hout = GCHandle.Alloc(output, GCHandleType.Pinned);
            IntPtr fftwplan = fftwf.dft_c2r_2d(nx, ny, input2, output, fftw_flags.Estimate);
            fftwf.execute(fftwplan);
            //fftw.destroy_plan(fftwplan);
            //hout.Free();
            //hin.Free();
            scanningpointer = (float*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    output2[x, y] = (*scanningpointer++) / (nx * ny);
                }
            }

            fftwf.free(input2);
            fftwf.free(output);
            fftwf.destroy_plan(fftwplan);
            return (output2);
        }
        unsafe public double[, ,] fft2easy(double[, ,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects complex values for both incoming and outgoing data
            //Assumed forward direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);

            double[, ,] output2 = new double[nx, ny, 2];

            IntPtr input2;
            IntPtr output;
            input2 = fftw.malloc(nx * ny * 8 * 2); //sizex, sizey, double precision, complex
            double* scanningpointer = (double*)input2;
            output = fftw.malloc(nx * ny * 8 * 2); //sizex, sizey, double precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        *scanningpointer++ = input[x, y, c];
                        //scanningpointer += 8;
                    }
                }
            }

            //double[,] output = new double[nx, ny];
            // GCHandle hin = GCHandle.Alloc(input, GCHandleType.Pinned);
            //GCHandle hout = GCHandle.Alloc(output, GCHandleType.Pinned);
            IntPtr fftwplan = fftw.dft_2d(nx, ny, input2, output, fftw_direction.Forward, fftw_flags.Estimate);
            fftw.execute(fftwplan);
            //fftw.destroy_plan(fftwplan);
            //hout.Free();
            //hin.Free();
            scanningpointer = (double*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        output2[x, y, c] = *scanningpointer++;
                        //scanningpointer += 8;
                    }
                }
            }
            fftw.free(input2);
            fftw.free(output);
            fftw.destroy_plan(fftwplan);
            return (output2);
        }
        unsafe public float[, ,] fft2easy(float[, ,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects complex values for both incoming and outgoing data
            //Assumed forward direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);

            float[, ,] output2 = new float[nx, ny, 2];

            IntPtr input2;
            IntPtr output;
            input2 = fftwf.malloc(nx * ny * 4 * 2); //sizex, sizey, single precision, complex
            float* scanningpointer = (float*)input2;
            output = fftwf.malloc(nx * ny * 4 * 2); //sizex, sizey, single precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        *scanningpointer++ = input[x, y, c];
                        //scanningpointer += 8;
                    }
                }
            }

            //double[,] output = new double[nx, ny];
            // GCHandle hin = GCHandle.Alloc(input, GCHandleType.Pinned);
            //GCHandle hout = GCHandle.Alloc(output, GCHandleType.Pinned);
            IntPtr fftwplan = fftwf.dft_2d(nx, ny, input2, output, fftw_direction.Forward, fftw_flags.Estimate);
            fftwf.execute(fftwplan);
            //fftw.destroy_plan(fftwplan);
            //hout.Free();
            //hin.Free();
            scanningpointer = (float*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        output2[x, y, c] = *scanningpointer++;
                        //scanningpointer += 8;
                    }
                }
            }
            fftwf.free(input2);
            fftwf.free(output);
            fftwf.destroy_plan(fftwplan);
            return (output2);
        }
        unsafe public double[, ,] fft2easyinverse(double[, ,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects complex values for both incoming and outgoing data
            //Assumed backwards direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);

            double[, ,] output2 = new double[nx, ny, 2];

            IntPtr input2;
            IntPtr output;
            input2 = fftw.malloc(nx * ny * 8 * 2); //sizex, sizey, double precision, complex
            double* scanningpointer = (double*)input2;
            output = fftw.malloc(nx * ny * 8 * 2); //sizex, sizey, double precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        *scanningpointer++ = input[x, y, c];
                        //scanningpointer += 8;
                    }
                }
            }

            //double[,] output = new double[nx, ny];
            // GCHandle hin = GCHandle.Alloc(input, GCHandleType.Pinned);
            //GCHandle hout = GCHandle.Alloc(output, GCHandleType.Pinned);
            IntPtr fftwplan = fftw.dft_2d(nx, ny, input2, output, fftw_direction.Backward, fftw_flags.Estimate);
            fftw.execute(fftwplan);
            //fftw.destroy_plan(fftwplan);
            //hout.Free();
            //hin.Free();
            scanningpointer = (double*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        output2[x, y, c] = (*scanningpointer++) / (nx * ny);
                        //scanningpointer += 8;
                    }
                }
            }
            fftw.free(input2);
            fftw.free(output);
            fftw.destroy_plan(fftwplan);
            return (output2);
        }
        unsafe public float[, ,] fft2easyinverse(float[, ,] input)
        {
            //easy implementation of fftw's fft that is 2d and expects complex values for both incoming and outgoing data
            //Assumed backwards direction
            int nx = input.GetLength(0);
            int ny = input.GetLength(1);

            float[, ,] output2 = new float[nx, ny, 2];

            IntPtr input2;
            IntPtr output;
            input2 = fftwf.malloc(nx * ny * 4 * 2); //sizex, sizey, single precision, complex
            float* scanningpointer = (float*)input2;
            output = fftwf.malloc(nx * ny * 4 * 2); //sizex, sizey, single precision, complex
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        *scanningpointer++ = input[x, y, c];
                        //scanningpointer += 8;
                    }
                }
            }

            //double[,] output = new double[nx, ny];
            // GCHandle hin = GCHandle.Alloc(input, GCHandleType.Pinned);
            //GCHandle hout = GCHandle.Alloc(output, GCHandleType.Pinned);
            IntPtr fftwplan = fftwf.dft_2d(nx, ny, input2, output, fftw_direction.Backward, fftw_flags.Estimate);
            fftwf.execute(fftwplan);
            //fftw.destroy_plan(fftwplan);
            //hout.Free();
            //hin.Free();
            scanningpointer = (float*)output;
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int c = 0; c < 2; c++)
                    {
                        output2[x, y, c] = (*scanningpointer++) / (nx * ny);
                        //scanningpointer += 8;
                    }
                }
            }
            fftwf.free(input2);
            fftwf.free(output);
            fftwf.destroy_plan(fftwplan);
            return (output2);
        }
        public double[,] ConvolveEasy(double[,] A, double[,] B)
        {
            //Convolves two equally sized arrays A and B into each other and returns the real result
            //Currently no sanity checks
            //We reuse the same place in memory Afft is both a temp and our output
            double[, ,] Afft = fft2easy(realtocomplex(A));
            double[, ,] Bfft = fft2easy(realtocomplex(B));
            double r, c;
            for (int x = 0; x < A.GetLength(0); x++)
            {
                for (int y = 0; y < A.GetLength(1); y++)
                {
                    r = Afft[x, y, 0] * Bfft[x, y, 0] - Afft[x, y, 1] * Bfft[x, y, 1]; //A_real * B_real - A_imag * B_imag
                    c = Afft[x, y, 0] * Bfft[x, y, 1] + Afft[x, y, 1] * Bfft[x, y, 0]; //A_real * B_imag + A_imag * B_real
                    Afft[x, y, 0] = r;
                    Afft[x, y, 1] = c;
                }
            } 
            return (complextoreal(fft2easyinverse(Afft)));
        }
        public float[,] ConvolveEasy(float[,] A, float[,] B)
        {
            //Convolves two equally sized arrays A and B into each other and returns the real result
            //Currently no sanity checks
            //float[, ,] Afft = fft2easyr2c(A);
            //float[, ,] Bfft = fft2easyr2c(B);
            float[, ,] Afft = fft2easy(realtocomplex(A));
            float[, ,] Bfft = fft2easy(realtocomplex(B));
           // float[, ,] Cfft = new float[Afft.GetLength(0), Afft.GetLength(1), 2];
            float r, c;
            for (int x = 0; x < A.GetLength(0); x++)
            {
                for (int y = 0; y < A.GetLength(1); y++)
                {
                    r = Afft[x, y, 0] * Bfft[x, y, 0] - Afft[x, y, 1] * Bfft[x, y, 1]; //A_real * B_real - A_imag * B_imag
                    c = Afft[x, y, 0] * Bfft[x, y, 1] + Afft[x, y, 1] * Bfft[x, y, 0]; //A_real * B_imag + A_imag * B_real
                    Afft[x, y, 0] = r;
                    Afft[x, y, 1] = c; 
                }
            } 
            return (complextoreal(fft2easyinverse(Afft)));
        }
        public double[,] CorrelateEasy(double[,] A, double[,] B)
        {
            //Correlates two equally sized arrays A and B into each other and returns the real result
            //Currently no sanity checks
            //Correlate is just ifft(fft(A)*conj(fft(b)))
            double[, ,] Afft = fft2easy(realtocomplex(A));
            double[, ,] Bfft = fft2easy(realtocomplex(B));
            double r, c;
            for (int x = 0; x < A.GetLength(0); x++)
            {
                for (int y = 0; y < A.GetLength(1); y++)
                {
                    r = Afft[x, y, 0] * Bfft[x, y, 0] - Afft[x, y, 1] * -Bfft[x, y, 1]; //A_real * B_real - A_imag * -B_imag
                    c = Afft[x, y, 0] * -Bfft[x, y, 1] + Afft[x, y, 1] * Bfft[x, y, 0]; //A_real * -B_imag + A_imag * B_real
                    Afft[x, y, 0] = r;
                    Afft[x, y, 1] = c; 
                }
            }
            return (complextoreal(fft2easyinverse(Afft)));
        }
        public float[,] CorrelateEasy(float[,] A, float[,] B)
        {
            //Correlates two equally sized arrays A and B into each other and returns the real result
            //Currently no sanity checks
            //Correlate is just ifft(fft(A)*conj(fft(b)))
            float[, ,] Afft = fft2easy(realtocomplex(A));
            float[, ,] Bfft = fft2easy(realtocomplex(B));
            float r, c;
            for (int x = 0; x < A.GetLength(0); x++)
            {
                for (int y = 0; y < A.GetLength(1); y++)
                {
                    r = Afft[x, y, 0] * Bfft[x, y, 0] - Afft[x, y, 1] * -Bfft[x, y, 1]; //A_real * B_real - A_imag * -B_imag
                    c = Afft[x, y, 0] * -Bfft[x, y, 1] + Afft[x, y, 1] * Bfft[x, y, 0]; //A_real * -B_imag + A_imag * B_real
                    Afft[x, y, 0] = r;
                    Afft[x, y, 1] = c;
                }
            }
            return (complextoreal(fft2easyinverse(Afft)));
        }
        public float[, ,] realtocomplex(float[,] A)
        {
            int nx = A.GetLength(0);
            int ny = A.GetLength(1);

            float[, ,] output = new float[nx, ny, 2];
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    output[x, y, 0] = A[x, y];
                }
            }
            return (output);
        }
        public double[, ,] realtocomplex(double[,] A)
        {
            int nx = A.GetLength(0);
            int ny = A.GetLength(1);

            double[, ,] output = new double[nx, ny, 2];
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    output[x, y, 0] = A[x, y];
                }
            }
            return (output);
        }
        public float[,] complextoreal(float[, ,] A)
        {
            int nx = A.GetLength(0);
            int ny = A.GetLength(1);

            float[,] output = new float[nx, ny];
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    output[x, y] = A[x, y, 0];
                }
            }
            return (output);
        }
        public double[,] complextoreal(double[, ,] A)
        {
            int nx = A.GetLength(0);
            int ny = A.GetLength(1);

            double[,] output = new double[nx, ny];
            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    output[x, y] = A[x, y, 0];
                }
            }
            return (output);
        }
        public byte[,,] FromBitmap(Bitmap inputImage)
        {
            //converts a Bitmap into a Byte[x,y,c] array
            //assumes that the bitmap is saved at RGB 24 bits - what normally comes out of paint and such
            int Width = inputImage.Width;
            int Height = inputImage.Height;
            Byte[,,] outArray = new Byte[Width, Height,3];
            
            unsafe
            {
                BitmapData bd = inputImage.LockBits(
                    new Rectangle(0, 0, inputImage.Width, inputImage.Height),
                    ImageLockMode.ReadOnly,
                    PixelFormat.Format24bppRgb);

                Byte * firstPixel = (Byte*)bd.Scan0;
                Byte* pixel = firstPixel;

                //System.Runtime.InteropServices.Marshal.Copy(bd.Scan0, outArray, 0, Width * Height * 3);

                for (int x = 0; x < Width; x++)
                {
                    for (int y = 0; y < Height; y++)
                    {
                        for (int c = 0; c < 3; c++)
                        {
                            outArray[x, y, c] = *pixel++;
                        }
                    }
                }
                inputImage.UnlockBits(bd); 
            }
             
             return outArray;
        }
        public Bitmap ToBitmap(byte[,,] inArray)
        {
            //converts a byte array into a bitmap of the same size
            //assumes that the bitmap is saved at RGB 24 bits - what normally comes out of paint and such
            int Width = inArray.GetLength(0);
            int Height = inArray.GetLength(1);
            Bitmap outputBitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
            unsafe
            {
                
                BitmapData bd = outputBitmap.LockBits(
                    new Rectangle(0, 0, outputBitmap.Width, outputBitmap.Height),
                    ImageLockMode.WriteOnly,
                    PixelFormat.Format24bppRgb);
                Byte* firstPixel = (Byte*)bd.Scan0;
                Byte* pixel = firstPixel;
                int padding = bd.Stride - bd.Width;
                for (int y = 0; y < Height; y++)
                {
                    for (int x = 0; x < Width; x++)
                    {
                        for (int c = 0; c < 3; c++)
                        {
                            *pixel++ = inArray[x, y, c];
                        }
                    }
                    pixel += padding;
                }
                outputBitmap.UnlockBits(bd);

            }
            return outputBitmap;
        }
        public Bitmap ToBitmap(byte[,] inArray)
        {
            //converts a byte array into a bitmap of the same size
            //assumes that the bitmap is saved at 8 bit greyscale
            int Width = inArray.GetLength(0);
            int Height = inArray.GetLength(1);
            Bitmap outputBitmap = new Bitmap(Width, Height, PixelFormat.Format8bppIndexed);
            SetMonochromePalette(outputBitmap);
            unsafe
            {

                BitmapData bd = outputBitmap.LockBits(
                    new Rectangle(0, 0, outputBitmap.Width, outputBitmap.Height),
                    ImageLockMode.WriteOnly,
                    PixelFormat.Format8bppIndexed);
                Byte* firstPixel = (Byte*)bd.Scan0;
                Byte* pixel = firstPixel;
                int padding = bd.Stride - bd.Width;
                for (int y = 0; y < Height; y++)
                {
                    for (int x = 0; x < Width; x++)
                    {
                        *pixel++ = inArray[x, y];
                    }
                    pixel += padding;
                }
                outputBitmap.UnlockBits(bd);

            }
            return outputBitmap;
        }
        public float ArrayMin(float[,] inArray)
        {
            float min = inArray[0, 0];
            foreach (float f in inArray)
                if (f < min)
                    min = f;
            return min;
        }
        public double ArrayMin(double[,] inArray)
        {
            double min = inArray[0, 0];
            foreach (double d in inArray)
                if (d < min)
                    min = d;
            return min;
        }
        public float ArrayMax(float[,] inArray)
        {
            float max = inArray[0, 0];
            foreach (float f in inArray)
                if (f > max)
                    max = f;
            return max;
        }
        public double ArrayMax(double[,] inArray)
        {
            double max = inArray[0, 0];
            foreach (double d in inArray)
                if (d > max)
                    max = d;
            return max;
        }
        public float ArrayMin(float[, ,] inArray)
        {
            float min = inArray[0, 0, 0];
            foreach (float f in inArray)
                if (f < min)
                    min = f;
            return min;
        }
        public double ArrayMin(double[,,] inArray)
        {
            double min = inArray[0, 0,0];
            foreach (double d in inArray)
                if (d < min)
                    min = d;
            return min;
        }
        public float ArrayMax(float[,,] inArray)
        {
            float max = inArray[0, 0,0];
            foreach (float f in inArray)
                if (f > max)
                    max = f;
            return max;
        }
        public double ArrayMax(double[, ,] inArray)
        {
            double max = inArray[0, 0, 0];
            foreach (double d in inArray)
                if (d > max)
                    max = d;
            return max;
        }


        public Bitmap ToBitmap(float[,] inArray)
        {
            //converts a float array into a bitmap of the same size
            //scales everything to be in the range 0-255
            //assumes that the bitmap is saved at 8 bit greyscale
            int Width = inArray.GetLength(0);
            int Height = inArray.GetLength(1);

            float minvalue = ArrayMin(inArray);
            float maxvalue = ArrayMax(inArray);
            

            Bitmap outputBitmap = new Bitmap(Width, Height, PixelFormat.Format8bppIndexed);
            SetMonochromePalette(outputBitmap);
            unsafe
            {

                BitmapData bd = outputBitmap.LockBits(
                    new Rectangle(0, 0, outputBitmap.Width, outputBitmap.Height),
                    ImageLockMode.WriteOnly,
                    PixelFormat.Format8bppIndexed);
                Byte* firstPixel = (Byte*)bd.Scan0;
                Byte* pixel = firstPixel;
                int padding = bd.Stride - bd.Width;
                for (int y = 0; y < Height; y++)
                {
                    for (int x = 0; x < Width; x++)
                    {
                        *pixel++ = (byte)(255/(maxvalue-minvalue)*(inArray[x, y]-minvalue));
                    }

                    pixel += padding;
                }
                outputBitmap.UnlockBits(bd);
                
            }
            return outputBitmap;
        }
        public Bitmap ToBitmap(double[,] inArray)
        {
            //converts a float array into a bitmap of the same size
            //scales everything to be in the range 0-255
            //assumes that the bitmap is saved at 8 bit greyscale
            int Width = inArray.GetLength(0);
            int Height = inArray.GetLength(1);

            double minvalue = ArrayMin(inArray);
            double maxvalue = ArrayMax(inArray);


            Bitmap outputBitmap = new Bitmap(Width, Height, PixelFormat.Format8bppIndexed);
            SetMonochromePalette(outputBitmap);
            unsafe
            {

                BitmapData bd = outputBitmap.LockBits(
                    new Rectangle(0, 0, outputBitmap.Width, outputBitmap.Height),
                    ImageLockMode.WriteOnly,
                    PixelFormat.Format8bppIndexed);
                Byte* firstPixel = (Byte*)bd.Scan0;
                Byte* pixel = firstPixel;
                int padding = bd.Stride - bd.Width;
                for (int y = 0; y < Height; y++)
                {
                    for (int x = 0; x < Width; x++)
                    {
                        *pixel++ = (byte)(255 / (maxvalue - minvalue) * (inArray[x, y] - minvalue));
                    }
                    pixel += padding;
                }
                outputBitmap.UnlockBits(bd);

            }
            return outputBitmap;
        }
        public Bitmap ComplexToBitmap(float[,,] inArray)
        {
            //converts a float array into a bitmap of the same size
            //scales everything to be in the range 0-255
            //assumes that the bitmap is saved at 8 bit greyscale
            int Width = inArray.GetLength(0);
            int Height = inArray.GetLength(1);

            float minvalue = ArrayMin(inArray);
            float maxvalue = ArrayMax(inArray);


            Bitmap outputBitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
            unsafe
            {

                BitmapData bd = outputBitmap.LockBits(
                    new Rectangle(0, 0, outputBitmap.Width, outputBitmap.Height),
                    ImageLockMode.WriteOnly,
                    PixelFormat.Format24bppRgb);
                Byte* firstPixel = (Byte*)bd.Scan0;
                Byte* pixel = firstPixel;
                int padding = bd.Stride - bd.Width;
                for (int y = 0; y < Height; y++)
                {
                    for (int x = 0; x < Width; x++)
                    {
                        *pixel++ = (byte)(255 / (maxvalue - minvalue) * (inArray[x, y, 0] - minvalue));
                        *pixel++ = (byte)(255 / (maxvalue - minvalue) * (inArray[x, y, 1] - minvalue));
                        *pixel++ = 0;
                        
                    }
                    pixel += padding;
                }
                outputBitmap.UnlockBits(bd);

            }
            return outputBitmap;
        }
        public Bitmap ComplexToBitmap(double[,,] inArray)
        {
            //converts a float array into a bitmap of the same size
            //scales everything to be in the range 0-255
            //assumes that the bitmap is saved at 8 bit greyscale
            int Width = inArray.GetLength(0);
            int Height = inArray.GetLength(1);

            double minvalue = ArrayMin(inArray);
            double maxvalue = ArrayMax(inArray);
            byte[, ,] testarray = new byte[Width, Height, 3];


            Bitmap outputBitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
            unsafe
            {

                BitmapData bd = outputBitmap.LockBits(
                    new Rectangle(0, 0, outputBitmap.Width, outputBitmap.Height),
                    ImageLockMode.WriteOnly,
                    PixelFormat.Format24bppRgb);
                Byte* firstPixel = (Byte*)bd.Scan0;
                Byte* pixel = firstPixel;
                int padding = bd.Stride - bd.Width;
                for (int y = 0; y < Height; y++)
                {
                    for (int x = 0; x < Width; x++)
                    {
                        *pixel++ = (byte)((255.0 / (maxvalue - minvalue)) * (inArray[x, y, 0] - minvalue));
                        *pixel++ = (byte)((255.0 / (maxvalue - minvalue)) * (inArray[x, y, 1] - minvalue));
                        *pixel++ = 0;

                        testarray[x, y, 0] = (byte)((255.0 / (maxvalue - minvalue)) * (inArray[x, y, 0] - minvalue));
                        testarray[x, y, 1] = (byte)((255.0 / (maxvalue - minvalue)) * (inArray[x, y, 1] - minvalue));
                        testarray[x, y, 2] = 0;

                    }
                    pixel += padding;
                }
                outputBitmap.UnlockBits(bd);
                outputBitmap.Save("C:\\Working Directory\\fftwlib\\test2.bmp");
                Bitmap q = new Bitmap("C:\\Working Directory\\fftwlib\\test2.bmp");
                byte[,,] q2 = FromBitmap(q);
                q2[0, 0, 0] = q2[0, 0, 0];

            }
            return outputBitmap;
        }
        public double[, ,] ArrayLog(double[, ,] inArray)
        {
            int nx = inArray.GetLength(0);
            int ny = inArray.GetLength(1);
            int nz = inArray.GetLength(2);

            double[, ,] outArray = new double[nx, ny, nz];

            for (int x = 0; x < nx; x++)
            {
                for (int y = 0; y < ny; y++)
                {
                    for (int z = 0; z < nz; z++)
                    {
                        outArray[x, y, z] = Math.Log(inArray[x, y, z]);
                        if (Double.IsNaN(outArray[x, y, z]) || Double.IsInfinity(outArray[x, y, z]))
                            outArray[x, y, z] = 0;
                    }
                }
            }
            return outArray;
        }


            
        public byte[,] FromBitmapBW(Bitmap inputImage)
        {
            //converts a Bitmap into a Byte[x,y,c] array
            //assumes that the bitmap is saved at 8 bits - greyscale
            Byte[,] outArray = new Byte[inputImage.Width, inputImage.Height];
            int Width = inputImage.Width;
            int Height = inputImage.Height;
            
            unsafe
            {
                BitmapData bd = inputImage.LockBits(
                    new Rectangle(0, 0, inputImage.Width, inputImage.Height),
                    ImageLockMode.ReadOnly,
                    PixelFormat.Format8bppIndexed);

                Byte* firstPixel = (Byte*)bd.Scan0;
                Byte* lastPixel = firstPixel + inputImage.Width * inputImage.Height;
                Byte* pixel = firstPixel;

                
                for (int x = 0; x < Width; x++)
                {
                    for (int y = 0; y < Height; y++)
                    {
                        outArray[x, y] = *pixel++;
                    }
                }
            }
            return outArray;
        }
        public float[,] Gaussian(int sizex, int sizey, int centerx, int centery, float amplitude, float std)
        {
            //realistic boundaries of the gaussian
            //int minx = (int)Math.Max(0, centerx - 4 * std);
            //int maxx = (int)Math.Min(sizex, centerx + 4 * std);
            //int miny = (int)Math.Max(0, centery - 4 * std);
            //int maxy = (int)Math.Min(sizey, centery + 4 * std);
            int minx = 0; int maxx = sizex ;
            int miny = 0; int maxy = sizey ;

            float[,] outArray = new float[sizex, sizey];

            for (int x = minx; x < maxx; x++)
            {
                for (int y = miny; y < maxy; y++)
                {
                    int dx = Math.Min(sizex - Math.Abs(x - centerx), Math.Abs(centerx - x));
                    int dy = Math.Min(sizey - Math.Abs(y - centery), Math.Abs(centery - y));
                    if(dx*dx+dy*dy < std*std*16) //reduce unnecessary computations (zscore of >4 is very close to zero
                        outArray[x, y] = (float)(amplitude * Math.Exp(-(Math.Pow(dx, 2) + Math.Pow(dy, 2)) / (std * std)));
                }
            }

            return outArray;
        }
        public float[,] Annulus(int sizex, int sizey, int centerx, int centery, float radius1, float amplitude1, float radius2, float amplitude2)
        {
         float[,] outArray = new float[sizex, sizey];
            for (int x = 0; x < sizex; x++)
            {
                for (int y = 0; y < sizey; y++)
                {
                    int dx = Math.Min(sizex - Math.Abs(x - centerx), Math.Abs(centerx - x));
                    int dy = Math.Min(sizey - Math.Abs(y - centery), Math.Abs(centery - y));
                    float dr = (float)Math.Sqrt(dx * dx + dy * dy); //f'in sqrts
                    if (dr <= radius1)
                        outArray[x, y] = amplitude1;
                    else if (dr <= radius2)
                        outArray[x, y] = amplitude2;
                }
            }
            return outArray;
        }
        public float[,] Annulus(int sizex, int sizey, float radius)
        {
            float area = (float)Math.PI * radius * radius;
            float radius2 = radius * 3;
            float area2 = (float)Math.PI * radius2 * radius2 - area;
            return (Annulus(sizex, sizey, 0, 0, radius, 1 / area, 3 * radius, -1 / area2));
        }
        public float[,] GaussianWithMoat(int sizex, int sizey, float radius)
        {
            return (GaussianWithMoat(sizex, sizey, 0, 0, radius/2, 1, radius * 4));
        }
        public float[,] GaussianWithMoat(int sizex, int sizey, int centerx, int centery, float std, float amplitude, float radius2)
        {
            float[,] outArray = Gaussian(sizex, sizey, centerx, centery, amplitude, std);
            float total = 0;
            int numinradius2 = 0;
            for (int x = 0; x < sizex; x++)
            {
                for (int y = 0; y < sizey; y++)
                {
                    int dx = Math.Min(sizex - Math.Abs(x - centerx), Math.Abs(centerx - x));
                    int dy = Math.Min(sizey - Math.Abs(y - centery), Math.Abs(centery - y));
                    float dr2 = dx * dx + dy * dy; 
                    if (dr2 > std * 2 && dr2<radius2) //outside radius1 but inside radius 2, ie in the moat
                        numinradius2++;
                    else if(dx*dx + dy*dy <= std*2) // inside the gaussian, sum these values
                        total += outArray[x, y];
                }
            }
            float moatamplitude = -total / numinradius2;
            for (int x = 0; x < sizex; x++)
            {
                for (int y = 0; y < sizey; y++)
                {
                    int dx = Math.Min(sizex - Math.Abs(x - centerx), Math.Abs(centerx - x));
                    int dy = Math.Min(sizey - Math.Abs(y - centery), Math.Abs(centery - y));
                    float dr2 = dx * dx + dy * dy;
                    if (dr2 > std * 2 && dr2 < radius2) //outside radius1 but inside radius 2, ie in the moat
                        outArray[x, y] = moatamplitude;
                }
            }
            return outArray;
        }
        
        public float[,] BytetoFloat(byte[,] inArray)
        {
            int sx = inArray.GetLength(0);
            int sy = inArray.GetLength(1);
            float[,] outArray = new float[sx, sy];

            for (int x = 0; x < sx; x++)
                for (int y = 0; y < sy; y++)
                    outArray[x, y] = (float)inArray[x, y];

            return outArray;
        }
        public byte[,] FloattoByte(float[,] inArray)
        {
            int sx = inArray.GetLength(0);
            int sy = inArray.GetLength(1);
            byte[,] outArray = new byte[sx, sy];

            for (int x = 0; x < sx; x++)
                for (int y = 0; y < sy; y++)
                    outArray[x, y] = (byte)inArray[x, y];

            return outArray;
        }

        public static void SetMonochromePalette(Bitmap b)
        {
            ColorPalette cp = b.Palette;
            for (int i = 0; i < 255; ++i)
                cp.Entries[i] = Color.FromArgb(i, i, i);
            b.Palette = cp;
        }




              
    }
    #endregion


}
