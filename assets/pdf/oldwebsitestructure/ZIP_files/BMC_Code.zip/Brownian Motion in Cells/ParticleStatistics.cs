using System;
using System.Collections.Generic;
using System.Text;
using GoodStuff;
using CameraDriver;
using System.Drawing;
using System.IO;

namespace BrownianMotion
{
    public class ParticleTrajectory
    {
        public double[] x;
        public double[] y;
        public double[] time; // in seconds
        public double[] dx;
        public double[] dy;
        double[] dt;
        double[] drsquared;
        public double[] DisplacementSquared;
        public int length;
        double Duration;
        DateTime StartTime; 

        public ParticleTrajectory()
        {
            
        }
        public ParticleTrajectory(string Filename)
        {
            ReadFromFile(Filename);
        }
        public ParticleTrajectory(StreamReader SR)
        {
            ReadFromFile(SR);
        }
        public ParticleTrajectory(Particle[] InParticles)
        {
            length = InParticles.Length;
            
            //initialize variables
            x = new double[length];
            y = new double[length];
            time = new double[length];
            dx = new double[length];
            dy = new double[length];
            dt = new double[length];
            drsquared = new double[length];
            DisplacementSquared = new double[length];
            StartTime = InParticles[length-1].Time;                        
            x[0] = InParticles[length -1 ].x;
            y[0] = InParticles[length - 1].y;
            time[0] = 0;
            
            //collect and compute all position data
            for (int i = 1; i < length; i++)
            {
                x[i] = InParticles[length - 1-i].x;
                y[i] = InParticles[length - 1 - i].y;
                time[i] = (InParticles[length - 1 - i].Time - InParticles[length - 1 ].Time).TotalSeconds;
                dx[i] = x[i] - x[i - 1];
                dy[i] = y[i] - y[i - 1];
                dt[i] = time[i] - time[i - 1];
                drsquared[i] = dx[i] * dx[i] + dy[i] * dy[i];
                DisplacementSquared[i] = Math.Pow(x[i] - x[0], 2) + Math.Pow(y[i] - y[0], 2);
            }
            Duration = time[length - 1] - time[0];
        }


        public void ConvertDistanceUnits(double MultiplicationFactor)
        {
            for (int i = 0; i < length; i++)
            {
                x[i] *= MultiplicationFactor;
                y[i] *= MultiplicationFactor;
                dx[i] *= MultiplicationFactor;
                dy[i] *= MultiplicationFactor;
                drsquared[i] *= MultiplicationFactor*MultiplicationFactor;
                DisplacementSquared[i] *= MultiplicationFactor * MultiplicationFactor;
            }
        }
        public double DiffusionCoefficient()
        {
            //i'm not commenting on why this is at the moment. 
            //If you go through a very simple least squares model of Displacement^2 = D*t (from Einstein) 
            //you will arrive at this. In short, we're just calculating the slope (D)
            int NumDimensions = 2;
            double numerator = 0;
            double denominator = 0;
            for (int i = 0; i < length; i++)
            {
                numerator += DisplacementSquared[i] * time[i];
                denominator += time[i] * time[i];
            }
            return numerator / denominator / (2*NumDimensions);
        }
        public void WriteToFile(StreamWriter SW)
        {
            //SW.WriteLine(length.ToString() + " " + StartTime.ToString()) ;//need to add milliseconds
            SW.WriteLine(length.ToString());
            string[] stringarray = new string[8];
            for (int i = 0; i < length; i++)
            {
                stringarray[0] = x[i].ToString(); stringarray[1] = y[i].ToString(); stringarray[2] = time[i].ToString();
                stringarray[3] = dx[i].ToString(); stringarray[4] = dy[i].ToString(); stringarray[5] = dt[i].ToString();
                stringarray[6] = drsquared[i].ToString(); stringarray[7] = DisplacementSquared[i].ToString();
                SW.WriteLine(string.Join(" ", stringarray));
            }
        }
        public void ReadFromFile(string Filename)
        {
            StreamReader SR = new StreamReader(Filename);
            ReadFromFile(SR);
        }
        public void ReadFromFile(StreamReader SR)
        {
            //string s = SR.ReadLine();
            //string s1 = s.Substring(0,s.IndexOf(" "));
            //length = int.Parse(s1);
            //StartTime = DateTime.Parse(s.Substring(s.IndexOf(" ")));
            
            length = int.Parse(SR.ReadLine());
            //initialize variables
            x = new double[length];
            y = new double[length];
            time = new double[length];
            dx = new double[length];
            dy = new double[length];
            dt = new double[length];
            drsquared = new double[length];
            DisplacementSquared = new double[length];
            char[] delimeters = new char[1];
            delimeters[0] = ' ';
            string[] stringarray = new string[8];
            for (int i = 0; i < length; i++)
            {

                stringarray = SR.ReadLine().Split(delimeters);
                x[i] = double.Parse(stringarray[0]);
                y[i] = double.Parse(stringarray[1]);
                time[i] = double.Parse(stringarray[2]);
                dx[i] = double.Parse(stringarray[3]);
                dy[i] = double.Parse(stringarray[4]);
                dt[i] = double.Parse(stringarray[5]);
                drsquared[i] = double.Parse(stringarray[6]);
                DisplacementSquared[i] = double.Parse(stringarray[7]);
            }
        }

    }

    public class ParticleStatistics : IInitializable 
    {
        public event SampleEventHandler ReportStatistics;
        public event SampleEventHandler ReportStatus;
        public event SampleEventHandler PlotOut;
        bool DoStatistics;
        bool WriteToFile;
        bool SetStartTime;
        DateTime StartTime;
        DateTime EndTime;
        double UnitMultiplicationFactor;

        GoodProperty<String> _filename;
        public GoodProperty<String> Filename
        {
            get{return _filename;}
            set { _filename = value; }
        }
                
        public ParticleStatistics()
        {
            StartTime = DateTime.Now;
            UnitMultiplicationFactor = 384e-9;
            _filename = new GoodProperty<string>();
            _filename.Value = "C:\\Particles.txt";
        }
        #region Interfacing with the User Interface
        public void UISaysDoStatistics(object sender, SampleEventArgs sArgs)
        {
            DoStatistics = !DoStatistics;
        }
        public void UISaysWriteToFile(object sender, SampleEventArgs sArgs)
        {
            WriteToFile = !WriteToFile;
        }
        public void UISetStartTime(object sender, SampleEventArgs sArgs)
        {
            SetStartTime = true; // set up a flag
            //StartTime = DateTime.Now;
        }
        public void UIConversionFactor(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                Double.TryParse((string)sArgs.Sample["Value"], out UnitMultiplicationFactor);
                //UnitMultiplicationFactor = Double.Parse((string)sArgs.Sample["Value"]);
        }
        public void UIFilenameChanged(object sender, SampleEventArgs sArgs)
        {
            if (sArgs.Sample.ContainsKey("Value"))
                _filename.Value = (string)sArgs.Sample["Value"];
        }
        public void ReportStatusLocal(string messageout)
        {
            SampleEventArgs s = new SampleEventArgs();
            s.Sample.Add("Message", messageout);
            if(ReportStatus!=null)
                ReportStatus(this, s);
        }
        #endregion


        public void IncomingParticles(object sender, SampleEventArgs sArgs)
        {
            if (SetStartTime && sArgs.Sample.ContainsKey("Time"))
            {
                SetStartTime = false;
                StartTime = (DateTime)sArgs.Sample["Time"];
            }
            else if (SetStartTime)
            {
                SetStartTime = false;
                StartTime = DateTime.Now;
            }
            
            if (DoStatistics || WriteToFile)
            {
                Particle[] CurrentParticles;
                List<Particle> LostParticles;


                if(sArgs.Sample.ContainsKey("StartTime"))
                    StartTime = (DateTime)sArgs.Sample["StartTime"];
                if (sArgs.Sample.ContainsKey("EndTime"))
                    EndTime = (DateTime)sArgs.Sample["EndTime"];
                else if (sArgs.Sample.ContainsKey("Time"))
                    EndTime = (DateTime)sArgs.Sample["Time"];
                else
                    EndTime = DateTime.Now;
                if (sArgs.Sample.ContainsKey("Particles"))
                    CurrentParticles = (Particle[])sArgs.Sample["Particles"];
                else
                    CurrentParticles = new Particle[0];
                if (sArgs.Sample.ContainsKey("LostParticles"))
                    LostParticles = (List<Particle>)sArgs.Sample["LostParticles"];
                else
                    LostParticles = new List<Particle>(0);
                ParticleTrajectory[] ParticleTrajectories = CompileValidParticleTrajectories(CurrentParticles, LostParticles, StartTime, EndTime);
                ParticleTrajectories = ConvertUnits(ParticleTrajectories);
                if (DoStatistics)
                {
                    double DiffusionCoefficient = ComputeDiffusionCoefficient(ParticleTrajectories);
                    //ComputeFluidMap(ParticleTrajectories, 100, 100);
                    SampleEventArgs outArgs = new SampleEventArgs();

                    DoStatistics = false;

                    outArgs.Sample.Add("DiffusionCoefficient", DiffusionCoefficient);
                    outArgs.Sample.Add("Message", DiffusionCoefficient.ToString()); //for output to GoodTextBox
                    ReportStatistics(this, outArgs);

                   /* SampleEventArgs plotArgs = new SampleEventArgs();
                    double[] x = new double[5];
                    for(int i = 0 ; i < 5; i++)
                        x[i] = i;
                    plotArgs.Sample.Add("X", x); plotArgs.Sample.Add("Y", x);
                    if(PlotOut!=null)
                        PlotOut(this, plotArgs);*/
                }
                if (WriteToFile)
                {
                    SaveParticleTracksToFile(ParticleTrajectories, _filename.Value);
                    WriteToFile = false;
                }
            }

         


        }
        public ParticleTrajectory[] CompileValidParticleTrajectories(Particle[] CurrentParticles, List<Particle> LostParticles, DateTime StartTime, DateTime EndTime)
        {
            int minlength = 10;
            List<Particle[]> ValidParticleArrays = new List<Particle[]>(LostParticles.Count);
            Particle[] temp;
            foreach (Particle P in LostParticles)
            {
                temp = P.ToArray(EndTime, StartTime);
                if (temp != null)
                    ValidParticleArrays.Add(temp);
            }
            foreach (Particle P in CurrentParticles)
            {
                temp = P.ToArray(EndTime, StartTime);
                if (temp != null && temp.Length>0)
                    ValidParticleArrays.Add(temp);
            }
            
            int GoodPTLength = 0;
            foreach (Particle[] Parray in ValidParticleArrays)
            {
                if (Parray.Length >= minlength)
                    GoodPTLength++;
            }
            ParticleTrajectory[] PT = new ParticleTrajectory[GoodPTLength];
            int PTindex = 0;
            for (int i = 0; i < ValidParticleArrays.Count; i++)
                if (ValidParticleArrays[i].Length >= minlength)
                {
                    PT[PTindex] = new ParticleTrajectory(ValidParticleArrays[i]);
                    PTindex++;
                }            
            return (PT);
        }
        public double ComputeDiffusionCoefficient(ParticleTrajectory[] ParticleTrajectories)
        {
            double[] DiffusionCoefficients = new double[ParticleTrajectories.Length];
            double[] lengths = new double[ParticleTrajectories.Length];
            
            for (int i = 0; i < ParticleTrajectories.Length; i++)
            {
                lengths[i] = ParticleTrajectories[i].length;
                DiffusionCoefficients[i] = ParticleTrajectories[i].DiffusionCoefficient();
                SampleEventArgs PlotArgs = new SampleEventArgs();
                if (PlotOut != null)
                {
                    PlotArgs.Sample.Add("X", ParticleTrajectories[i].time);
                    PlotArgs.Sample.Add("Y", ParticleTrajectories[i].DisplacementSquared);
                    PlotArgs.Sample.Add("X Label", "Time (s)");
                    PlotArgs.Sample.Add("Y Label", "Displacement Squared (m^2)");
                    PlotArgs.Sample.Add("Hold", true);
                    PlotArgs.Sample.Add("Color", i);
                    PlotOut(this, PlotArgs);
                }
            }
            //if (PlotOut != null)
            //{
            //    SampleEventArgs PlotArgs = new SampleEventArgs();
            //    double[] x = new double[DiffusionCoefficients.Length];
            //    for (int i = 0; i < x.Length; i++)
            //        x[i] = i;

            //    PlotArgs.Sample.Add("X", x);
            //    PlotArgs.Sample.Add("Y", DiffusionCoefficients);
            //    PlotArgs.Sample.Add("Title", "Our Calculated Diffusion Coefficients");
            //    PlotOut(this, PlotArgs);
            //}
            double D = WeightedMean(DiffusionCoefficients, lengths);
            ReportStatusLocal("Diffusion Coefficient Calculated as " + D.ToString());
            return D;
        }
        public ParticleTrajectory[] ConvertUnits(ParticleTrajectory[] inTrajectories)
        {
            foreach (ParticleTrajectory PT in inTrajectories)
                PT.ConvertDistanceUnits(UnitMultiplicationFactor);
            return inTrajectories;
        }
        public double WeightedMean(double[] X, double[] Weights)
        {
            double total = 0;
            double sumweights = 0;
            for (int i = 0; i < X.Length; i++)
            {
                total += X[i] * Weights[i];
                sumweights += Weights[i];
            }
            return total / sumweights;
        }
       
        public void SaveParticleTracksToFile(ParticleTrajectory[] ParticleTrajectories, string Filename)
        {
            Filename = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + '\\' + Filename;
            StreamWriter SW = new StreamWriter(Filename);
            SW.WriteLine("x y time dx dy dt dr^2 TotalDisplacementSquared");

            foreach (ParticleTrajectory PT in ParticleTrajectories)
                PT.WriteToFile(SW);
            SW.Close();
            ReportStatusLocal("Particle Tracks Saved to " + Filename);
        }
        public void ComputeFluidMap(ParticleTrajectory[] ParticleTrajectories, int sizex, int sizey)
        {
            int length = 0;
            foreach (ParticleTrajectory PT in ParticleTrajectories)
                length += PT.length-1;
            double[] x = new double[length];
            double[] y = new double[length];
            double[] dx = new double[length];
            double[] dy = new double[length];
            int i = 0; 
            //Conglomerate all of the particles' information here
            foreach(ParticleTrajectory PT in ParticleTrajectories)
            {
                for(int j = 1; j < PT.length; j++)
                {
                    x[i] = PT.x[j];
                    y[i] = PT.y[j];
                    dx[i] = PT.dx[j];
                    dy[i] = PT.dy[j];
                    i++;//i doesnt reset, j does
                }
            }
            //find max and min x,y
            double maxx = 0, maxy = 0, minx = 1e99, miny = 1e99;
            for(i = 0 ; i < length; i++)
            {
                if(x[i] > maxx) maxx = x[i];
                if(x[i] < minx) minx = x[i];
                if(y[i] > maxy) maxy = y[i]; 
                if(y[i] < miny) miny = y[i];
            }
            //particle to fluidarray conversions
            double conversionx = sizex / (maxx - minx);
            double conversiony = sizey / (maxy - miny);

            double[,] DX = new double[sizex, sizey];
            double[,] DY = new double[sizex, sizey];
            double WeightThreshold = 1.0 / (Math.Pow(sizex*.15,4));
            for (int xx = 0; xx < sizex; xx++)
            {
                for (int yy = 0; yy < sizey; yy++)
                {
                    double sumdx = 0;
                    double sumdy = 0;
                    double totalweight = 0;
                    for (i = 0; i < length; i++)
                    {
                        double inverseweight = InverseWeight(conversionx*x[i]+minx, conversiony*y[i]+miny, xx, yy);
                        if (inverseweight < WeightThreshold)
                            inverseweight = 0;
                        else
                        {
                        }

                        sumdx += inverseweight * dx[i];
                        sumdy += inverseweight * dy[i];
                        totalweight += inverseweight;
                    }
                    if (totalweight != 0)
                    {
                        DX[xx, yy] = sumdx / totalweight;
                        DY[xx, yy] = sumdy / totalweight;
                    }
                    

                }
            }
            fftwlib.fftweasy fft = new fftwlib.fftweasy();
            fft.ToBitmap(DX).Save("c:\\dx.bmp");
            fft.ToBitmap(DY).Save("c:\\dy.bmp");
            ReportStatusLocal("DX and DY bitmaps saved");

        }
        public double InverseWeight(double x1, double y1, double x2, double y2)
        {
            double exponent = 4;
            double mindistance = 10;
            return (1 / (Math.Abs(Math.Pow(x1 - x2, exponent)) + Math.Abs(Math.Pow(y1 - y2, exponent)) + mindistance));
        }

        


        public void Initialize()
        {
        }


    }
}
