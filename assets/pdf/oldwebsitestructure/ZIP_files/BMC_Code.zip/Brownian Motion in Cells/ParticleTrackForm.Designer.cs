using CameraDriver;
using System.Windows.Forms;
namespace BrownianMotion
{
    partial class ParticleTrackForm : Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.goodPictureBox1 = new GoodStuff.GoodPictureBox();
            this.goodPictureBox2 = new GoodStuff.GoodPictureBox();
            this.goodPictureBox3 = new GoodStuff.GoodPictureBox();
            this.goodPictureBox4 = new GoodStuff.GoodPictureBox();
            this.goodPictureBox5 = new GoodStuff.GoodPictureBox();
            this.goodPictureBox6 = new GoodStuff.GoodPictureBox();
            this.goodGroupBox1 = new GoodStuff.GoodGroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.goodGroupBox2 = new GoodStuff.GoodGroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.goodGroupBox1.SuspendLayout();
            this.goodGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // goodPictureBox1
            // 
            this.goodPictureBox1.Location = new System.Drawing.Point(13, 7);
            this.goodPictureBox1.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.goodPictureBox1.Name = "goodPictureBox1";
            this.goodPictureBox1.Size = new System.Drawing.Size(200, 100);
            this.goodPictureBox1.TabIndex = 0;
            this.goodPictureBox1.TabStop = false;
            this.goodPictureBox1.Text = "goodPictureBox1";
            // 
            // goodPictureBox2
            // 
            this.goodPictureBox2.Location = new System.Drawing.Point(13, 125);
            this.goodPictureBox2.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.goodPictureBox2.Name = "goodPictureBox2";
            this.goodPictureBox2.Size = new System.Drawing.Size(200, 100);
            this.goodPictureBox2.TabIndex = 1;
            this.goodPictureBox2.TabStop = false;
            this.goodPictureBox2.Text = "goodPictureBox2";
            this.goodPictureBox2.Enter += new System.EventHandler(this.goodPictureBox2_Enter);
            // 
            // goodPictureBox3
            // 
            this.goodPictureBox3.Location = new System.Drawing.Point(242, 7);
            this.goodPictureBox3.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.goodPictureBox3.Name = "goodPictureBox4";
            this.goodPictureBox3.Size = new System.Drawing.Size(200, 100);
            this.goodPictureBox3.TabIndex = 3;
            this.goodPictureBox3.TabStop = false;
            this.goodPictureBox3.Text = "goodPictureBox4";
            // 
            // goodPictureBox4
            // 
            this.goodPictureBox4.Location = new System.Drawing.Point(242, 125);
            this.goodPictureBox4.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.goodPictureBox4.Name = "goodPictureBox5";
            this.goodPictureBox4.Size = new System.Drawing.Size(200, 100);
            this.goodPictureBox4.TabIndex = 4;
            this.goodPictureBox4.TabStop = false;
            this.goodPictureBox4.Text = "goodPictureBox5";
            // 
            // goodPictureBox5
            // 
            this.goodPictureBox5.Location = new System.Drawing.Point(461, 13);
            this.goodPictureBox5.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.goodPictureBox5.Name = "goodPictureBox7";
            this.goodPictureBox5.Size = new System.Drawing.Size(200, 100);
            this.goodPictureBox5.TabIndex = 5;
            this.goodPictureBox5.TabStop = false;
            this.goodPictureBox5.Text = "goodPictureBox7";
            // 
            // goodPictureBox6
            // 
            this.goodPictureBox6.Location = new System.Drawing.Point(461, 131);
            this.goodPictureBox6.Margin = new System.Windows.Forms.Padding(3, 15, 3, 3);
            this.goodPictureBox6.Name = "goodPictureBox8";
            this.goodPictureBox6.Size = new System.Drawing.Size(200, 100);
            this.goodPictureBox6.TabIndex = 6;
            this.goodPictureBox6.TabStop = false;
            this.goodPictureBox6.Text = "goodPictureBox8";
            // 
            // goodGroupBox1
            // 
            this.goodGroupBox1.Controls.Add(this.button4);
            this.goodGroupBox1.Controls.Add(this.button3);
            this.goodGroupBox1.Controls.Add(this.checkBox1);
            this.goodGroupBox1.Controls.Add(this.label2);
            this.goodGroupBox1.Controls.Add(this.label1);
            this.goodGroupBox1.Controls.Add(this.textBox2);
            this.goodGroupBox1.Controls.Add(this.button2);
            this.goodGroupBox1.Controls.Add(this.textBox1);
            this.goodGroupBox1.Controls.Add(this.button1);
            this.goodGroupBox1.Location = new System.Drawing.Point(690, 13);
            this.goodGroupBox1.Margin = new System.Windows.Forms.Padding(5, 15, 5, 5);
            this.goodGroupBox1.Name = "goodGroupBox1";
            this.goodGroupBox1.Size = new System.Drawing.Size(261, 176);
            this.goodGroupBox1.TabIndex = 7;
            this.goodGroupBox1.TabStop = false;
            this.goodGroupBox1.Text = "Movie Controls";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(180, 37);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Load Movie";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(107, 40);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(57, 20);
            this.textBox1.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(180, 71);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Process Movie";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(107, 74);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(57, 20);
            this.textBox2.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Start Frame";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Stop Frame";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(87, 100);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(97, 17);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Show Progress";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(58, 123);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 7;
            this.button3.Text = "Next Frame";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(151, 123);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 8;
            this.button4.Text = "Previous Frame";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // goodGroupBox2
            // 
            this.goodGroupBox2.Controls.Add(this.label19);
            this.goodGroupBox2.Controls.Add(this.label17);
            this.goodGroupBox2.Controls.Add(this.label15);
            this.goodGroupBox2.Controls.Add(this.label14);
            this.goodGroupBox2.Controls.Add(this.label18);
            this.goodGroupBox2.Controls.Add(this.label16);
            this.goodGroupBox2.Controls.Add(this.label13);
            this.goodGroupBox2.Controls.Add(this.label12);
            this.goodGroupBox2.Controls.Add(this.label11);
            this.goodGroupBox2.Controls.Add(this.textBox11);
            this.goodGroupBox2.Controls.Add(this.label10);
            this.goodGroupBox2.Controls.Add(this.label9);
            this.goodGroupBox2.Controls.Add(this.label8);
            this.goodGroupBox2.Controls.Add(this.label7);
            this.goodGroupBox2.Controls.Add(this.label6);
            this.goodGroupBox2.Controls.Add(this.label5);
            this.goodGroupBox2.Controls.Add(this.checkBox2);
            this.goodGroupBox2.Controls.Add(this.textBox10);
            this.goodGroupBox2.Controls.Add(this.textBox9);
            this.goodGroupBox2.Controls.Add(this.textBox8);
            this.goodGroupBox2.Controls.Add(this.textBox7);
            this.goodGroupBox2.Controls.Add(this.textBox6);
            this.goodGroupBox2.Controls.Add(this.textBox5);
            this.goodGroupBox2.Controls.Add(this.label3);
            this.goodGroupBox2.Controls.Add(this.label4);
            this.goodGroupBox2.Controls.Add(this.textBox3);
            this.goodGroupBox2.Controls.Add(this.textBox4);
            this.goodGroupBox2.Location = new System.Drawing.Point(690, 209);
            this.goodGroupBox2.Margin = new System.Windows.Forms.Padding(5, 15, 5, 5);
            this.goodGroupBox2.Name = "goodGroupBox2";
            this.goodGroupBox2.Size = new System.Drawing.Size(302, 351);
            this.goodGroupBox2.TabIndex = 9;
            this.goodGroupBox2.TabStop = false;
            this.goodGroupBox2.Text = "Movie Controls";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(55, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "TimeStep";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(73, 43);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Scale";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(127, 67);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(57, 20);
            this.textBox3.TabIndex = 3;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(127, 40);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(57, 20);
            this.textBox4.TabIndex = 1;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(127, 93);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(57, 20);
            this.textBox5.TabIndex = 6;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(127, 119);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(57, 20);
            this.textBox6.TabIndex = 7;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(127, 145);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(57, 20);
            this.textBox7.TabIndex = 8;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(127, 171);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(57, 20);
            this.textBox8.TabIndex = 9;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(127, 197);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(57, 20);
            this.textBox9.TabIndex = 10;
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(127, 223);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(57, 20);
            this.textBox10.TabIndex = 11;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(38, 249);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(109, 17);
            this.checkBox2.TabIndex = 12;
            this.checkBox2.Text = "Subtract Average";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 96);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Object Diameter";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(33, 119);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Noise Diameter";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(55, 145);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Threshold ";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 171);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(101, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Minimum Threshold ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 226);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 13);
            this.label9.TabIndex = 17;
            this.label9.Text = "Maximum Displacement";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 197);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(93, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Minimum Diameter";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(127, 295);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(57, 20);
            this.textBox11.TabIndex = 19;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(89, 302);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(23, 13);
            this.label11.TabIndex = 20;
            this.label11.Text = "Eta";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(190, 43);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 13);
            this.label12.TabIndex = 21;
            this.label12.Text = "nm per pixel";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(192, 70);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "milliseconds";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(192, 145);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(63, 13);
            this.label16.TabIndex = 25;
            this.label16.Text = "nm per pixel";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(190, 226);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 13);
            this.label18.TabIndex = 27;
            this.label18.Text = "nanometers";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(190, 119);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(62, 13);
            this.label14.TabIndex = 28;
            this.label14.Text = "nanometers";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(190, 96);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(62, 13);
            this.label15.TabIndex = 29;
            this.label15.Text = "nanometers";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(190, 174);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(103, 13);
            this.label17.TabIndex = 30;
            this.label17.Text = "Standard Deviations";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(203, 302);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(31, 13);
            this.label19.TabIndex = 31;
            this.label19.Text = "10^6";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 600);
            this.Controls.Add(this.goodGroupBox2);
            this.Controls.Add(this.goodGroupBox1);
            this.Controls.Add(this.goodPictureBox8);
            this.Controls.Add(this.goodPictureBox7);
            this.Controls.Add(this.goodPictureBox5);
            this.Controls.Add(this.goodPictureBox4);
            this.Controls.Add(this.goodPictureBox2);
            this.Controls.Add(this.goodPictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.goodGroupBox1.ResumeLayout(false);
//            this.goodGroupBox1.PerformLayout();
            this.goodGroupBox2.ResumeLayout(false);
//            this.goodGroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private GoodStuff.GoodPictureBox goodPictureBox1;
        private GoodStuff.GoodPictureBox goodPictureBox2;
        private GoodStuff.GoodPictureBox goodPictureBox4;
        private GoodStuff.GoodPictureBox goodPictureBox5;
        private GoodStuff.GoodPictureBox goodPictureBox7;
        private GoodStuff.GoodPictureBox goodPictureBox8;
        private GoodStuff.GoodGroupBox goodGroupBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private GoodStuff.GoodGroupBox goodGroupBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
    }
}